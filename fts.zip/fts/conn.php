<?php

#configuration directives
class Config
{
    var $absolute_path = "C:/xampp5/htdocs/fts/"; #include ending /
    var $site_url = "http://localhost//fts/"; #include ending /
    var $root_dir = "/fts/";
    var $db_name = "fts";
    var $db_user = "root";
    var $db_pass = "";
    var $db_host = "localhost";
    var $admin_email = "www.ifast.com.pk";//email to use as FROM
    var $site_name = "";
    var $upload_size_allowed = "8048576";//in bytes
    var $image_dir = "upload_file/";//spaw image director with ending slash
    var $file_dir = "upload_file/";//spaw image director with ending slash
    var $newsletter_dir = "newsletter_images/";//spaw image director with ending slash
    var $thumbnailWidth = 100;//width of the thumbnails generated for product images
    var $mainImageWidth = 500;
    var $mainImageHeight = 500;
    var $largeThumbnailWidth = 348;
    var $largeThumbnailHeight = 348;
    var $mediumThumbnailWidth = 178;
    var $mediumThumbnailHeight = 178;
    var $smallThumbnailWidth = 68;
    var $smallThumbnailHeight = 68;

//price settings
    var $price_handler = "&pound;";
    var $hotel_comission = "20.00";

//header for email
    var $email_header;

//footer for email
    var $email_footer;

//payment options

    var $payment_option;
    var $payment_option_name;

//PAYPAL settings
    var $currency = "AED";
    var $paypal_test = 1;//0 or 1
    var $paypal_currency = "GBP";
    var $paypal_success = "order_success.php";
    var $paypal_notify = "trans/paypal.php";
    var $paypal_cancel = "order_cancel.php";
    var $paypal_id = "atroniks@hotmail.co.uk";//business
    var $paypal_log_file = "log/paypal_ipn_log.txt";//paypal log file

    function conn()
    {
        $this->email_header = "<link href='" . $this->site_url . "css/styles.css' rel='stylesheet' type='text/css'><table width='100%' border='0' cellpadding='0' cellspacing='1'>

<tr>
<td><img src='" . $this->site_url . "images/email-header.jpg' border='0'></td>
</tr>
<tr>
<td class='blacktext'><br>";
        $this->email_footer = "<br></td>
</tr>
</table>";

//paypal init

        /*
        $this->payment_option[]=$this->site_url."order_paypal.php";
        $this->payment_option_name[]="Pay pal";
        */

        $this->paypal_success = $this->site_url . $this->paypal_success;
        $this->paypal_notify = $this->site_url . $this->paypal_notify;
        $this->paypal_cancel = $this->site_url . $this->paypal_cancel;
        $this->paypal_log_file = $this->absolute_path . $this->paypal_log_file;
    }

}

?>
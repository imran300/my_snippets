<?php
class User extends DBAccess{
	function User(){
		$this->connectToDB();
	}
	
	public function getAllUsers($q){
		$sql = "SELECT * FROM um_users AS u
				LEFT JOIN employee AS e	ON (u.employee_id = e.employee_id)
				LEFT JOIN um_groups AS g ON (u.group_id = g.group_id)
				$q
				";
		$data = $this->CustomQuery($sql);
		return $data;
	}
	public function addUser(){
		extract($_POST);
		$check_user = $this->uniqueUser($username);
		if($check_user < 1){
			if(isset($is_active)){$is_active = 1;}else{$is_active = 0;}
			if(isset($is_admin)){$is_admin = 1;}else{$is_admin = 0;}
			$sql  = "INSERT INTO um_users SET
					employee_id = '$employee_id',
					group_id = '$group_id',
					username = '$username',
					password = '".md5($password)."',
					is_active = '$is_active',
					is_admin ='$is_admin'	
				";
			if(mysql_query($sql)){
				return "User added successfully!";
			}
		}else{
			return "this username is not available!";
		}
		
		
		
	}
	public function getUser($id){
		$data = $this->GetRecord('um_users', 'user_id', $id);
		return  $data;
	}
	
	public function updateUser(){
		extract($_POST);
		$check_user = 0;//$this->uniqueUser($username);
		if($check_user < 1){
			if(isset($is_active)){$is_active = 1;}else{$is_active = 0;}
			if(isset($is_admin)){$is_admin = 1;}else{$is_admin = 0;}
			$sql  = "UPDATE um_users SET
					employee_id = '$employee_id',
					group_id = '$group_id',
					
					password = '".md5($password)."',
					is_active = '$is_active',
					is_admin ='$is_admin'	
					WHERE user_id = $user_id
				";
			if(mysql_query($sql)){
				return "User updated successfully!";
			}
		}else{
			return "this username is not available!";
		}
	}
	public function deleteUser($id){
		$sql = "DELETE";
		
		if($this->deleteRecord('um_users', ' user_id = '.$id)){
			return "User deleted";
		}
		
		
	}
	public function deleteMenu($id){
		$sql = "DELETE";
		
		if($this->deleteRecord('um_menu', ' menu_id  = '.$id)){
			return "Menu deleted";
		}
		
		
	}
	public function uniqueUser($username){
		$sql = "SELECT count(username) AS num from um_users where username = '$username'";
		$rs = mysql_query($sql);
		$rec = mysql_fetch_array($rs);
		$data = $rec['num'];
		return $data;
	}
	public function setPermissions(){
		
		$dsql = "DELETE from um_permissions where group_id = ".$_POST['group_id'];
		mysql_query($dsql);
		$menu = "SELECT * FROM um_menu";
		$rs = mysql_query($menu);
		while($row = mysql_fetch_array($rs)){
			$view = 0;
			$edit = 0;
			$add = 0;
			$delete = 0;
			
			if(isset($_POST['permission']['view'][$row['menu_id']])){
				$view = 1;
			}
			if(isset($_POST['permission']['add'][$row['menu_id']])){
				$add = 1;
			}
			if(isset($_POST['permission']['edit'][$row['menu_id']])){
				$edit = 1;
			}
			if(isset($_POST['permission']['delete'][$row['menu_id']])){
				$delete = 1;
			}
			
			$sql = "INSERT INTO um_permissions SET 
					group_id = '".$_POST['group_id']."', 
					menu_id = '".$row['menu_id']."',
					pview = '$view',
					padd = '$add',
					pdelete = '$delete',
					pedit = '$edit'
					"
					;
			
			mysql_query($sql) or die(mysql_error());
		}
		
	}
	
/***************************************************************loginsetting********************************************************/	
	function Login(){
		extract ($_POST);
		 $sql = "SELECT * FROM users as u
				LEFT JOIN employee AS e ON (u.idemployee = e.idemployee)
				LEFT JOIN department AS d ON (e.iddepartment = d.iddepartment)
				LEFT JOIN section AS s ON (e.idsection = s.idsection)
				LEFT JOIN designation AS g ON (e.iddesignation = g.iddesignation)
				WHERE 
				u.username = '$username'
				AND
				u.password = '".md5($password)."'
				AND
				u.isactive = 1
				";
		
		$rs = mysql_query($sql);
		$num = mysql_num_rows($rs);
		unset($_SESSION['user']);
		if($num > 0){
			
			$row = mysql_fetch_array($rs);
			$_SESSION['luser']['idusers'] = $row['idusers'];
			$_SESSION['luser']['iddepartment'] = $row['iddepartment'];
			$_SESSION['luser']['idsection'] = $row['idsection'];
			$_SESSION['luser']['iddesignation'] = $row['iddesignation'];
			$_SESSION['luser']['empname'] = $row['empname'];
			$_SESSION['luser']['username'] = $row['username'];
			$_SESSION['luser']['department'] = $row['department'];
			$_SESSION['luser']['section'] = $row['section'];
			$_SESSION['luser']['designation'] = $row['designation'];
			$_SESSION['luser']['logo'] = $row['picture'];
			$_SESSION['luser']['prefix'] = $row['prefix'];
			
			if($row['isadmin'] == 1 ){
				$_SESSION['luser']['admin'] = 1;
			}else{
				$_SESSION['luser']['admin'] = 0;
			}
			
			header("Location:index.php"); 
		}
		else{
		return $this->error = "<div id='errormessage'>Invalid Credentials. Please try again!</div>";
		}
	}
	function validate($data,$cmenu){
		
		$allow = 0;
		if(!isset($data['user'])){
			header("Location:login.php");
			
		}else{
			extract($_SESSION['luser']);
			$sql = "SELECT * FROM um_permissions as p
					left join um_menu as m ON (p.menu_id = m.menu_id) 
					
					WHERE group_id = $group";
			
			$data = $this->CustomQuery($sql);
			
			foreach ($data as $d) {
				if($d['url'] == $cmenu){
					$allow = 1;
				}
			}
			
			return $allow;
		}
	}
}
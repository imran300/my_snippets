<?php

class General extends DBaccess
{
    function General()
    {
        $this->connectToDB();

    }

    public function maximum_number_test_1()
    {

        $sql = "SELECT * FROM  tests1";

        $data = $this->totalRecordsInQuery_max($sql);

        return $data;
    }

    function addGender()
    {
        extract($_POST);
        $query = mysql_query("SELECT * FROM gen_gender where gender_title='" . $gentitle . "'");
        $row = mysql_fetch_array($query);

        if (empty($gentitle) || $gentitle == 'Gender Title') {
            return $this->error = "Please Enter title";
        } else {
            if (empty($row['gender_title'])) {
                $insert = "gender_title";
                $vals = "'" . mysql_real_escape_string($gentitle) . "'";
                $id = $this->InsertRecord("gen_gender", $insert, $vals);
                unset($_POST);
                $this->success = "Gender has been added successfully";
                return $id;
            } else
                return $this->err = "Gender already exists.";

        }

    }

    function getAllGender($start, $limit, $q)
    {
        $sql = "SELECT * FROM gen_gender $q order by gender desc LIMIT " . $start . ", " . $limit;

        $data = $this->CustomQuery($sql);
        if (empty($data)) {
            $data = array();
        }
        return $data;
    }

    function countAllGender()
    {
        $sql = "SELECT * FROM gen_gender";
        $data = $this->totalRecordsInQuery($sql);
        return $data;
    }

    function searchGender($q)
    {
        $sql = "SELECT * FROM gen_gender" . $q;
        $data = $this->CustomQuery($sql);
        if (empty($data)) {
            $data = array();
        }
        return $data;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    function counttotalissuedfiles()
    {
        $iddepartment = $_SESSION['luser']['iddepartment'];
        $idsection = $_SESSION['luser']['idsection'];
        $sql = "SELECT COUNT(`idissue`) as totissuefiles FROM `issue` 
	WHERE `fromdept` = '$iddepartment'
	AND `fromsection` = '$idsection'";
        $data = $this->CustomQuery($sql);
        return $data;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    function counttotalreceivefile()
    {
        $iddepartment = $_SESSION['luser']['iddepartment'];
        $idsection = $_SESSION['luser']['idsection'];
        $sql = "SELECT COUNT( 1 ) AS totreceivefile
	FROM  `receive` AS r,  `track` AS t
	WHERE r.`idissue` = t.`idissue` 
	AND r.`received` =  '0'
	AND t.`status` =  '1'
	AND  t.`todept` =  '$iddepartment'
	AND t.`tosection` = '$idsection'";
        $data = $this->CustomQuery($sql);
        return $data;
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////
    function counttotalpendingfile()
    {
        $iddepartment = $_SESSION['luser']['iddepartment'];
        $idsection = $_SESSION['luser']['idsection'];
        $sql = "SELECT COUNT(t.idissue) AS totpendingfile
	FROM  `track` AS t, `receive` as r
	WHERE t.`idissue` = r.`idissue` 
	AND t.`status` =  '1'
	AND r.`received` = '1'
	AND t.`todept` =  '$iddepartment'
	AND t.`tosection` = '$idsection'";
        $data = $this->CustomQuery($sql);
        return $data;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////
    public function countAll_disposedoff()
    {
        $iddepartment = $_SESSION['luser']['iddepartment'];
        $idsection = $_SESSION['luser']['idsection'];
        $sql = "SELECT COUNT( 1 ) AS countAll_disposedoff
	FROM  `track` AS t
	WHERE  t.`idfilestatus` =  '2'
	AND t.`status` =  '0'
	AND t.`todept` =  '$iddepartment'
	AND t.`tosection` =  '$idsection'";
        $data = $this->CustomQuery($sql);
        return $data;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////
    function getSepcificGender($genid)
    {

        $sql = "SELECT * FROM gen_gender where gender_id='" . $genid . "'";
        $data = $this->CustomQuery($sql);
        return $data;
    }

    function updateGender($genid)
    {
        extract($_POST);
        $sql = "UPDATE  gen_gender set gender_title='" . $gentitle . "' where gender_id='" . $genid . "' ";
        unset($_POST);

        $this->success = "Gender has been updated successfully";
        return $this->CustomModify($sql);


    }

    function deleteGender($gid)
    {
        $this->deleteRecord("gen_gender", "gender_id=" . $gid);
        return true;
    }

    function addDesignation()
    {
        extract($_POST);
        $query = mysql_query("SELECT * FROM gen_designations where designation_title='" . $designation_title . "'");
        $row = mysql_fetch_array($query);
        if (empty($designation_title)) {
            return $this->error = "Please Enter title";

        } else {
            if (empty($row['designation_title'])) {
                $insert = "designation_title";
                $vals = "'" . mysql_real_escape_string($designation_title) . "'";
                $id = $this->InsertRecord("gen_designations", $insert, $vals);
                unset($_POST);
                $this->success = "Designation has been added successfully";
                return $id;
            } else
                return $this->success = "Designation already exists";
        }
    }

    function getAllDesignation($start, $limit, $q)
    {
        $sql = "SELECT * FROM gen_designations $q order by designation_title LIMIT " . $start . ", " . $limit;
        $data = $this->CustomQuery($sql);
        if (empty($data)) {
            $data = array();
        }
        return $data;
    }

    function countAllDesignation()
    {
        $sql = "SELECT * FROM gen_designations";
        $data = $this->totalRecordsInQuery($sql);
        return $data;
    }

    function deleteDesignation($did)
    {
        $this->deleteRecord("gen_designations", "designation_id=" . $did);
        return true;
    }

    function getSepcificDesignation($desid)
    {
        $sql = "SELECT * FROM gen_designations where designation_id='" . $desid . "'";
        $data = $this->CustomQuery($sql);
        return $data;
    }

    function updateDesignation($desid)
    {
        extract($_POST);
        $sql = "UPDATE  gen_designations set designation_title='" . $designation_title . "' where designation_id='" . $desid . "' ";
        unset($_POST);

        $this->success = "Designations has been updated successfully";
        return $this->CustomModify($sql);


    }

    function getAllGroups($q)
    {
        $sql = "SELECT * FROM um_groups $q ORDER BY group_title";
        $data = $this->CustomQuery($sql);
        return $data;
    }

    function getGroup($id)
    {
        $data = $this->GetRecord('um_groups', 'group_id', $id);
        return $data;
    }

    function addGroup()
    {
        extract($_POST);
        if (empty($group_title)) {
            return $this->error = "Please Enter title";
        } else {
            $insert = "group_title";
            $vals = "'" . mysql_real_escape_string($group_title) . "'";
            $id = $this->InsertRecord("um_groups", $insert, $vals);
            unset($_POST);
            $this->success = "Group title been added successfully";
            return $id;
        }
    }

    function updateGroup()
    {
        extract($_POST);
        $sql = "UPDATE um_groups SET group_title = '$group_title' WHERE group_id = $group_id ";
        $this->CustomModify($sql);

    }

    function deleteGroup($id)
    {
        $this->deleteRecord("um_groups", "group_id=" . $id);
        return true;
    }

    public function getGroupDD($name, $selected, $text, $options)
    {
        $groups = $this->getAllGroups("");
        $html = "<select name='$name' id='$name' $options >";

        $html .= "<option value='0'>$text</option>";

        foreach ($groups as $g) {
            $selected_item = '';
            if ($selected == $g['group_id']) {
                $selected_item = "selected='selected'";
            }
            $html .= "<option $selected_item value='" . $g['group_id'] . "'>" . $g['group_title'] . "</option>";
        }


        $html .= "</select>";
        return $html;
    }

    public function getChildMenus($menus, $id)
    {
        $data = array();
        foreach ($menus as $m) {
            if ($m['parent_id'] == $id) {

                $data[] = array(
                    'id' => $m['menu_id'],
                    'title' => $m['menu_text'],
                    'href' => $m['url'],
                    'parent' => $m['parent_id'],
                    'order' => $m['sort_order']
                );
            }
        }
        return $data;
    }

    public function mainNavigation()
    {

        $group = $_SESSION['luser']['group'];
        $sql = "SELECT * FROM um_menu as u 
			LEFT JOIN um_permissions as p ON (p.menu_id = u.menu_id)
			where u.show_in_menu = 1 
			AND
			p.group_id = $group
			AND 
			p.pview = 1
		order by u.sort_order";
        if ($_SESSION['luser']['admin'] == 1) {
            $sql = "SELECT * FROM um_menu as u 
				where u.show_in_menu = 1 
				order by u.sort_order";
        }
        $data = $this->CustomQuery($sql);

        $menus = array();
        foreach ($data as $m) {
            $parent = $m['parent_id'];
            if ($m['parent_id'] == 0) {
                $menus[] = array(
                    'id' => $m['menu_id'],
                    'title' => $m['menu_text'],
                    'href' => $m['url'],
                    'parent' => $m['parent_id'],
                    'order' => $m['sort_order'],
                    'child' => $this->getChildMenus($data, $m['menu_id'])
                );
            }
        }
        return $menus;
    }

    /**
     *
     * Enter description here ...
     * @param unknown_type $name
     * @param unknown_type $id
     * @param unknown_type $select
     * @param unknown_type $selected
     * @param unknown_type $text
     */
    function getGenderDD($name, $id, $select, $selected, $text)
    {
        $sql = "SELECT * FROM gen_gender order by gender_title ";
        $values = $this->CustomQuery($sql);
        $html = "<select name='$name' id='$name' $text >";
        $html .= "<option value='0'>$select</option>";
        foreach ($values as $value) {
            $selected_item = '';
            if ($selected == $value['gender_id']) {
                $selected_item = "selected='selected'";
            }
            $html .= "<option $selected_item value='" . $value['gender_id'] . "'>" . $value['gender_title'] . "</option>";
        }
        $html .= "</select>";
        return $html;
    }

    /**
     *
     * Enter description here ...
     * @param $name
     * @param $id
     * @param $select
     * @param $selected
     * @param $text
     */
    function getDesignationDD($name, $id, $select, $selected, $text)
    {
        $sql = "SELECT * FROM gen_designations order by designation_title ";
        $values = $this->CustomQuery($sql);
        $html = "<select name='$name' id='$name' $text >";
        $html .= "<option value='0'>$select</option>";
        foreach ($values as $value) {
            $selected_item = '';
            if ($selected == $value['designation_id']) {
                $selected_item = "selected='selected'";
            }
            $html .= "<option $selected_item value='" . $value['designation_id'] . "'>" . $value['designation_title'] . "</option>";
        }
        $html .= "</select>";
        return $html;
    }

    /**
     *
     * Enter description here ...
     * @param unknown_type $name
     * @param unknown_type $id
     * @param unknown_type $select
     * @param unknown_type $selected
     * @param unknown_type $text
     */

    function getCountryDD($name, $id, $select, $selected, $text)
    {
        $sql = "SELECT * FROM countries order by countries_name ";
        $values = $this->CustomQuery($sql);
        $html = "<select name='$name' id='$name' $text >";
        $html .= "<option value='0'>$select</option>";
        foreach ($values as $value) {
            $selected_item = '';
            if ($selected == $value['countries_id']) {
                $selected_item = "selected='selected'";
            }
            $html .= "<option $selected_item value='" . $value['countries_id'] . "'>" . $value['countries_name'] . "</option>";
        }
        $html .= "</select>";
        return $html;
    }

    public function getFileTypes($q)
    {
        $sql = "SELECT * FROM filetype 
				$q
				";
        $data = $this->CustomQuery($sql);
        return $data;
    }

    public function getFileType($name, $selected, $text, $options)
    {
        $filetype = $this->getFileTypes("");
        $html = "<select name='$name' id='$name' $options >";
        $html .= "<option value=''>$text</option>";
        foreach ($filetype as $ft) {
            $selected_item = '';
            if ($selected == $ft['idfiletype']) {
                $selected_item = "selected='selected'";
            }
            $html .= "<option $selected_item value='" . $ft['idfiletype'] . "'>" . $ft['filetype'] . "</option>";
        }
        $html .= "</select>";
        return $html;
    }

    public function getFileStatuses($q)
    {
        $sql = "SELECT * FROM filestatus 
				$q
				";
        $data = $this->CustomQuery($sql);
        return $data;
    }

    public function getFileStatus($name, $selected, $text, $options)
    {
        $filestatus = $this->getFileStatuses("");
        $html = "<select name='$name' id='$name' $options >";
        $html .= "<option value='0'>$text</option>";
        foreach ($filestatus as $ft) {
            $selected_item = '';
            if ($selected == $ft['idfilestatus']) {
                $selected_item = "selected='selected'";
            }
            $html .= "<option $selected_item value='" . $ft['idfilestatus'] . "'>" . $ft['filestatus'] . "</option>";
        }
        $html .= "</select>";
        return $html;
    }

    public function getsource($q)
    {
        $sql = "SELECT * FROM source 
				$q
				";
        $data = $this->CustomQuery($sql);
        return $data;
    }

    public function getsources($name, $selected, $text, $options)
    {
        $source = $this->getsource("");
        $html = "<select name='$name' id='$name' $options >";
        $html .= "<option value='0'>$text</option>";
        foreach ($source as $s) {
            $selected_item = '';
            if ($selected == $s['idsource']) {
                $selected_item = "selected='selected'";
            }
            $html .= "<option $selected_item value='" . $s['idsource'] . "'>" . $s['source'] . "</option>";
        }
        $html .= "</select>";
        return $html;
    }

    public function getstatus($q)
    {
        $sql = "SELECT * FROM `filestatus` 
				$q
				";
        $data = $this->CustomQuery($sql);
        return $data;
    }

    public function getstat($name, $selected, $text, $options)
    {
        $status = $this->getstatus("");
        $html = "<select name='$name' id='$name' $options >";
        $html .= "<option value='0'>$text</option>";
        foreach ($status as $s) {
            $selected_item = '';
            if ($selected == $s['idfilestatus']) {
                $selected_item = "selected='selected'";
            }
            $html .= "<option $selected_item value='" . $s['idfilestatus'] . "'>" . $s['filestatus'] . "</option>";
        }
        $html .= "</select>";
        return $html;
    }

    public function getDepartment($q)
    {
        $sql = "SELECT * FROM department  
				$q
				";
        $data = $this->CustomQuery($sql);
        return $data;
    }

    public function getdept($name, $selected, $text, $options)
    {
        $department = $this->getDepartment("");
        $html = "<select name='$name' id='$name' $options  >";
        $html .= "<option value='0'>$text</option>";
        foreach ($department as $dept) {
            $selected_item = '';
            if ($selected == $dept['iddepartment']) {
                $selected_item = "selected='selected'";
            }
            $html .= "<option $selected_item value='" . $dept['iddepartment'] . "'>" . $dept['department'] . "</option>";
        }
        $html .= "</select>";
        return $html;
    }

    public function getsections($q)
    {
        $sql = "SELECT * FROM section 
				$q
				";
        $data = $this->CustomQuery($sql);
        return $data;
    }

    public function getsection($name, $selected, $text, $options)
    {
        $department = $this->getsections("");
        $html = "<select name='$name' id='$name' $options >";
        $html .= "<option value='0'>$text</option>";
        foreach ($department as $dept) {
            $selected_item = '';
            if ($selected == $dept['idsection']) {
                $selected_item = "selected='selected'";
            }
            $html .= "<option $selected_item value='" . $dept['idsection'] . "'>" . $dept['section'] . "</option>";
        }
        $html .= "</select>";
        return $html;
    }

    public function getflag($q)
    {
        $sql = "SELECT * FROM flag 
				$q
				";
        $data = $this->CustomQuery($sql);
        return $data;
    }

    public function getflags($name, $selected, $text, $options)
    {
        $flag = $this->getflag("");
        $html = "<select name='$name' id='$name' $options >";
        $html .= "<option value=''>$text</option>";
        foreach ($flag as $fg) {
            $selected_item = '';
            if ($selected == $fg['idflag']) {
                $selected_item = "selected='selected'";
            }
            $html .= "<option $selected_item value='" . $fg['idflag'] . "'>" . $fg['flag'] . "</option>";
        }
        $html .= "</select>";
        return $html;
    }

    public function add_new_file()
    {
        extract($_POST);
       // echo "<pre>";
       // print_r($_POST);
       // exit;
        $fromdept = $_SESSION['luser']['iddepartment'];
        $fromsection = $_SESSION['luser']['idsection'];
        $check = mysql_query("SELECT `barcode` FROM `issue` WHERE `barcode`='$barcode'");
        if (mysql_num_rows($check) > 0) {
            return "Test not added successfully!";
        } else {
            $ip = getenv("REMOTE_ADDR");
            $datetime = date("Y-m-d H:i:s");
            $idusers = $_SESSION['luser']['idusers'];

            foreach ($tosection as $m) {
                $sql = mysql_query("INSERT INTO `issue` SET `barcode`='$barcode', `fileno`='$fileno', `dairyno`='$dairyno', `subject`='$subject', `remarks`='$remarks', `idfiletype`='$idfiletype', `idfilestatus`='1', `idflag`='$idflag', `idsource`='1', `idvolume`='$idvolume', `fromdept`='$fromdept', `fromsection`='$fromsection', `todept`='$todept', `tosection`='$m', `datetime`='$datetime', `ip`='$ip', `idusers`='$idusers'");
                //echo $sql;
                $idissue = mysql_insert_id();
                $sqllog = mysql_query("INSERT INTO `track` SET `idissue`='$idissue', `fromdept`='$fromdept', `fromsection`='$fromsection', `todept`='$todept', `tosection`='$m', `remarks`='$remarks', `idfilestatus`='1', `datetime`='$datetime', `ip`='$ip', `idusers`='$idusers'");
                $sqlrecieved = mysql_query("INSERT INTO `receive` SET `idissue`='$idissue', `received`='0', `datetime`='$datetime', `status`=1");
            }
          //   exit;
            for ($i = 0; $i < count($_FILES['image']['name']); $i++) {
                //Get the temp file path
                $tmpFilePath = $_FILES['image']['tmp_name'][$i];
                //Make sure we have a filepath
                if ($tmpFilePath != "") {
                    //Setup our new file path
                    $newFilePath = "./upload/" . $_FILES['image']['name'][$i];
                    //Upload the file into the temp dir
                    if (move_uploaded_file($tmpFilePath, $newFilePath)) {

                        $sqlattachment = mysql_query("INSERT INTO `attachment` SET `idissue`='$idissue', `path`='$newFilePath'");

                    }
                }
            }

            return "Test added successfully!";

        }
    }

    ///////////////////////////////////////////////////////////////////////
    public function update_file($idissue)
    {
        extract($_POST);
        $ip = getenv("REMOTE_ADDR");
        $date = date("Y-m-d", strtotime($date));
        $time = date('H:i:s');
        $datetime = $date . ' ' . $time;
        $idusers = $_SESSION['luser']['idusers'];
        $fromdept = $_SESSION['luser']['iddepartment'];
        $fromsection = $_SESSION['luser']['idsection'];

        foreach ($tosection as $m) {
            $sqlissue = mysql_query("UPDATE `issue` SET `idfilestatus`='$idfilestatus' WHERE `idissue`='$idissue'");
            $sqltrack = mysql_query("UPDATE `track` SET `status`='0' WHERE `idissue`='$idissue' AND `status`=1");
            $sqlur = mysql_query("UPDATE `receive` SET `status`='0' WHERE `idissue`='$idissue' AND `status`=1");
            $sqllog = mysql_query("INSERT INTO `track` SET `idissue`='$idissue', `fromdept`='$fromdept', `fromsection`='$fromsection', `todept`='$todept', `tosection`='$m', `remarks`='$remarks', `idfilestatus`='$idfilestatus', `datetime`='$datetime', `ip`='$ip', `idusers`='$idusers'");
            $sqlrecieved = mysql_query("INSERT INTO `receive` SET `idissue`='$idissue', `received`='0', `datetime`='$datetime', `status`=1");
        }
        for ($i = 0; $i < count($_FILES['image']['name']); $i++) {
            //Get the temp file path
            $tmpFilePath = $_FILES['image']['tmp_name'][$i];
            //Make sure we have a filepath
            if ($tmpFilePath != "") {
                //Setup our new file path
                $newFilePath = "./upload/" . $_FILES['image']['name'][$i];
                //Upload the file into the temp dir
                if (move_uploaded_file($tmpFilePath, $newFilePath)) {

                    $sqlattachment = mysql_query("INSERT INTO `attachment` SET `idissue`='$idissue', `path`='$newFilePath'");

                }
            }
        }

        return "Test added successfully!";

    }
}

?>
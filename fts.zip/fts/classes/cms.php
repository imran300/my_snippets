<?php
class Cms extends DBAccess
{
    function Cms()
    {
        $this->connectToDB();
    }
    public function maximum_number()
    {
        $sql  = "SELECT * FROM  opd_pat_reg";
        $data = $this->totalRecordsInQuery_max($sql);
        return $data;
    }
    public function maximum_number_test_1($test)
    {
        $sql = "SELECT IFNULL(MAX(`TNO`),0)+1  AS mx FROM `tests1`
WHERE `PDNO`='$test'";
        
        $data = $this->total_max($sql);
        
        return $data;
    }
    //////////////////////////////////////////
    public function maximum_number_group($g_test, $groups)
    {
        
        $sql = "SELECT IFNULL(MAX(`GNO`),0)+1  AS mx FROM `groups`
WHERE `PDNO`='$g_test' AND TNO='$groups'";
        
        $data = $this->total_max($sql);
        
        return $data;
    }
    public function maximum_number_sgroup($s_test, $child, $sub_child)
    {
        
        $sql = "SELECT IFNULL(MAX(`SGNO`),0)+1  AS mx FROM `sgroups`
WHERE `PDNO`='$s_test' AND TNO='$child' AND GNO='$sub_child'";
        
        $data = $this->total_max($sql);
        
        return $data;
    }
    
    //////////////////////////////////////////
    
    public function addPat()
    {
        $ip       = getenv("REMOTE_ADDR");
        $timezone = "Asia/Karachi";
        
        
        extract($_POST);
        
        $name_c = strtoupper($name);
        
        $date = date('Y-m-d');
        $sql  = "INSERT INTO  opd_pat_reg SET
	                 opd_unique_no ='$opd_unique_no',
	 				 opd_pat_name = '$name_c',
				 	opd_pat_gender = '$gender', 
				 	opd_pat_date= '$date'";
        
        if (mysql_query($sql)) {
            return "User added successfully!";
        } else {
            return "this username is not available!";
        }
        
    }
    ///////////////////////////////////////////////////
    public function add_opd()
    {
        $ip       = getenv("REMOTE_ADDR");
        $timezone = "Asia/Karachi";
        
        
        extract($_POST);
        
        $name_c = strtoupper($name);
        if ($day1 != "-1") {
            $day_one = $day1;
        } else {
            $day_one = "";
        }
        //////////////////////////////////////////FOR DAY2////////////////////////////
        if ($day2 != "-1") {
            $day_two = $day2;
        } else {
            $day_two = "";
        }
        /////////////////FOR DAY 3///////////////////
        if ($day3 != "-1") {
            $day_three = $day3;
        } else {
            $day_three = "";
        }
        /////////////////FOR DAY 4///////////////////
        if ($day3 != "-1") {
            $day_three = $day3;
        } else {
            $day_three = "";
        }
        /////////////////FOR DAY 4///////////////////
        if ($day4 != "-1") {
            $day_four = $day4;
        } else {
            $day_four = "";
        }
        /////////////////FOR DAY 5///////////////////
        if ($day5 != "-1") {
            $day_five = $day5;
        } else {
            $day_five = "";
        }
        /////////////////FOR DAY 6///////////////////
        if ($day6 != "-1") {
            $day_six = $day6;
        } else {
            $day_six = "";
        }
        
        
        
        $date = date('Y-m-d');
        $sql  = "INSERT INTO  opdlist SET
	                 OPD ='$opd_name',
	 				RATE = '$opd_rate',
				 	ROOM = '$opd_room',
					DAY1='$day_one',
					DAY2='$day_two',
					DAY3='$day_three',
					DAY4='$day_four',
					DAY5='$day_five',
					DAY6='$day_six'";
        
        if (mysql_query($sql)) {
            return "User added successfully!";
        } else {
            return "this username is not available!";
        }
        
    }
    ////////////////////////////////////////////////////////////////////////
    public function addTest($no)
    {
        $ip = getenv("REMOTE_ADDR");
        date_default_timezone_set('Asia/karachi');
        $TIME = date("h:i:s", time());
        
        
        extract($_POST);
        $date = date('Y-m-d');
        $sql  = "INSERT INTO  tests1 SET
                    TNO='$no',	 
	                PDNO='$test',
	 				TNAME = '$t_name',
				 	NORMAL_FR = '$nor_fr',
					NORMAL_TO='$nor_to',
					UNIT='$unit',
					RATE ='$rate',
					COST='$cost',
					SPNO='$sp_no',
					SCHRGS='$s_charges',
					HEXP='$hexp',
					IPP_RATE='$ipp_rate'";
        
        
        if (mysql_query($sql)) {
            return "Test added successfully!";
        } else {
            return "this Test is not available!";
        }
        
    }
    //////////////////////////////////////////////////////
    
    public function addTest_groups($no_max)
    {
        $ip = getenv("REMOTE_ADDR");
        date_default_timezone_set('Asia/karachi');
        $TIME = date("h:i:s", time());
        
        
        extract($_POST);
        $date = date('Y-m-d');
        $sql  = "INSERT INTO  groups SET	 
	                PDNO='$g_test',
					TNO='$groups',
					GNO='$no_max',
	 				GNAME = '$g_name',
				 	NORMAL_FR = '$g_nor_f',
					NORMAL_TO='$g_nor_to',
					UNIT='$g_unit',
					RATE ='$g_rate',
					COST='$g_cost',
					SPNO='$g_sp_no'";
        if (mysql_query($sql)) {
            return "Test added successfully!";
        } else {
            return "this Test is not available!";
        }
        
    }
    public function addTest_sub_groups($no_max_sub)
    {
        $ip = getenv("REMOTE_ADDR");
        date_default_timezone_set('Asia/karachi');
        $TIME = date("h:i:s", time());
        
        
        extract($_POST);
        $date = date('Y-m-d');
        $sql  = "INSERT INTO  sgroups SET	 
	                PDNO='$s_test',
					TNO='$child',
					GNO='$sub_child',
					SGNO='$no_max_sub',
	 				SGNAME = '$s_name',
				 	NORMAL_FR = '$s_nor_f',
					NORMAL_TO='$s_nor_to',
					UNIT='$s_unit',
					RATE ='$s_rate',
					COST='$s_cost',
					SPNO='$s_sp_no'";
        if (mysql_query($sql)) {
            return "Test added successfully!";
        } else {
            return "this Test is not available!";
        }
        
    }
    
    
    /////////////////////////////////////////////////
    public function addC_test()
    {
        $ip = getenv("REMOTE_ADDR");
        date_default_timezone_set('Asia/karachi');
        $TIME = date("h:i:s", time());
        
        
        extract($_POST);
        $date = date('Y-m-d');
        $sql  = "INSERT INTO  cardiology SET
	                
	 				c_test_name = '$ctest_name',
				 	c_test_rate = '$ctest_rate',
					time='$TIME',
					date='$date',
					ip='$ip'";
        
        
        if (mysql_query($sql)) {
            return "Test added successfully!";
        } else {
            return "this Test is not available!";
        }
        
    }
    //////////////////////////////////////////////
    public function addCat()
    {
        $ip = getenv("REMOTE_ADDR");
        date_default_timezone_set('Asia/karachi');
        $TIME    = date("h:i:s", time());
        $user_id = $_SESSION['luser']['id'];
        
        
        extract($_POST);
        $date = date('Y-m-d');
        $sql  = "INSERT INTO  phar_category SET
	                
	 				cat_name = '$cat_name',
				 	user_id = '$user_id',
					time='$TIME',
					date='$date',
					ip='$ip'";
        
        
        if (mysql_query($sql)) {
            return "Category added successfully!";
        } else {
            return "this Category is not available!";
        }
        
        
    }
    /////////////////////////////////////////////
    public function addUltra()
    {
        extract($_POST);
        $ip = getenv("REMOTE_ADDR");
        date_default_timezone_set('Asia/karachi');
        $TIME    = date("h:i:s", time());
        $user_id = $_SESSION['luser']['id'];
        $date    = date('Y-m-d');
        $sql     = "INSERT INTO  ultrasound_type SET  
	 				ultra_type = '$ultra_type',
				 	user_id = '$user_id',
					time='$TIME',
					date='$date',
					ip='$ip'";
        
        
        if (mysql_query($sql)) {
            return "Ultrasound added successfully!";
        } else {
            return "this Ultrasound is not available!";
        }
        
        
    }
    
    //////////////////////////////////////////////
    public function add_generic_drug()
    {
        $ip = getenv("REMOTE_ADDR");
        date_default_timezone_set('Asia/karachi');
        $TIME    = date("h:i:s", time());
        $user_id = $_SESSION['luser']['id'];
        
        
        extract($_POST);
        $date = date('Y-m-d');
        $sql  = "INSERT INTO  phar_generic_drug SET
	                
	 				generic_drug_name = '$generic_drug_name',
				 	user_id = '$user_id',
					time='$TIME',
					date='$date',
					ip='$ip'";
        
        
        if (mysql_query($sql)) {
            return "Generic drugs added successfully!";
        } else {
            return "this Generic drugs is not available!";
        }
        
        
    }
    
    //////////////////////////////////////////////
    public function addComp()
    {
        $ip = getenv("REMOTE_ADDR");
        date_default_timezone_set('Asia/karachi');
        $TIME    = date("h:i:s", time());
        $user_id = $_SESSION['luser']['id'];
        
        
        extract($_POST);
        $date = date('Y-m-d');
        $sql  = "INSERT INTO  phar_company SET
	 				comp_name = '$comp_name',
					address = '$address',
				 	user_id = '$user_id',
					time='$TIME',
					date='$date',
					ip='$ip'";
        
        
        if (mysql_query($sql)) {
            return "Company added successfully!";
        } else {
            return "this Company is not available!";
        }
        
        
    }
    
    //////////////////////////////////////////////
    public function addSupplier()
    {
        $ip = getenv("REMOTE_ADDR");
        date_default_timezone_set('Asia/karachi');
        $TIME    = date("h:i:s", time());
        $user_id = $_SESSION['luser']['id'];
        
        
        extract($_POST);
        $date = date('Y-m-d');
        $sql  = "INSERT INTO  phar_supplier SET
	 				sup_name = '$sup_name',
					sup_address='$sup_address',
					city = '$city',
					phone = '$phone',
					comp_id = '$comp_id',
				 	user_id = '$user_id',
					time='$TIME',
					date='$date',
					ip='$ip'";
        
        
        if (mysql_query($sql)) {
            return "Supplier added successfully!";
        } else {
            return "this Supplier is not available!";
        }
        
        
    }
    ///////////////////////////////////////////////
    public function show_ultra()
    {
        $sql  = "SELECT * FROM  `ultrasound_type`";
        $data = $this->CustomQuery($sql);
        return $data;
    }
    public function add_ultra_record()
    {
        if (isset($_POST['submit']) == 'save') {
            extract($_POST);
            $id      = $_POST['opd_no'];
            $gen     = $_POST['gen'];
            $comment = nl2br($_POST['comment']);
            $ip      = getenv('REMOTE_ADDR');
            $date    = date('Y-m-d');
            $time    = date('H:i:s');
            $user_id = $_SESSION['luser']['id'];
            $insert  = "INSERT INTO `pat_ultra_result` SET `opd_no`='$id', `ultra_id`='$ultra_id', `result`='$result', `comment`='$comment', `extra_area`='$extra_area', `doctor`='$doctor', `gender`='$gen', `ip`='$ip', `date`='$date', `time`='$time', `user_id`='$user_id'";
            if (mysql_query($insert)) {
?>
                <script>window.open("report/ultra_report_a.php?id=<?= $id; ?>&gender=<?= $gen; ?>");</script>
                <?php
            }
        }
    }
    /////////////////////////////////////////////////////////////////////
    public function show_ultra_report_a($id, $gender)
    {
        extract($_POST);
        $sql  = "SELECT p.opd_no as id, o.name AS name, u.ultra_type AS type , p.result AS result, p.comment AS comment , p.extra_area AS extra, p.doctor AS doctor, p.date AS date, p.time AS time
FROM `pat_ultra_result` AS p, `ultrasound_type` AS u, `opd` AS o
WHERE p.opd_no = o.YEAR
AND p.ultra_id = u.ultra_id
AND p.opd_no = '$id'
AND p.gender = o.SEX
AND p.gender = '$gender'";
        $data = $this->CustomQuery($sql);
        return $data;
    }
    /////////////////////////////////////////////////////////////////////
    public function add_ultra_female_record()
    {
        if (isset($_POST['submit1']) == 'save1') {
            extract($_POST);
            $id      = $_POST['opd_no'];
            $comment = nl2br($_POST['comment']);
            $gen     = $_POST['gen'];
            $ip      = getenv('REMOTE_ADDR');
            $date    = date('Y-m-d');
            $time    = date('H:i:s');
            $user_id = $_SESSION['luser']['id'];
            $insert  = "INSERT INTO `pat_ultra_female` SET `opd_no`='$id', `ultra_name`='$ultra_name', `size`='$size', `liquor`='$liquor', `fetus`='$fetus', `location`='$location', `presentation`='$presentation', `crl`='$crl', `lie`='$lie', `bpd`='$bpd', `position`='$position', `length`='$length', `spine`='$spine', `hc`='$hc', `hb`='$hb', `ac`='$ac', `movement`='$movement', `hcac`='$hcac', `stomach`='$stomach', `weight`='$weight', `bladder`='$bladder', `gestation`='$gestation', `doctor`='$doctor1', comment='$comment1', `gender`='$gen', `ip`='$ip', `date`='$date', `time`='$time', `user_id`='$user_id'";
            if (mysql_query($insert)) {
?>
                <script>window.open("report/ultra_report_b.php?id=<?= $id; ?>&gender=<?= $gen; ?>");</script>
                <?php
            }
        }
    }
    //////////////////////////////////////////////////////////////////////////////////
    public function show_ultra_report_b($id, $gender)
    {
        extract($_POST);
        $sql  = "SELECT * 
FROM  `pat_ultra_female` AS p, `opd` AS o
WHERE p.opd_no = o.YEAR
AND p.opd_no = '$id'
AND p.gender = o.SEX
AND p.gender='$gender'";
        $data = $this->CustomQuery($sql);
        return $data;
    }
    //////////////////////////////////////////////
    public function adddrug_master()
    {
        $ip = getenv("REMOTE_ADDR");
        date_default_timezone_set('Asia/karachi');
        $TIME    = date("h:i:s", time());
        $user_id = $_SESSION['luser']['id'];
        
        
        extract($_POST);
        $date = date('Y-m-d');
        $sql  = "INSERT INTO  phar_drug_master SET
	 				drug_name = '$drug_name',
					masmcode='$masmcode',
					generic_id = '$generic_id',
					cat_id = '$cat_id',
					unit = '$unit',
					reorder_level = '$reorder_level',
				 	user_id = '$user_id',
					time='$TIME',
					date='$date',
					ip='$ip'";
        
        
        if (mysql_query($sql)) {
            return "Drug Master added successfully!";
        } else {
            return "this Drug Master is not available!";
        }
        
        
    }
    
    //////////////////////////////////////////////
    public function additem()
    {
        extract($_POST);
        $ip = getenv("REMOTE_ADDR");
        date_default_timezone_set('Asia/karachi');
        $TIME    = date("h:i:s", time());
        $user_id = $_SESSION['luser']['id'];
        
        
        
        $date    = date('Y-m-d');
        $mdate1  = date('Y-m-d', strtotime($mdate));
        $expiry1 = date('Y-m-d', strtotime($expiry));
        $sql     = "INSERT INTO  phar_item SET
	 				item_name = '$item_name',
					item_desc = '$item_desc',
					sup_id='$sup_id',
					cat_id = '$cat_id',
					quantity = '$quantity',
					ini_qty = '$quantity',
					costprice = '$costprice',
					unitprice = '$unitprice',
					mdate = '$mdate1',
					expiry = '$expiry1',
					location = '$location',
				 	user_id = '$user_id',
					time='$TIME',
					date='$date',
					ip='$ip'";
        
        if (mysql_query($sql)) {
            return "Item added successfully!";
        } else {
            return "this item is not available!";
        }
        
        
    }
    
    //////////////////////////////////////////////
    public function addX_Ray()
    {
        $ip = getenv("REMOTE_ADDR");
        date_default_timezone_set('Asia/karachi');
        $TIME = date("h:i:s", time());
        
        
        extract($_POST);
        $date = date('Y-m-d');
        $sql  = "INSERT INTO  x_ray SET
	                
	 				x_test_name = '$x_name',
				 	x_test_rate = '$x_rate',
					time='$TIME',
					date='$date',
					ip='$ip'";
        
        
        if (mysql_query($sql)) {
            return "Test added successfully!";
        } else {
            return "this Test is not available!";
        }
        
    }
    //////////////////////////////////////////////
    public function add_med()
    {
        $ip = getenv("REMOTE_ADDR");
        date_default_timezone_set('Asia/karachi');
        $TIME = date("h:i:s", time());
        extract($_POST);
        $date = date('Y-m-d');
        $sql  = "INSERT INTO  medicines SET med_name='$m_name'";
        if (mysql_query($sql)) {
            return "Test added successfully!";
        } else {
            return "this Test is not available!";
        }
        
    }
    ////////////////////////////////////////////////////////////////
    public function addCT_scan()
    {
        $ip = getenv("REMOTE_ADDR");
        date_default_timezone_set('Asia/karachi');
        $TIME = date("h:i:s", time());
        
        
        extract($_POST);
        $date = date('Y-m-d');
        $sql  = "INSERT INTO  ct_scan SET
	                
	 				ct_test_name = '$ct_name',
				 	ct_test_rate = '$ct_rate',
					time='$TIME',
					date='$date',
					ip='$ip'";
        
        
        if (mysql_query($sql)) {
            return "Test added successfully!";
        } else {
            return "this Test is not available!";
        }
        
    }
    
    //////////////////////////////////////////////////////////////////////////////////////////
    public function adddept()
    {
        extract($_POST);
        $sql = "INSERT INTO `department` SET
	 				department = '$department'";
        if (mysql_query($sql)) {
            return "Department added successfully!";
        } else {
            return "this Test is not available!";
        }
        
    }
    public function addsection()
    {
        extract($_POST);
        $sql = "INSERT INTO `section` SET
	 				section = '$section',
					iddept = '$iddept'";
        if (mysql_query($sql)) {
            return "Section added successfully!";
        } else {
            return "this Test is not available!";
        }
        
    }
    
    //////////////////////////////////////////////////////////////////////////////////////////
    public function addfiletype()
    {
        extract($_POST);
        $sql = "INSERT INTO `file_type` SET
	 				`file_type` = '$filetype'";
        if (mysql_query($sql)) {
            return "File type added successfully!";
        } else {
            return "this Test is not available!";
        }
        
    }
    
    //////////////////////////////////////////////////////////////////////////////////////////
    public function addflag()
    {
        extract($_POST);
        $sql = "INSERT INTO `flag` SET
	 				`flag` = '$flag'";
        if (mysql_query($sql)) {
            return "Flag added successfully!";
        } else {
            return "this Test is not available!";
        }
        
    }
    
    //////////////////////////////////////////////////////////////////////////////////////////
    public function addstatus()
    {
        extract($_POST);
        $sql = "INSERT INTO `status` SET
	 				`status` = '$status'";
        if (mysql_query($sql)) {
            return "Status added successfully!";
        } else {
            return "this Test is not available!";
        }
        
    }
    public function addsource()
    {
        extract($_POST);
        $sql = "INSERT INTO `source` SET
	 				`source` = '$source'";
        if (mysql_query($sql)) {
            return "Source added successfully!";
        } else {
            return "this Test is not available!";
        }
        
    }
    
    //////////////////////////////////////////////////////////////////////////////////////////
    public function GetallUsers()
    {
        
        $sql = "SELECT * FROM um_users";
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    ///////////////////////////
    public function GetallUsers_opd()
    {
        $sql = "SELECT u.user_id AS id, u.username AS user
FROM um_users AS u, um_groups AS g
WHERE u.group_id = g.group_id
AND g.group_title = 'opd'";
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    ///////////////////////////
    public function getAllPdept()
    {
        
        $sql = "SELECT * FROM pdept";
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    /////////////////////////////////////
    public function countAll_ward()
    {
        $user_id = $_SESSION['luser']['id'];
        $sql     = "SELECT * FROM phar_ward";
        $data    = $this->totalRecordsInQuery($sql);
        return $data;
    }
    public function getAllWard($start, $limit, $q)
    {
        $user_id = $_SESSION['luser']['id'];
        
        $sql = "SELECT * FROM phar_ward $q LIMIT " . $start . "," . $limit;
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    /////////////
    public function countAll_pat($user_id)
    {
        $date = date("Y");
        if ($user_id != 4) {
            $sql  = "SELECT * FROM opd where USER_ID='$user_id' and opddate like '$date%'";
            $data = $this->totalRecordsInQuery($sql);
            return $data;
        } else {
            $sql  = "SELECT * FROM opd where opddate like '$date%'";
            $data = $this->totalRecordsInQuery($sql);
            return $data;
        }
    }
    public function getAllPat($start, $limit, $q, $user_id)
    {
        //$date=date("Y");
        if ($user_id != 4) {
            $sql  = "SELECT * FROM opd " . $q . " and USER_ID='$user_id'  order by YEAR  ASC LIMIT " . $start . "," . $limit;
            $data = $this->CustomQuery($sql);
            return $data;
        } else {
            $sql  = "SELECT * FROM opd " . $q . " and user_id IN ('10','12','4') order by YEAR  ASC LIMIT " . $start . "," . $limit;
            $data = $this->CustomQuery($sql);
            return $data;
        }
    }
    //////////////OPD LIST///////////////////////
    public function countAll_opd()
    {
        $sql  = "SELECT * FROM opdlist";
        $data = $this->totalRecordsInQuery($sql);
        return $data;
    }
    public function getAllopd($start, $limit, $q)
    {
        
        $sql = "SELECT * FROM opdlist $q order by opd LIMIT " . $start . "," . $limit;
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    //////////////////////////////////////////////////////////////////////////////////////////
    public function countAll_test()
    {
        $sql  = "SELECT * FROM tests1";
        $data = $this->totalRecordsInQuery($sql);
        return $data;
    }
    /////////////////////////////////////////////////
    public function countAll_dept()
    {
        $sql  = "SELECT * FROM `department`";
        $data = $this->totalRecordsInQuery($sql);
        return $data;
    }
    /////////////////////////////////////////////////
    public function countAll_section()
    {
        $sql  = "SELECT * FROM `section`";
        $data = $this->totalRecordsInQuery($sql);
        return $data;
    }
    /////////////////////////////////////////////////
    public function countAll_file_type()
    {
        $sql  = "SELECT * FROM `file_type`";
        $data = $this->totalRecordsInQuery($sql);
        return $data;
    }
    /////////////////////////////////////////////////
    public function countAll_flag()
    {
        $sql  = "SELECT * FROM `flag`";
        $data = $this->totalRecordsInQuery($sql);
        return $data;
    }
    /////////////////////////////////////////////////
    public function countAll_status()
    {
        $sql  = "SELECT * FROM `status`";
        $data = $this->totalRecordsInQuery($sql);
        return $data;
    }
    public function countAll_source()
    {
        $sql  = "SELECT * FROM `source`";
        $data = $this->totalRecordsInQuery($sql);
        return $data;
    }
    /////////////////////////////////////////////////
    public function getAllTest($start, $limit, $q)
    {
        
        $sql = "SELECT `PDNO`, `TNO`, `TNAME`, `NORMAL_FR`, `NORMAL_TO`, `UNIT` FROM `tests1`";
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    public function getTest1($pdno, $tno, $gno, $sgno)
    {
        if ($gno == '' && $sgno == '') {
            $sql = "SELECT TNAME AS test, NORMAL_FR, NORMAL_TO, UNIT FROM tests1
WHERE pdno='$pdno' AND tno='$tno'";
        }
        if ($sgno == '') {
            $sql = "SELECT GNAME AS test, NORMAL_FR, NORMAL_TO, UNIT FROM groups
WHERE pdno='$pdno' AND tno='$tno'";
        } else {
            $sql = "SELECT SGNAME AS test, NORMAL_FR, NORMAL_TO, UNIT FROM sgroups
WHERE pdno='$pdno' AND tno='$tno' AND gno='$gno' AND sgno='$sgno'";
        }
        $data = $this->CustomQuery($sql);
        return $data;
    }
    
    //////////////////////////////////////
    public function getAllTest2()
    {
        
        $sql = "SELECT t.tno as tid, p.pdno as pid, g.gno as gid, p.pdname as pdname, t.tname as tname, g.gname as gname, g.normal_fr as normal_fr, g.normal_to as normal_to
FROM tests1 AS t, groups AS g, pdept AS p
WHERE g.tno = t.tno
AND g.pdno = t.pdno
AND g.pdno = p.pdno";
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    public function getTest2($id_g)
    {
        
        $sql = "SELECT g.id as id, p.pdname as pdname, t.tname as tname, g.gname as gname, g.normal_fr as normal_fr, g.normal_to as normal_to
FROM tests1 AS t, groups AS g, pdept AS p
WHERE g.tno = t.tno
AND g.pdno = t.pdno
AND g.pdno = p.pdno
AND g.id='$id_g'";
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    /////////////////////////////////////
    public function getAllTest3()
    {
        
        $sql = "SELECT s.id as id, p.pdname as pdname, t.tname as tname, g.gname as gname, s.sgname as sgname, s.normal_fr as normal_fr, s.normal_to as normal_to
FROM sgroups AS s, groups AS g, tests1 AS t, pdept AS p
WHERE s.gno = g.gno
AND s.tno = g.tno
AND g.tno = t.tno
AND s.pdno = g.pdno
AND g.pdno = t.pdno
AND t.pdno = p.pdno";
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    public function getTest3($id_s)
    {
        
        $sql = "SELECT s.id as id, p.pdname as pdname, t.tname as tname, g.gname as gname, s.sgname as sgname, s.normal_fr as normal_fr, s.normal_to as normal_to
FROM sgroups AS s, groups AS g, tests1 AS t, pdept AS p
WHERE s.gno = g.gno
AND s.tno = g.tno
AND g.tno = t.tno
AND s.pdno = g.pdno
AND g.pdno = t.pdno
AND t.pdno = p.pdno
AND s.id='$id_s'";
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    ////////////////////////////////////////////////////////
    public function countAll_comp()
    {
        $sql  = "SELECT * FROM phar_company";
        $data = $this->totalRecordsInQuery($sql);
        return $data;
    }
    public function countAll_issue($idfiletype)
    {
        $iddepartment = $_SESSION['luser']['iddepartment'];
        $idsection    = $_SESSION['luser']['idsection'];
        $sql          = "SELECT COUNT(`issue`.`idissue`) AS tot
FROM
    `issue`
    INNER JOIN `department` 
        ON (`issue`.`fromdept` = `department`.`iddepartment`)
    INNER JOIN `section` 
        ON (`issue`.`fromsection` = `section`.`idsection`)
    INNER JOIN `filestatus` 
        ON (`issue`.`idfilestatus` = `filestatus`.`idfilestatus`)
    INNER JOIN `filetype` 
        ON (`issue`.`idfiletype` = `filetype`.`idfiletype`)
    INNER JOIN `flag` 
        ON (`issue`.`idflag` = `flag`.`idflag`)
    INNER JOIN `source` 
        ON (`issue`.`idsource` = `source`.`idsource`)
    INNER JOIN `volume` 
        ON (`issue`.`idvolume` = `volume`.`idvolume`)
        WHERE `issue`.`idfiletype` = '$idfiletype'
        AND `issue`.`fromdept` = '$iddepartment'
        AND `issue`.`fromsection` = '$idsection';";
        $data         = $this->totalRecordsInQuery($sql);
        return $data;
    }
    
    public function getAllissue($idfiletype)
    {
        $iddepartment = $_SESSION['luser']['iddepartment'];
        $idsection    = $_SESSION['luser']['idsection'];
        $sql          = "SELECT `issue`.`idissue`, `issue`.`datetime`, `issue`.`dairyno`, `issue`.`barcode`, `issue`.`subject`, `department`.`department`, `section`.`section`, `volume`.`volume`, `filestatus`.`filestatus`, `filetype`.`filetype`, `flag`.`flag`
FROM
    `issue`
    INNER JOIN `department` 
        ON (`issue`.`todept` = `department`.`iddepartment`)
    INNER JOIN `section` 
        ON (`issue`.`tosection` = `section`.`idsection`)
    INNER JOIN `filestatus` 
        ON (`issue`.`idfilestatus` = `filestatus`.`idfilestatus`)
    INNER JOIN `filetype` 
        ON (`issue`.`idfiletype` = `filetype`.`idfiletype`)
    INNER JOIN `flag` 
        ON (`issue`.`idflag` = `flag`.`idflag`)
    INNER JOIN `source` 
        ON (`issue`.`idsource` = `source`.`idsource`)
    INNER JOIN `volume` 
        ON (`issue`.`idvolume` = `volume`.`idvolume`)
        WHERE `issue`.`idfiletype` = '$idfiletype'
        AND `issue`.`fromdept` = '$iddepartment'
        AND `issue`.`fromsection` = '$idsection'
        ORDER BY `issue`.`datetime` ASC";
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
	//for issued detail with date and idfiletype perameters
	public function getAllissue_date($idfiletype,$date)
    {
		
        $iddepartment = $_SESSION['luser']['iddepartment'];
        $idsection    = $_SESSION['luser']['idsection'];
        $sql          = "SELECT `issue`.`idissue`, `issue`.`datetime`, `issue`.`dairyno`, `issue`.`barcode`, `issue`.`subject`, `department`.`department`, `section`.`section`, `volume`.`volume`, `filestatus`.`filestatus`, `filetype`.`filetype`, `flag`.`flag`
FROM
    `issue`
    INNER JOIN `department` 
        ON (`issue`.`todept` = `department`.`iddepartment`)
    INNER JOIN `section` 
        ON (`issue`.`tosection` = `section`.`idsection`)
    INNER JOIN `filestatus` 
        ON (`issue`.`idfilestatus` = `filestatus`.`idfilestatus`)
    INNER JOIN `filetype` 
        ON (`issue`.`idfiletype` = `filetype`.`idfiletype`)
    INNER JOIN `flag` 
        ON (`issue`.`idflag` = `flag`.`idflag`)
    INNER JOIN `source` 
        ON (`issue`.`idsource` = `source`.`idsource`)
    INNER JOIN `volume` 
        ON (`issue`.`idvolume` = `volume`.`idvolume`)
        WHERE `issue`.`idfiletype` = '$idfiletype'
        AND `issue`.`fromdept` = '$iddepartment'
        AND `issue`.`fromsection` = '$idsection'
		AND `issue`.`datetime` >= '$date'
        ORDER BY `issue`.`datetime` ASC";
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
//For issued deatil between dates query
public function getAllissue_twodate($idfiletype,$date,$todate)
    {  
	$iddepartment = $_SESSION['luser']['iddepartment'];
        $idsection    = $_SESSION['luser']['idsection'];
        $sql          = "SELECT `issue`.`idissue`, `issue`.`datetime`, `issue`.`dairyno`, `issue`.`barcode`, `issue`.`subject`, `department`.`department`, `section`.`section`, `volume`.`volume`, `filestatus`.`filestatus`, `filetype`.`filetype`, `flag`.`flag`
FROM
    `issue`
    INNER JOIN `department` 
        ON (`issue`.`todept` = `department`.`iddepartment`)
    INNER JOIN `section` 
        ON (`issue`.`tosection` = `section`.`idsection`)
    INNER JOIN `filestatus` 
        ON (`issue`.`idfilestatus` = `filestatus`.`idfilestatus`)
    INNER JOIN `filetype` 
        ON (`issue`.`idfiletype` = `filetype`.`idfiletype`)
    INNER JOIN `flag` 
        ON (`issue`.`idflag` = `flag`.`idflag`)
    INNER JOIN `source` 
        ON (`issue`.`idsource` = `source`.`idsource`)
    INNER JOIN `volume` 
        ON (`issue`.`idvolume` = `volume`.`idvolume`)
        WHERE `issue`.`idfiletype` = '$idfiletype'
        AND `issue`.`fromdept` = '$iddepartment'
        AND `issue`.`fromsection` = '$idsection'
		AND `issue`.`datetime` >= '$date' AND `issue`.`datetime` <= '$todate'
        ORDER BY `issue`.`datetime` ASC";
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
   public function countAll_received($idfiletype)
    {
        $iddepartment = $_SESSION['luser']['iddepartment'];
        $idsection    = $_SESSION['luser']['idsection'];
        $sql          = "SELECT count(`issue`.`idissue`)
FROM
    `track`
    INNER JOIN `issue` 
        ON (`track`.`idissue` = `issue`.`idissue`)    
    INNER JOIN `receive` 
        ON (`track`.`idissue` = `receive`.`idissue`)    
	INNER JOIN `department` 
        ON (`track`.`todept` = `department`.`iddepartment`)
    INNER JOIN `section` 
        ON (`track`.`tosection` = `section`.`idsection`)
    INNER JOIN `filestatus` 
        ON (`track`.`idfilestatus` = `filestatus`.`idfilestatus`)
    INNER JOIN `filetype` 
        ON (`issue`.`idfiletype` = `filetype`.`idfiletype`)
    INNER JOIN `flag` 
        ON (`issue`.`idflag` = `flag`.`idflag`)
    INNER JOIN `source` 
        ON (`issue`.`idsource` = `source`.`idsource`)
    INNER JOIN `volume` 
        ON (`issue`.`idvolume` = `volume`.`idvolume`)
        AND `receive`.`received` = 0
		AND `track`.`status` = 1
	    AND `track`.`todept` = '$iddepartment'        
        AND `track`.`tosection` = '$idsection'
        ORDER BY `issue`.`datetime` ASC;";
        $data         = $this->totalRecordsInQuery($sql);
        return $data;
    }
    
    public function countAll_pending($idfiletype)
    {
        $iddepartment = $_SESSION['luser']['iddepartment'];
        $idsection    = $_SESSION['luser']['idsection'];
        $sql          = "SELECT i.datetime as datetime, i.barcode as barcode, i.subject as subject, f.filetype as filetype, g.flag as flag, d.department as department, s.section as section, r.idissue as idissue, r.idreceive as idreceive, r.received as received, i.scan as scan, t.filestatus as filestatus
		  FROM `receive` as r, `issue` as i, `filetype` as f, flag as g, department as d, section as s, filestatus as t
		  WHERE r.idissue = i.idissue
		  AND i.idfiletype = f.idfiletype
		  AND i.idflag = g.idflag
		  AND i.fromdept = d.iddepartment
		  AND i.fromsection = s.idsection
		  AND i.idfilestatus = t.idfilestatus
		   AND i.idfilestatus = 2
		  AND i.todept='$iddepartment'
		  AND i.tosection='$idsection'
		  ORDER BY `datetime` ASC";
        $data         = $this->totalRecordsInQuery($sql);
        return $data;
    }
    public function countAll_disposedoff()
    {
        $iddepartment = $_SESSION['luser']['iddepartment'];
        $idsection    = $_SESSION['luser']['idsection'];
        $sql          = "SELECT * FROM `receive` as r, issue as i
	WHERE r.idissue = i.idissue 
	AND i.todept = '$iddepartment'
	AND i.tosection = '$idsection'
	AND i.idfilestatus = 2";
        $data         = $this->totalRecordsInQuery($sql);
        return $data;
    }
    
    
    public function getAlldisposedoffdetail()
    {
        $iddepartment = $_SESSION['luser']['iddepartment'];
        $idsection    = $_SESSION['luser']['idsection'];
        $sql          = "SELECT *
FROM
    `track`
    INNER JOIN `issue` 
        ON (`track`.`idissue` = `issue`.`idissue`)
    INNER JOIN `department` 
        ON (`track`.`todept` = `department`.`iddepartment`)
    INNER JOIN `section` 
        ON (`track`.`tosection` = `section`.`idsection`)
    INNER JOIN `filestatus` 
        ON (`issue`.`idfilestatus` = `filestatus`.`idfilestatus`)
    INNER JOIN `filetype` 
        ON (`issue`.`idfiletype` = `filetype`.`idfiletype`)
    INNER JOIN `flag` 
        ON (`issue`.`idflag` = `flag`.`idflag`)
    INNER JOIN `source` 
        ON (`issue`.`idsource` = `source`.`idsource`)
    INNER JOIN `volume` 
        ON (`issue`.`idvolume` = `volume`.`idvolume`)
        AND `track`.`idfilestatus`=2
		 AND `track`.`todept`='$iddepartment'
		  AND `track`.`tosection`='$idsection'
		  ORDER BY `track`.`datetime` ASC";
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    
    
    public function getAllreceived($idfiletype)
    {
        $iddepartment = $_SESSION['luser']['iddepartment'];
        $idsection    = $_SESSION['luser']['idsection'];
        $sql          = "SELECT `issue`.`idissue`, `issue`.`datetime`, `issue`.`dairyno`, `issue`.`barcode`, `issue`.`subject`, `department`.`department`, `section`.`section`, `volume`.`volume`, `filestatus`.`filestatus`, `filetype`.`filetype`, `flag`.`flag`, `receive`.`idreceive`
FROM
    `track`
    INNER JOIN `issue` 
        ON (`track`.`idissue` = `issue`.`idissue`)  
	INNER JOIN `receive` 
        ON (`track`.`idissue` = `receive`.`idissue`)    
    INNER JOIN `department` 
        ON (`track`.`todept` = `department`.`iddepartment`)
    INNER JOIN `section` 
        ON (`track`.`tosection` = `section`.`idsection`)
    INNER JOIN `filestatus` 
        ON (`track`.`idfilestatus` = `filestatus`.`idfilestatus`)
    INNER JOIN `filetype` 
        ON (`issue`.`idfiletype` = `filetype`.`idfiletype`)
    INNER JOIN `flag` 
        ON (`issue`.`idflag` = `flag`.`idflag`)
    INNER JOIN `source` 
        ON (`issue`.`idsource` = `source`.`idsource`)
    INNER JOIN `volume` 
        ON (`issue`.`idvolume` = `volume`.`idvolume`)
        WHERE `issue`.`idfiletype` = '$idfiletype'
		AND `track`.`status` = 1
		AND `receive`.`received` = 0
		AND `receive`.`status` = 1
	    AND `track`.`todept` = '$iddepartment'        
        AND `track`.`tosection` = '$idsection'
        ORDER BY `issue`.`datetime` ASC";
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    
    public function getforwarddetail($idreceive)
    {
        $sql = "SELECT i.fileno as fileno, i.barcode as barcode, i.dairyno as dairyno, i.subject as subject, f.filetype as filetype, g.flag as flag, d.department as department, s.section as section, r.idissue as idissue, r.idreceive as idreceive, r.received as received, i.scan as scan, t.filestatus as filestatus
		  FROM `receive` as r, `issue` as i, `filetype` as f, flag as g, department as d, section as s, filestatus as t
		  WHERE r.idissue = i.idissue
		  AND i.idfiletype = f.idfiletype
		  AND i.idflag = g.idflag
		  AND i.fromdept = d.iddepartment
		  AND i.fromsection = s.idsection
		  AND i.idfilestatus = t.idfilestatus
		  AND r.`idreceive`='$idreceive'";
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    
    public function getAllpending($idfiletype)
    {
        $iddepartment = $_SESSION['luser']['iddepartment'];
        $idsection    = $_SESSION['luser']['idsection'];
        $sql          = "SELECT  `issue`.`barcode` ,  `issue`.`dairyno` ,  `issue`.`fileno` ,  `issue`.`subject` ,  `track`.`datetime`, `track`.`fromdept` ,  `track`.`fromsection` ,  `track`.`remarks` ,  `track`.`todept` ,  `track`.`tosection` ,  `flag`.`flag` , `section`.`section` , `department`.`department`, `filestatus`.`filestatus` , `filetype`.`filetype` ,  `source`.`source` ,  `volume`.`volume`, `receive`.`idissue`, `receive`.`idreceive`, `receive`.`received`
FROM  `receive` 
INNER JOIN  `track` ON (  `receive`.`idissue` =  `track`.`idissue` ) 
INNER JOIN  `issue` ON (  `track`.`idissue` =  `issue`.`idissue` ) 
INNER JOIN  `department` ON (  `track`.`fromdept` =  `department`.`iddepartment` ) 
INNER JOIN  `section` ON (  `track`.`fromsection` =  `section`.`idsection` ) 
INNER JOIN  `filetype` ON (  `issue`.`idfiletype` =  `filetype`.`idfiletype` ) 
INNER JOIN  `filestatus` ON (  `issue`.`idfilestatus` =  `filestatus`.`idfilestatus` ) 
INNER JOIN  `flag` ON (  `issue`.`idflag` =  `flag`.`idflag` ) 
INNER JOIN  `source` ON (  `issue`.`idsource` =  `source`.`idsource` ) 
INNER JOIN  `volume` ON (  `issue`.`idvolume` =  `volume`.`idvolume` ) 
WHERE  `issue`.`idfiletype` ='$idfiletype'
AND  `track`.`status` =1
AND `receive`.`received` = 1
AND `receive`.`status` = 1
		  AND `track`.todept='$iddepartment'
		  AND `track`.tosection='$idsection'
		  GROUP BY `track`.`datetime` ASC";
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    
   //for getting pending records using idfiletype and datetime
 public function getAllpending_date($idfiletype,$date)
    {
        $iddepartment = $_SESSION['luser']['iddepartment'];
        $idsection    = $_SESSION['luser']['idsection'];
        $sql          = "SELECT  `issue`.`barcode` ,  `issue`.`dairyno` ,  `issue`.`fileno` ,  `issue`.`subject` ,  `track`.`datetime`, `track`.`fromdept` ,  `track`.`fromsection` ,  `track`.`remarks` ,  `track`.`todept` ,  `track`.`tosection` ,  `flag`.`flag` , `section`.`section` , `department`.`department`, `filestatus`.`filestatus` , `filetype`.`filetype` ,  `source`.`source` ,  `volume`.`volume`, `receive`.`idissue`, `receive`.`idreceive`, `receive`.`received`
FROM  `receive` 
INNER JOIN  `track` ON (  `receive`.`idissue` =  `track`.`idissue` ) 
INNER JOIN  `issue` ON (  `track`.`idissue` =  `issue`.`idissue` ) 
INNER JOIN  `department` ON (  `track`.`fromdept` =  `department`.`iddepartment` ) 
INNER JOIN  `section` ON (  `track`.`fromsection` =  `section`.`idsection` ) 
INNER JOIN  `filetype` ON (  `issue`.`idfiletype` =  `filetype`.`idfiletype` ) 
INNER JOIN  `filestatus` ON (  `issue`.`idfilestatus` =  `filestatus`.`idfilestatus` ) 
INNER JOIN  `flag` ON (  `issue`.`idflag` =  `flag`.`idflag` ) 
INNER JOIN  `source` ON (  `issue`.`idsource` =  `source`.`idsource` ) 
INNER JOIN  `volume` ON (  `issue`.`idvolume` =  `volume`.`idvolume` ) 
WHERE  `issue`.`idfiletype` ='$idfiletype'
AND  `track`.`status` =1
AND `receive`.`received` = 1
AND `receive`.`status` = 1
		  AND `track`.todept='$iddepartment'
		  AND `track`.tosection='$idsection'
		  AND `track`.datetime>='$date'
		  GROUP BY `track`.`datetime` ASC";
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
	//For Pendinng detail between dates
	public function getAllpending_twodate($idfiletype,$date,$todate)
    {
        $iddepartment = $_SESSION['luser']['iddepartment'];
        $idsection    = $_SESSION['luser']['idsection'];
        $sql          = "SELECT  `issue`.`barcode` ,  `issue`.`dairyno` ,  `issue`.`fileno` ,  `issue`.`subject` ,  `track`.`datetime`, `track`.`fromdept` ,  `track`.`fromsection` ,  `track`.`remarks` ,  `track`.`todept` ,  `track`.`tosection` ,  `flag`.`flag` , `section`.`section` , `department`.`department`, `filestatus`.`filestatus` , `filetype`.`filetype` ,  `source`.`source` ,  `volume`.`volume`, `receive`.`idissue`, `receive`.`idreceive`, `receive`.`received`
FROM  `receive` 
INNER JOIN  `track` ON (  `receive`.`idissue` =  `track`.`idissue` ) 
INNER JOIN  `issue` ON (  `track`.`idissue` =  `issue`.`idissue` ) 
INNER JOIN  `department` ON (  `track`.`fromdept` =  `department`.`iddepartment` ) 
INNER JOIN  `section` ON (  `track`.`fromsection` =  `section`.`idsection` ) 
INNER JOIN  `filetype` ON (  `issue`.`idfiletype` =  `filetype`.`idfiletype` ) 
INNER JOIN  `filestatus` ON (  `issue`.`idfilestatus` =  `filestatus`.`idfilestatus` ) 
INNER JOIN  `flag` ON (  `issue`.`idflag` =  `flag`.`idflag` ) 
INNER JOIN  `source` ON (  `issue`.`idsource` =  `source`.`idsource` ) 
INNER JOIN  `volume` ON (  `issue`.`idvolume` =  `volume`.`idvolume` ) 
WHERE  `issue`.`idfiletype` ='$idfiletype'
AND  `track`.`status` =1
AND `receive`.`received` = 1
AND `receive`.`status` = 1
		  AND `track`.todept='$iddepartment'
		  AND `track`.tosection='$idsection'
		  AND `track`.datetime>='$date' AND `track`.datetime <='$todate'
		  GROUP BY `track`.`datetime` ASC";
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
      //Geting forwarded detail between two dates
	  public function getAllforwarding_twodate($idfiletype,$date,$todate)
    {
        $iddepartment = $_SESSION['luser']['iddepartment'];
        $idsection    = $_SESSION['luser']['idsection'];
        $sql          = "SELECT `issue`.`barcode` ,  `issue`.`dairyno` ,  `issue`.`fileno` ,  `issue`.`subject` ,  `track`.`datetime`,`track`.`idissue` ,
		`track`.`fromdept` ,  `track`.`fromsection` ,  `track`.`remarks` ,  `track`.`todept` ,  `track`.`tosection` ,  `flag`.`flag` ,
		`section`.`section` , `department`.`department`, `filestatus`.`filestatus` , `filetype`.`filetype` ,  `source`.`source` ,  `volume`.`volume`
FROM `track` 

INNER JOIN  `issue` ON (  `track`.`idissue` =  `issue`.`idissue` ) 
INNER JOIN  `department` ON (  `track`.`fromdept` =  `department`.`iddepartment` ) 
INNER JOIN  `section` ON (  `track`.`fromsection` =  `section`.`idsection` ) 
INNER JOIN  `filetype` ON (  `issue`.`idfiletype` =  `filetype`.`idfiletype` ) 
INNER JOIN  `filestatus` ON (  `issue`.`idfilestatus` =  `filestatus`.`idfilestatus` ) 
INNER JOIN  `flag` ON (  `issue`.`idflag` =  `flag`.`idflag` ) 
INNER JOIN  `source` ON (  `issue`.`idsource` =  `source`.`idsource` ) 
INNER JOIN  `volume` ON (  `issue`.`idvolume` =  `volume`.`idvolume` ) 
WHERE  `issue`.`idfiletype`= $idfiletype
AND `track`.fromdept='$iddepartment'
		  AND `track`.fromsection='$idsection'
		  AND `track`.datetime>='$date' AND `track`.datetime <='$todate'
and  `track`.`status`=1
order by track.idissue

";
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
	  
	  
	  
	  
    public function gettrackofidissue($idissue)
    {
        $sql  = "SELECT *
		  FROM `issue` as i, `filetype` as f, flag as g, department as d, section as s , filestatus as t, source as o
		  WHERE i.idfiletype = f.idfiletype
		  AND i.idflag = g.idflag
		  AND i.todept = d.iddepartment
		  AND i.tosection = s.idsection  
		  AND i.`idfiletype`= f.idfiletype
		  AND i.idfilestatus = t.idfilestatus
		  AND i.idsource = o.idsource
		  AND i.`idissue` = '$idissue'";
        $data = $this->CustomQuery($sql);
        echo $data;
        return $data;
    }
    public function getAllComp($start, $limit, $q)
    {
        
        $sql = "SELECT * FROM phar_company LIMIT " . $start . "," . $limit;
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    
    ////////////////////////////////////////////////////////
    public function countAll_cat()
    {
        $sql  = "SELECT * FROM phar_category";
        $data = $this->totalRecordsInQuery($sql);
        return $data;
    }
    //////////////////////////////////////////////////////////
    public function getAllCat($start, $limit, $q)
    {
        
        $sql = "SELECT * FROM phar_category LIMIT " . $start . "," . $limit;
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    ///////////////////////////////////////////////////
    public function getAllUltra($start, $limit, $q)
    {
        
        $sql = "SELECT * FROM ultrasound_type LIMIT " . $start . "," . $limit;
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    ////////////////////////////////////////////////////////
    public function countAll_generic_drug()
    {
        $sql  = "SELECT * FROM phar_generic_drug";
        $data = $this->totalRecordsInQuery($sql);
        return $data;
    }
    public function getAllGeneric_drug($start, $limit, $q)
    {
        
        $sql = "SELECT * FROM phar_generic_drug LIMIT " . $start . "," . $limit;
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    
    ////////////////////////////////////////////////////////
    public function countAll_supplier()
    {
        $sql  = "SELECT * FROM phar_supplier";
        $data = $this->totalRecordsInQuery($sql);
        return $data;
    }
    public function getAllSupplier($start, $limit, $q)
    {
        
        $sql  = "SELECT ps.sup_id as sid, 
				        ps.sup_name as sname, 
				        pc.comp_name as cname, 
						ps.sup_address as address,
						ps.city as city,
						ps.phone as phone
						FROM phar_supplier as ps, phar_company as pc where ps.comp_id=pc.comp_id 
						LIMIT " . $start . "," . $limit;
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    ////////////////////////////////////////////////////////
    public function countAll_drug_master()
    {
        $sql  = "SELECT * FROM phar_drug_master";
        $data = $this->totalRecordsInQuery($sql);
        return $data;
    }
    public function getAlldrug_master($start, $limit, $q)
    {
        
        $sql  = "SELECT pm.drug_id AS drug_id, pm.drug_name AS drug_name, pm.masmcode AS masmcode, pg.generic_drug_name AS generic_drug, pc.cat_name AS cat_name, pm.unit AS unit, pm.reorder_level AS reorder_level
FROM phar_drug_master AS pm, phar_generic_drug AS pg, phar_category AS pc
WHERE pm.generic_id = pg.generic_id
AND pm.cat_id = pc.cat_id
						LIMIT " . $start . "," . $limit;
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    ////////////////////////////////////////////////////////
    public function countAll_item()
    {
        $sql  = "SELECT * FROM phar_item";
        $data = $this->totalRecordsInQuery($sql);
        return $data;
    }
    public function getAllitem($start, $limit, $q)
    {
        $sql  = "SELECT i.isbn_no AS isbn_no, i.item_name AS item_name, c.cat_name AS cat_name, s.sup_name AS sup_name, i.item_desc AS item_desc, i.costprice AS costprice, i.unitprice AS unitprice, i.quantity AS quantity, i.mdate AS mfd, i.expiry AS exp, i.location AS location
FROM phar_item AS i, phar_category AS c, phar_supplier AS s
" . $q . " and i.cat_id = c.cat_id
AND i.sup_id = s.sup_id
LIMIT " . $start . "," . $limit;
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    ////////////////////////////////////////////////////////
    public function countAll_med()
    {
        $sql  = "SELECT * FROM medicines";
        $data = $this->totalRecordsInQuery($sql);
        return $data;
    }
    //////////////////////////////////////////////////
    public function show_test_record($id)
    {
        $sql  = "Select * from pat_test, pat_result 
	where pat_test.pdno=pat_result.pdno
	and pat_test.tno=pat_result.tno
	and pat_result.opd_no='$id'";
        $data = $this->CustomQuery($sql);
        return $data;
    }
    ////////////////////////////////////////////
    public function getAllMed($start, $limit, $q)
    {
        
        $sql = "SELECT * FROM medicines $q order by med_id LIMIT " . $start . "," . $limit;
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    
    
    //////////////////////////////////////////////////////
    public function getAllCard($start, $limit, $q)
    {
        
        $sql = "SELECT * FROM cardiology $q order by c_test_id LIMIT " . $start . "," . $limit;
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    
    /////////////////////////////////////////////////////////////////////////
    public function countAll_xtest()
    {
        $sql  = "SELECT * FROM x_ray";
        $data = $this->totalRecordsInQuery($sql);
        return $data;
    }
    public function getAllxray($start, $limit, $q)
    {
        
        $sql = "SELECT * FROM x_ray $q order by x_test_id LIMIT " . $start . "," . $limit;
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    /////////////////////////////////////////////////////////////////////////
    public function getAllct($start, $limit, $q)
    {
        
        $sql = "SELECT * FROM ct_scan $q order by ct_test_id LIMIT " . $start . "," . $limit;
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    ///////////////////////////////////////////////////////////////////////////
    public function getAlldept($start, $limit, $q)
    {
        
        $sql = "SELECT * FROM `department` $q order by `department` asc LIMIT " . $start . "," . $limit;
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    public function getAllsection($start, $limit, $q)
    {
        
        $sql = "SELECT * FROM `section` as s, `department` as d $q and s.iddept=d.iddept order by s.iddept asc LIMIT " . $start . "," . $limit;
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    ///////////////////////////////////////////////////////////////////////////
    public function getAllfiletype($start, $limit, $q)
    {
        
        $sql = "SELECT * FROM `file_type` $q order by `filetype` asc LIMIT " . $start . "," . $limit;
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    public function getAllflag($start, $limit, $q)
    {
        
        $sql = "SELECT * FROM `flag` $q order by `flag` asc LIMIT " . $start . "," . $limit;
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    ///////////////////////////////////////////////////////////////////////////
    public function getAllstatus($start, $limit, $q)
    {
        
        $sql = "SELECT * FROM `status` $q order by `status` asc LIMIT " . $start . "," . $limit;
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    ///////////////////////////////////////////////////////////////////////////
    public function getAllsource($start, $limit, $q)
    {
        
        $sql = "SELECT * FROM `source` $q order by `source` asc LIMIT " . $start . "," . $limit;
        
        $data = $this->CustomQuery($sql);
        
        return $data;
    }
    ///////////////////////////////////////////////////////////////////////////
    
    public function getPat($id)
    {
        $data = $this->GetRecord('opd', 'ID', $id);
        return $data;
    }
    //////////////////////////////////////////////////
    public function getOpdList($id)
    {
        $data = $this->GetRecord('opdlist', 'CODE', $id);
        return $data;
    }
    ////////////////////////////////////////////////////////////////////////////////
    public function getTest($id)
    {
        $data = $this->GetRecord('med_tests', 'm_test_id', $id);
        return $data;
    }
    public function getCardTest($id)
    {
        $data = $this->GetRecord('cardiology', 'c_test_id', $id);
        return $data;
    }
    public function getCat($id)
    {
        $data = $this->GetRecord('phar_category', 'cat_id', $id);
        return $data;
    }
    public function getUltra($id)
    {
        $data = $this->GetRecord('ultrasound_type', 'ultra_id', $id);
        return $data;
    }
    public function getGenDrug($id)
    {
        $data = $this->GetRecord('phar_generic_drug', 'generic_id', $id);
        return $data;
    }
    public function getComp($id)
    {
        $data = $this->GetRecord('phar_company', 'comp_id', $id);
        return $data;
    }
    public function getWard($id)
    {
        $data = $this->GetRecord('phar_ward', 'ward_id', $id);
        return $data;
    }
    public function getSupplier($id)
    {
        $data = $this->GetRecord('phar_supplier', 'sup_id', $id);
        return $data;
    }
    public function get_name_session($id)
    {
        $data = $this->GetRecord('um_users', 'user_id', $id);
        return $data;
    }
    
    
    public function getitemname($id)
    {
        $data = $this->GetRecord('phar_item', 'isbn_no', $id);
        return $data;
    }
    public function getCtTest($id)
    {
        $data = $this->GetRecord('ct_scan', 'ct_test_id', $id);
        return $data;
    }
    public function getdept($id)
    {
        $data = $this->GetRecord('department', 'iddept', $id);
        return $data;
    }
    public function getsection($id)
    {
        $data = $this->GetRecord('section', 'idsection', $id);
        return $data;
    }
    public function getfiletype($id)
    {
        $data = $this->GetRecord('file_type', 'idfiletype', $id);
        return $data;
    }
    public function getflag($id)
    {
        $data = $this->GetRecord('flag', 'idflag', $id);
        return $data;
    }
    public function getstatus($id)
    {
        $data = $this->GetRecord('status', 'idstatus', $id);
        return $data;
    }
    public function getsource($id)
    {
        $data = $this->GetRecord('source', 'idsource', $id);
        return $data;
    }
    public function getXrayTest($id)
    {
        $data = $this->GetRecord('x_ray', 'x_test_id', $id);
        return $data;
    }
    public function getCompany()
    {
        $sql  = "select * from phar_company";
        $data = $this->CustomQuery($sql);
        return $data;
    }
    public function getCatName()
    {
        $sql  = "select * from phar_category";
        $data = $this->CustomQuery($sql);
        return $data;
    }
    public function getCompName_auto($name)
    {
        $sql  = "SELECT DISTINCT comp_name,comp_id
          FROM phar_company
          WHERE comp_name LIKE '%$name%'";
        $data = $this->CustomQuery($sql);
        return $data;
    }
    
    public function getItemName_auto($name)
    {
        $sql  = "SELECT DISTINCT item_name,isbn_no
          FROM phar_item
          WHERE item_name LIKE '%$name%'";
        $data = $this->CustomQuery($sql);
        return $data;
    }
    
    public function getCatName_auto($name)
    {
        $sql  = "SELECT DISTINCT cat_name,cat_id
          FROM phar_category
          WHERE cat_name LIKE '%$name%'";
        $data = $this->CustomQuery($sql);
        return $data;
    }
    public function getGenericName_auto($name)
    {
        $sql  = "SELECT DISTINCT generic_drug_name,generic_id
          FROM phar_generic_drug
          WHERE generic_drug_name LIKE '%$name%'";
        $data = $this->CustomQuery($sql);
        return $data;
    }
    public function getSupName_auto($name)
    {
        $sql  = "SELECT DISTINCT sup_name,sup_id
          FROM phar_supplier
          WHERE sup_name LIKE '%$name%'";
        $data = $this->CustomQuery($sql);
        return $data;
    }
    public function get_CatName($cat)
    {
        echo $sql = "select * from phar_category where cat_id!=$cat";
        $data = $this->CustomQuery($sql);
        return $data;
    }
    public function getSup()
    {
        $sql  = "select * from phar_supplier";
        $data = $this->CustomQuery($sql);
        return $data;
    }
    public function get_SupName($sup)
    {
        $sql  = "select * from phar_supplier where sup_id!=$sup";
        $data = $this->CustomQuery($sql);
        return $data;
    }
    public function getgenid()
    {
        $sql  = "select * from phar_generic_drug";
        $data = $this->CustomQuery($sql);
        return $data;
    }
    public function getCompanyName($uid)
    {
        $sql  = "SELECT c.comp_id as comp_id, c.comp_name AS comp_name
FROM phar_supplier AS s, phar_company AS c
WHERE s.comp_id = c.comp_id
AND s.sup_id =$uid";
        $data = $this->CustomQuery($sql);
        return $data;
    }
    public function getSupplierName($uid)
    {
        $sql  = "SELECT s.sup_id as sup_id, s.sup_name AS sup_name
FROM phar_item as i, phar_supplier AS s
WHERE i.sup_id = s.sup_id
AND i.isbn_no =$uid";
        $data = $this->CustomQuery($sql);
        return $data;
    }
    public function getCategory($uid)
    {
        $sql  = "SELECT c.cat_id as cat_id, c.cat_name AS cat_name
FROM phar_item AS i, phar_category AS c
WHERE i.cat_id = c.cat_id
AND i.isbn_no =$uid";
        $data = $this->CustomQuery($sql);
        return $data;
    }
    public function getDrugMaster($uid)
    {
        $sql  = "SELECT pm.drug_id AS drug_id, pm.drug_name AS drug_name, pm.masmcode AS masmcode, pg.generic_drug_name, pc.cat_name AS cat_name, pm.unit AS unit, pm.reorder_level AS reorder_level
FROM phar_drug_master AS pm, phar_generic_drug AS pg, phar_category AS pc
WHERE pm.generic_id = pg.generic_id
AND pm.cat_id = pc.cat_id
AND pm.drug_id =$uid";
        $data = $this->CustomQuery($sql);
        return $data;
    }
    ///////////////////////////////////////////
    
    public function updateOpdList()
    {
        extract($_POST);
        $uid = $_REQUEST['uid'];
        
        $sql = "UPDATE opdlist SET OPD = '$opd_name',RATE = '$opd_rate',
				 	ROOM= '$opd_room', 
				 	
					
					
					 WHERE CODE = '$uid'";
        
        if (mysql_query($sql)) {
            return "User updated successfully!";
        } else {
            return "this username is not available!";
        }
    }
    //////////////////////////////////////////////////////////////////////
    public function updatePat_rec()
    {
        extract($_POST);
        $uid = $_REQUEST['uid'];
        
        echo $sql = "UPDATE opd SET NAME = '$name' WHERE ID = '$id'";
        if (mysql_query($sql)) {
            return "User updated successfully!";
        } else {
            return "this username is not available!";
        }
    }
    ////////////////// Medicines Update ///////////////////////////////////
    public function getMed($id)
    {
        $data = $this->GetRecord('medicines', 'med_id', $id);
        return $data;
    }
    
    
    
    public function updateMed()
    {
        extract($_POST);
        //$uid=$_REQUEST['uid'];
        
        $sql = "UPDATE medicines SET med_name = '$m_name', WHERE med_id = '$m_id'";
        
        if (mysql_query($sql)) {
            return "Test updated successfully!";
        } else {
            return "this Test is not available!";
        }
    }
    
    ///////////////////////////////////Test Update///////////////////////////////////
    public function updateTest()
    {
        extract($_POST);
        $pdno = $_POST['pdno'];
        $tno  = $_POST['tno'];
        $gno  = $_POST['gno'];
        $sgno = $_POST['sgno'];
        if ($sgno == '') {
            $sql = mysql_query("UPDATE groups SET GNAME = '$test',
				 	NORMAL_FR= '$normal_fr', 
					NORMAL_TO= '$normal_to', 
					UNIT= '$unit' 
					WHERE PDNO='$pdno' AND TNO='$tno' AND GNO='$gno'");
        }
        if ($gno == '' && $sgno == '') {
            $sql = mysql_query("UPDATE tests1 SET TNAME = '$test',
				 	NORMAL_FR= '$normal_fr', 
					NORMAL_TO= '$normal_to', 
					UNIT= '$unit' 
					WHERE PDNO='$pdno' AND TNO='$tno'");
        } else {
            $sql = mysql_query("UPDATE sgroups SET SGNAME = '$test',
				 	NORMAL_FR= '$normal_fr', 
					NORMAL_TO= '$normal_to', 
					UNIT= '$unit' 
					WHERE PDNO='$pdno' AND TNO='$tno' AND GNO='$gno' AND SGNO='$sgno'");
        }
    }
    ///////////////////////////////////////////////////
    public function updateTest1()
    {
        extract($_POST);
        $sql = "UPDATE groups SET GNAME = '$gname',
				 	NORMAL_FR= '$normal_fr', 
					NORMAL_TO= '$normal_to' 
					WHERE id = '$test_id'";
        if (mysql_query($sql)) {
            return "Test updated successfully!";
        } else {
            return "this Test is not available!";
        }
    }
    //////////////////////////////////////////////////
    public function updateTest2()
    {
        extract($_POST);
        $sql = "UPDATE sgroups SET SGNAME = '$sgname',
				 	NORMAL_FR= '$normal_fr', 
					NORMAL_TO= '$normal_to' 
					WHERE id = '$test_id'";
        if (mysql_query($sql)) {
            return "Test updated successfully!";
        } else {
            return "this Test is not available!";
        }
    }
    /////////////////////////////////////////////
    public function updateCardTest()
    {
        extract($_POST);
        //$uid=$_REQUEST['uid'];
        
        $sql = "UPDATE cardiology SET c_test_name = '$ctest_name',
					
				 	c_test_rate= '$ctest_rate' WHERE c_test_id = '$ctest_id'";
        
        if (mysql_query($sql)) {
            return "Test updated successfully!";
        } else {
            return "this Test is not available!";
        }
    }
    ///////////////////////////////////////////////////////
    public function updateCat()
    {
        extract($_POST);
        //$uid=$_REQUEST['uid'];
        
        $sql = "UPDATE phar_category SET cat_name = '$cat_name'
					
				 	         WHERE cat_id = '$cat_id'";
        
        
        if (mysql_query($sql)) {
            return "Category updated successfully!";
        } else {
            return "this Category is not available!";
        }
    }
    /////////////////////////////////////////////////////
    public function updateUltra()
    {
        extract($_POST);
        //$uid=$_REQUEST['uid'];
        
        $sql = "UPDATE ultrasound_type SET ultra_type = '$ultra_type'
					
				 	         WHERE ultra_id = '$ultra_id'";
        
        
        if (mysql_query($sql)) {
            return "Ultrasound updated successfully!";
        } else {
            return "this Ultrasound is not available!";
        }
    }
    ///////////////////////////////////////////////////////
    public function updateGeneDrug()
    {
        extract($_POST);
        //$uid=$_REQUEST['uid'];
        
        $sql = "UPDATE phar_generic_drug SET generic_drug_name = '$generic_drug_name'
					
				 	         WHERE generic_id = '$generic_id'";
        
        
        if (mysql_query($sql)) {
            return "Generic Drug updated successfully!";
        } else {
            return "this Generic Drug is not available!";
        }
    }
    ///////////////////////////////////////////////////////
    public function updateComp()
    {
        extract($_POST);
        //$uid=$_REQUEST['uid'];
        
        $sql = "UPDATE phar_company SET comp_name = '$comp_name',
					          address='$address'
				 	         WHERE comp_id = '$comp_id'";
        
        
        if (mysql_query($sql)) {
            return "Company updated successfully!";
        } else {
            return "this Company is not available!";
        }
    }
    //////////////////////////////////////////////////////
    public function updateWard()
    {
        extract($_POST);
        
        echo $sql = "UPDATE phar_ward SET ward_name = '$ward_name'
				 	         WHERE ward_id = '$ward_id'";
        
        
        if (mysql_query($sql)) {
            return "Ward updated successfully!";
        } else {
            return "this Ward is not available!";
        }
    }
    ///////////////////////////////////////////////////////
    public function updateSupplier()
    {
        extract($_POST);
        //$uid=$_REQUEST['uid'];
        
        $sql = "UPDATE phar_supplier SET sup_name = '$sup_name',
				                comp_id='$comp_id',
					          sup_address='$sup_address',
							  city='$city',
							  phone='$phone'
				 	         WHERE sup_id = '$sup_id'";
        
        
        
        if (mysql_query($sql)) {
            return "Supplier updated successfully!";
        } else {
            return "this Supplier is not available!";
        }
    }
    ///////////////////////////////////////////////////////
    public function updateitem($uid)
    {
        extract($_POST);
        //$uid=$_REQUEST['uid'];
        $mdate1  = date('Y-m-d', strtotime($mdate));
        $expiry1 = date('Y-m-d', strtotime($expiry));
        $sql     = "UPDATE phar_item 
				                SET item_name = '$item_name',
								item_desc = '$item_desc',
				                cat_id='$cat_id',
								sup_id='$sup_id',
					          costprice='$costprice',
							  unitprice='$unitprice',
							  quantity='$quantity',
							  mdate='$mdate1',
							  expiry='$expiry1',
							  location='$location'
				 	         WHERE isbn_no = '$uid'";
        
        
        if (mysql_query($sql)) {
            return "Item updated successfully!";
        } else {
            return "this item is not available!";
        }
    }
    ///////////////////////////////////////////////////////
    public function updateStock($uid)
    {
        extract($_POST);
        $ip = getenv("REMOTE_ADDR");
        date_default_timezone_set('Asia/karachi');
        $time = date("h:i:s", time());
        $date = date('Y-m-d');
        $user = $_SESSION['luser']['id'];
        $sql  = mysql_query("INSERT INTO manage_stock 
				                SET 
								isbn_no='$isbn_no',
								quan_add='$new_stock',
								quantity='$quantity',
								old_quan='$old_quan',
								ip='$ip',
								date='$date',
								time='$time',
								user_id='$user'");
        
        
        $sql1 = "UPDATE phar_item 
				                SET item_name = '$item_name',
								item_desc = '$item_desc',
								costprice='$costprice',
								unitprice='$unitprice',
								quantity='$quantity'
								  
								WHERE isbn_no = '$uid'";
        
        if (mysql_query($sql1)) {
            return "Stock updated successfully!";
        } else {
            return "this item is not available!";
        }
    }
    ///////////////////////////////////////////////////////
    public function updateCtTest()
    {
        extract($_POST);
        //$uid=$_REQUEST['uid'];
        
        $sql = "UPDATE ct_scan SET ct_test_name = '$cttest_name',
					
				 	ct_test_rate= '$cttest_rate' WHERE ct_test_id = '$cttest_id'";
        
        if (mysql_query($sql)) {
            return "Test updated successfully!";
        } else {
            return "this Test is not available!";
        }
    }
    
    /////////////////////////////////////////////////
    public function updatedept()
    {
        extract($_POST);
        $sql = "UPDATE `section` SET `section` = '$section', `iddept` = '$iddept' WHERE `idsection`='$idsection'";
        
        if (mysql_query($sql)) {
            return "Test updated successfully!";
        } else {
            return "this Test is not available!";
        }
    }
    
    /////////////////////////////////////////////////
    public function updatefiletype()
    {
        extract($_POST);
        $sql = "UPDATE `file_type` SET `filetype` = '$filetype' WHERE `idfiletype` = '$idfiletype'";
        
        if (mysql_query($sql)) {
            return "Test updated successfully!";
        } else {
            return "this Test is not available!";
        }
    }
    
    /////////////////////////////////////////////////
    public function updateflag()
    {
        extract($_POST);
        $sql = "UPDATE `flag` SET `flag` = '$flag' WHERE `idflag` = '$idflag'";
        
        if (mysql_query($sql)) {
            return "Test updated successfully!";
        } else {
            return "this Test is not available!";
        }
    }
    public function updatestatus()
    {
        extract($_POST);
        $sql = "UPDATE `status` SET `status` = '$status' WHERE `idstatus` = '$idstatus'";
        
        if (mysql_query($sql)) {
            return "Test updated successfully!";
        } else {
            return "this Test is not available!";
        }
    }
    
    /////////////////////////////////////////////////
    public function updatesource()
    {
        extract($_POST);
        $sql = "UPDATE `source` SET `source` = '$source' WHERE `idsource` = '$idsource'";
        
        if (mysql_query($sql)) {
            return "Test updated successfully!";
        } else {
            return "this Test is not available!";
        }
    }
    
    /////////////////////////////////////////////////
    public function getalldays()
    {
        $sql  = "SELECT * FROM opd_days";
        $data = $this->CustomQuery($sql);
        return $data;
        
    }
    ////////////////////////////////////////////////////
    public function updateXrayTest()
    {
        extract($_POST);
        //$uid=$_REQUEST['uid'];
        
        $sql = "UPDATE x_ray SET x_test_name = '$x_name',
					
				 	x_test_rate= '$x_rate' WHERE x_test_id = '$xtest_id'";
        
        if (mysql_query($sql)) {
            return "Test updated successfully!";
        } else {
            return "this Test is not available!";
        }
    }
    /////////////////////////////////////////////////////////////
    
    
    public function deleteOPD($id)
    {
        $sql = "DELETE";
        
        if ($this->deleteRecord('opd', 'ID = ' . $id)) {
            return "User deleted";
        }
    }
    /////////////////////////////////////////////////////////
    public function deleteWard($id)
    {
        $sql = "DELETE";
        
        if ($this->deleteRecord('phar_ward', 'ward_id = ' . $id)) {
            return "User deleted";
        }
    }
    
    ////////////////////////////////////////////////////////
    
    
    
    public function deletePat($id)
    {
        $sql = "DELETE";
        
        if ($this->deleteRecord('opd_pat_reg', 'opd_id = ' . $id)) {
            return "User deleted";
        }
    }
    ////////////////////////////////////////////
    public function deleteOpdList($id)
    {
        $sql = "DELETE";
        
        if ($this->deleteRecord('opdlist', 'CODE = ' . $id)) {
            return "User deleted";
        }
    }
    ///////////////////////////////////////////////////////////////////////////
    public function deleteTest($id)
    {
        $sql = "DELETE";
        if ($this->deleteRecord('tests1', 'TNO = ' . $id)) {
            return "User deleted";
        }
        
        
    }
    ////////////////////////////////////////////////
    public function deleteMed($id)
    {
        $sql = "DELETE";
        if ($this->deleteRecord('medicines', 'med_id = ' . $id)) {
            return "User deleted";
        }
        
    }
    
    ////////////////////////////////////////////////////////////////////////
    public function deleteCardTest($id)
    {
        $sql = "DELETE";
        if ($this->deleteRecord('cardiology', 'c_test_id = ' . $id)) {
            return "User deleted";
        }
        
        
    }
    ////////////////////////////////////////////////////////////////////////
    public function deleteCatTest($id)
    {
        $sql = "DELETE";
        if ($this->deleteRecord('phar_category', 'cat_id = ' . $id)) {
            return "Category deleted";
        }
        
        
    }
    //////////////////////////////////////
    public function deletePatMedicine($id)
    {
        $sql = "DELETE";
        if ($this->deleteRecord('patient_medicine', 'id = ' . $id)) {
            return "Medicine deleted";
        }
        
        
    }
    ///////////////////////////////////////////////
    public function deleteUltra($id)
    {
        $sql = "DELETE";
        if ($this->deleteRecord('ultrasound_type', 'ultra_id = ' . $id)) {
            return "Ultrasound deleted";
        }
        
        
    }
    
    //////////////////////////////////////////////////////////////////////////////
    public function deleteGeneric_drug($id)
    {
        $sql = "DELETE";
        if ($this->deleteRecord('phar_generic_drug', 'generic_id = ' . $id)) {
            return "Generic Drug deleted";
        }
        
        
    }
    
    
    
    //////////////////////////////////////////////////////////////////////////////
    public function deleteComp($id)
    {
        $sql = "DELETE";
        if ($this->deleteRecord('phar_company', 'comp_id = ' . $id)) {
            return "Company deleted";
        }
        
        
    }
    
    
    
    //////////////////////////////////////////////////////////////////////////////
    public function deleteSupplier($id)
    {
        $sql = "DELETE";
        if ($this->deleteRecord('phar_supplier', 'sup_id = ' . $id)) {
            return "Supplier deleted";
        }
        
        
    }
    //////////////////////////////////////////////////////////////////////////////
    public function deletedrug_master($id)
    {
        $sql = "DELETE";
        if ($this->deleteRecord('phar_drug_master', 'drug_id = ' . $id)) {
            return "Drug Master deleted";
        }
        
        
    }
    //////////////////////////////////////////////////////////////////////////////
    public function deleteitem($id)
    {
        $sql = "DELETE";
        if ($this->deleteRecord('phar_item', 'isbn_no = ' . $id)) {
            return "Item deleted";
        }
        
        
    }
    
    
    
    //////////////////////////////////////////////////////////////////////////////
    public function deleteXrayTest($id)
    {
        $sql = "DELETE";
        if ($this->deleteRecord('x_ray', 'x_test_id = ' . $id)) {
            return "User deleted";
        }
        
        
    }
    
    
    ////////////////////////////////////////////
    public function deleteCTscan($id)
    {
        $sql = "DELETE";
        if ($this->deleteRecord('ct_scan', 'ct_test_id = ' . $id)) {
            return "User deleted";
        }
        
        
    }
    //////////////////////////////////////////////
    public function deleteDept($id)
    {
        $sql = "DELETE";
        if ($this->deleteRecord('department', 'iddept = ' . $id)) {
            return "User deleted";
        }
        
        
    }
    //////////////////////////////////////////////
    public function deleteSection($id)
    {
        $sql = "DELETE";
        if ($this->deleteRecord('section', 'idsection = ' . $id)) {
            return "User deleted";
        }
        
        
    }
    //////////////////////////////////////////////
    public function deleteFiletype($id)
    {
        $sql = "DELETE";
        if ($this->deleteRecord('file_type', 'idfiletype = ' . $id)) {
            return "User deleted";
        }
        
        
    }
    //////////////////////////////////////////////
    public function deleteFlag($id)
    {
        $sql = "DELETE";
        if ($this->deleteRecord('flag', 'idflag = ' . $id)) {
            return "User deleted";
        }
        
        
    }
    //////////////////////////////////////////////
    public function deletestatus($id)
    {
        $sql = "DELETE";
        if ($this->deleteRecord('status', 'idstatus = ' . $id)) {
            return "User deleted";
        }
        
        
    }
    //////////////////////////////////////////////
    public function deletesource($id)
    {
        $sql = "DELETE";
        if ($this->deleteRecord('source', 'idsource = ' . $id)) {
            return "User deleted";
        }
        
        
    }
    //////////////////////////////////////////////
    
    
    
    
    
}

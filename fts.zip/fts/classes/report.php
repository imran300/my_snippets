<?php
class Report extends DBAccess{
	function Report(){
		$this->connectToDB();
	}
}
	
?>
<?php
class Pharmacy extends DBAccess{
	function Pharmacy(){
		$this->connectToDB();
	}
	public function getItem_auto($name){
		$sql="SELECT DISTINCT item_name,isbn_no,unitprice,quantity
          FROM phar_item
          WHERE item_name LIKE '%$name%'";
		$data = $this->CustomQuery($sql);
		return $data;
	}
	public function deleteSalesReturn($id){
		$sql = "DELETE";
		if($this->deleteRecord('phar_sales_return', 'isbn_no = '.$id)){
			return "Item deleted";
		}
	}
	//////////////////////////////////////////////////////////////////////////////
	public function countAll_item(){
	$sql = "SELECT * FROM phar_item";
	$data = $this->totalRecordsInQuery($sql);
	return $data;
	}
	public function getAllitem($start,$limit,$q){
				 $sql = "SELECT i.isbn_no as id, i.date as delivery, i.item_name AS item, s.sup_name AS sup, c.comp_name AS comp, i.quantity AS qty, i.unitprice AS unit, i.costprice AS cost, i.mdate as mfg, i.expiry as exp
FROM phar_item AS i, phar_company AS c, phar_supplier AS s
WHERE i.sup_id = s.sup_id
AND s.comp_id = c.comp_id
LIMIT ".$start.",".$limit;
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	////////////////////////////////////////////////////////////////////////////////
	public function getReturnSale($id){
		$sql="SELECT * FROM phar_sales_return WHERE isbn_no='$id' ";
		$data = $this->CustomQuery($sql);
		return $data;
	}
	public function getMedicationRecord($id){
		$date=date("Y");
	 $sql="SELECT pm.id AS sno, o.NAME AS name, f_name AS fname, o.OPD AS opd, pi.item_name AS item, pm.quantity_given AS qty, pi.unitprice AS unit, round((
IFNULL( pm.quantity_given, 0 ) * IFNULL( pi.unitprice, 0 )
),2) AS tot, pm.date AS date, pm.time as time
FROM patient_medicine AS pm, phar_item AS pi, opd AS o
WHERE pm.opd_no = o.YEAR
AND pm.isbn_no = pi.isbn_no
AND pm.gender = o.SEX
AND o.OPDDATE LIKE '%$date%'
AND pm.opd_no = '$id'";
		$data = $this->CustomQuery($sql);
		return $data;
	}
	public function getMedicationRecord_a($id,$gen){
	 $sql="SELECT pm.id AS sno, o.NAME AS name, f_name AS fname, o.OPD AS opd, pi.item_name AS item, pm.quantity_given AS qty, pi.unitprice AS unit, round((
IFNULL( pm.quantity_given, 0 ) * IFNULL( pi.unitprice, 0 )
),2) AS tot, pm.date AS date, pm.time as time
FROM patient_medicine AS pm, phar_item AS pi, opd AS o
WHERE pm.opd_no = o.YEAR
AND pm.isbn_no = pi.isbn_no
AND pm.gender = o.SEX
AND pm.opd_no = '$id'
AND pm.gender = '$gen'";
		$data = $this->CustomQuery($sql);
		return $data;
	}
	public function getMedicationWardRecord($id){
	$sql="SELECT pw.ward_name AS ward, pi.item_name AS item, wm.quantity_given AS qty, wm.time, wm.date
FROM phar_item AS pi, ward_medicine AS wm, phar_ward AS pw
WHERE wm.ward_id = pw.ward_id
AND wm.isbn_no = pi.isbn_no
AND wm.ward_id ='$id'";
		$data = $this->CustomQuery($sql);
		return $data;
	}
	public function get_medicine_actual($isbn){
		$sql="SELECT * from  phar_item  WHERE isbn_no='$isbn'";
		$data = $this->CustomQuery($sql);
		return $data;
	}
	public function view_stock(){
		$sql="SELECT i.isbn_no as id, i.item_name AS item, s.sup_name AS sup, c.comp_name AS comp, i.quantity AS qty, i.unitprice AS unit, i.costprice AS cost
FROM phar_item AS i, phar_company AS c, phar_supplier AS s
WHERE i.sup_id = s.sup_id
AND s.comp_id = c.comp_id";
		$data = $this->CustomQuery($sql);
		return $data;
	}
	public function show_sales_return($id){
		$sql="SELECT i.isbn_no as id, i.item_name AS item, s.sup_name AS sup, s.sup_id as sup_id, c.comp_name AS comp, c.comp_id as comp_id, i.quantity AS qty, i.unitprice AS unit, i.costprice AS cost, i.mdate as mfg, i.expiry as exp
FROM phar_item AS i, phar_company AS c, phar_supplier AS s
WHERE i.sup_id = s.sup_id
AND s.comp_id = c.comp_id
AND i.isbn_no='$id'";
		$data = $this->CustomQuery($sql);
		return $data;
	}
	public function insert_sales_return(){
	   if(isset($_POST['update'])=='add'){
	        extract ($_POST);
		 $ip = getenv("REMOTE_ADDR");
	        date_default_timezone_set('Asia/karachi');
	        $time = date("h:i:s");
	        $user_id=$_SESSION['luser']['id'];
		    $date=date('Y-m-d');
			$sql="INSERT INTO phar_sales_return SET item_name='$item_name', isbn_no='$isbn_no', sup_id='$sup_id', comp_id='$comp_id', quantity='$quantity', unitprice='$unitprice', costprice='$costprice', new_quan='$new_quan', remain_quan='$remain_quan', new_cost='$new_cost', remarks='$remarks', ip='$ip', date='$date', time='$time'";
			if(mysql_query($sql)){
				echo  "Sales Item Returned Successfully!";
			}
	   }
	}
	public function update_sales_return($id){
		if(isset($_POST['update'])=='add'){
			extract ($_POST);
			$sql="UPDATE phar_item SET quantity='$remain_quan', costprice='$new_cost' WHERE isbn_no='$id'";
			if(mysql_query($sql)){
			echo  "Sales Item Returned Successfully!";
				header("location:index.php?option=report&item=sales_return_report&id=$id");
			}
		}
	}
	////////////////////////////////////////////////////
	public function show_pat_med_id($id){
	 $sql="SELECT p.opd_no AS opd, i.item_name AS item, p.quantity_given AS qty
FROM patient_medicine AS p, phar_item AS i
WHERE p.isbn_no = i.isbn_no
AND p.id = '$id'";
		$data = $this->CustomQuery($sql);
		return $data;
	}
	////////////////////////////////////////////////
	public function update_pat_med_id($id){
		if(isset($_POST['submit'])=='update'){
			extract ($_POST);
			$sql="UPDATE patient_medicine SET quantity_given='$quantity_given' WHERE id='$id'";
			if(mysql_query($sql)){
		    return "Updated Successfully";
			}
		}
	}
///////////////////////////////////////////////////
    public function deletePatMedid($id){
		$sql = "DELETE";
		if($this->deleteRecord('patient_medicine', 'id = '.$id)){
			return "Record deleted";
		}
 }
   public function get_record($sql){
		$data = $this->CustomQuery($sql);
		return $data;
		
	}
	public function search_opd_pharmacy(){
		   extract($_POST);
	       $id=$_POST['opd_no'];
		   $gen=$_POST['gender'];
		   $sql="SELECT * FROM patient_medicine where opd_no='$id' AND gender = '$gen'";
	       $data= $this->CustomQuery($sql);
		   if($data==''){
			   echo "<div align='center' style='color:#F00;font-weight:bold;'>No Record Found</div>";
		   }else{
		   if($data){
		     ?>
			 <script>window.open("report/medication_report_a.php?opd_no=<?= $id; ?>&gender=<?= $gen; ?>");</script>
             <?php
		   }
		   }
	}
	
}
	
?>
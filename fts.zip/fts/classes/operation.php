<?php 
class Operation extends DBAccess{
	function Operation(){
		$this->connectToDB();
	}
	public function maximum_number(){
		extract($_POST);
				 $sql = "SELECT * FROM  opd";
			
		$data = $this->totalRecordsInQuery_max($sql);
		
		return $data;
	}
	
	function total_max($sql)
	{
		if(empty($sql))
			return false;
			
			$q = mysql_query($sql) or die(mysql_error());
			$r=mysql_fetch_array($q);
			//$num = mysql_num_rows($q);
			$max=$r['mx'];
			return $max;
	}
 public function maximum_number_lab($pdno,$no){
		
$sql="SELECT IFNULL(MAX(`LAB`),0)+1 FROM `pat_test` AS mx
WHERE `PDNO`='$pdno' AND `TNO`='$no'";

		$data = $this->total_max($sql);
		
		return $data;
	}
	////////////////////////////////////////////////////
	public function search_xray_id($id,$gender){
$sql="SELECT t.opd_no AS id, t.date AS date, t.time AS time, o.Name AS name, x.x_test_name AS xray, t.status AS status
FROM  `test_against_x_ray` AS t, opd AS o, x_ray AS x
WHERE t.opd_no = o.YEAR
AND t.x_ray_id = x.x_test_id
AND t.opd_no = '$id'
AND t.gender=o.SEX
AND t.gender='$gender'";
		$data = $this->CustomQuery($sql);
		return $data;
	}
	////////////////////////////////////////////////////
	public function search_ctscan_id($id,$gender){
$sql="SELECT t.opd_no AS id, t.date AS date, t.time AS time, o.Name AS name, c.ct_test_name AS ctscan, t.status AS status
FROM  `test_against_ct_scan` AS t, opd AS o, ct_scan AS c
WHERE t.opd_no = o.YEAR
AND t.ct_test_id = c.ct_test_id
AND t.opd_no = '$id'
AND t.gender=o.SEX
AND t.gender='$gender'";
		$data = $this->CustomQuery($sql);
		return $data;
	}
 	/////////////////////////////////////////////////////
	public function add_ward($id){
	 $ip = getenv("REMOTE_ADDR");
date_default_timezone_set('Asia/karachi');
	$TIME = date("h:i:s", time());
	$user=$_SESSION['luser']['id'];
	extract($_POST);
		$date=date('Y-m-d');
	   $sql  = "INSERT INTO  phar_ward SET
	                ward_id='$id',
	 				ward_name = '$ward_name',
					time='$TIME',
					date='$date',
					ip='$ip',
					user_id='$user'";
			if(mysql_query($sql)){
				
               header("location:index.php?option=general&item=show_ward");

			}
		else{
			return "this username is not available!";
		}
		
	}
	///////////////////////////////////////////////
	public function add_xray(){
		if(isset($_POST['submit'])=='save'){
		extract($_POST);
		$id=$_POST['opd_no'];
		$gen=$_POST['gen'];
	 $ip = getenv("REMOTE_ADDR");
	$TIME = date("h:i:s", time());
	$user=$_SESSION['luser']['id'];
		$date=date('Y-m-d');
	   $sql  = "INSERT INTO  `test_against_x_ray` SET
	                `x_ray_id`='$x_ray_id',
	 				`opd_no` = '$id',
					`status`='$status',
					`opd_date`='$opd_date',
					`gender`='$gen',
					`time`='$TIME',
					`date`='$date',
					`ip`='$ip',
					`user_id`='$user'";
			if(mysql_query($sql)){
				?>
                <script>window.open("report/xray_report.php?opd=<?= $id; ?>&gender=<?= $gen; ?>");</script>
                <?php
			}
		else{
			return "this username is not available!";
		}
		}
	}
	/////////////////////////////////////////////////////
	public function add_ct_scan(){
		if(isset($_POST['submit'])=='save'){
		extract($_POST);
		$id=$_POST['opd_no'];
		$gen=$_POST['gen'];
	 $ip = getenv("REMOTE_ADDR");
	$TIME = date("h:i:s", time());
	$user=$_SESSION['luser']['id'];
		$date=date('Y-m-d');
	   $sql  = "INSERT INTO  `test_against_ct_scan` SET
	                `ct_test_id`='$ct_test_id',
	 				`opd_no` = '$id',
					`status`='$status',
					`opd_date`='$opd_date',
					`gender`='$gen',
					`time`='$TIME',
					`date`='$date',
					`ip`='$ip',
					`user_id`='$user'";
			if(mysql_query($sql)){
				?>
                <script>window.open("report/ctscan_report.php?opd=<?= $id; ?>&gender=<?= $gen; ?>");</script>
                <?php
			}
		else{
			return "this username is not available!";
		}
		}
	}
	/////////////////////////////////////////////////////
	public function add_opd_record_opd($number){
	 $ip = getenv("REMOTE_ADDR");
date_default_timezone_set('Asia/karachi');
	$TIME = date("h:i:s", time());
	extract($_POST);
		$date=date('Y-m-d');
	  $sql  = "INSERT INTO  opd SET
	                YEAR ='$number',
	 				OPDDATE = '$date',
				 	NAME = '$name',
					f_name='$f_name',
					RELATION='$relation',
					EMP_NAME='$emp_name', 
				 	OPD= '$opd',
					ROOM='$room',
					RATE='5',
					CODE='$code',
					ADDRESS='PESHAWAR',
					AGE='$age',
					SEX='$gender',
					time='$TIME',
					IP='$ip',
					USER_ID=".$_SESSION['luser']['id'].",
					CANCEL=''";
			if(mysql_query($sql)){
				$id_new=mysql_insert_id();?>
		<script>window.open("report/opd_print.php?id=<?php echo $id_new;?>");</script>
                <?php 
				
				//header("Location:index.php?option=opd&item=opd&id=$id_new");
				//header("Location:http://192.168.1.51:82/cshms/report/production-grid.php");

			}
		else{
			return "this username is not available!";
		}
		
	}
	/////////////insert_patient_Detail///////////////
	public function insert_patient_Detail(){
	 $ip = getenv("REMOTE_ADDR");
   date_default_timezone_set('Asia/karachi');
	$TIME = date("h:i:s", time());


		extract($_POST);
		$date=date('Y-m-d');
		$test_count=$_REQUEST['test'];
	 $count=count($test_count);
	foreach($test_count as $row_test)
	{
		$sql_tests=mysql_query("INSERT INTO `test_against_opd` SET `opd_id`='$opd_no',`test_id`='$row_test',`pat_id`='0'");
		}
		$sql="INSERT INTO patient_record SET opd_unique_no='$opd_no',m_test_id='$row_test',remarks='$remarks',time='$TIME',date='$date',ip='$ip'";
		$data = mysql_query($sql);
		if($data)
		{
			header("Location:index.php?option=report&item=print_opd_patient_record&opd_id=$opd_no");
			return "Done Successfully !";
			}
			else
			{
				
							return "Operation Terminated !";
}
		//die($test);
	 
		
	}
	public function countAll_pat()
{
	$sql = "SELECT * FROM opd_pat_reg";
	$data = $this->totalRecordsInQuery($sql);
	return $data;
}
public function get_opd_by_no(){
	extract($_POST);
        $date=date('Y');
	$sql = "SELECT * FROM opd WHERE YEAR='$id' AND OPDDATE LIKE '%$date%'";
	$data = $this->CustomQuery($sql);
		if(empty($data)){
		$data ="EMPTY";
		}
		else
		{
	$data;
}

return $data;
}
public function get_opd_Acc($date){
	$date_new=date("Y-m-d",strtotime($date));
	 $sql="SELECT COUNT(YEAR) AS opds, SUM(RATE) AS rate FROM opd where OPDDATE='$date_new'";
	$data = $this->CustomQuery($sql);
		if(empty($data)){
		$data ="EMPTY";
		}
		else
		{
	$data;
}

return $data;
}


////////////////////////////////////////////////////
public function get_pdno($id)
{
	
		 $sql="SELECT * From tests1 where TNO='$id'";
	$data =mysql_query($sql);
		if(empty($data)){
		$data ="EMPTY";
		}
		else
		{
	$data;
}
return $data;
}
///////////////////////////////////////////////
public function search_cardiology_by_opdno_for_report()
{
	       extract($_POST);
	       $id=$_POST['opd_no'];
		   $gen=$_POST['gender'];
		   $sql="SELECT * From card_pecho where opd_no='$id' AND gender = '$gen'";
	       $data= $this->CustomQuery($sql);
		   if($data==''){
		   $sql1 ="SELECT * From card_echo where opd_no='$id' AND gender = '$gen'";
		   $data1= $this->CustomQuery($sql1);
		   if($data1){
		     ?>
			 <script>window.open("report/echo_report1.php?id=<?= $id;?>&gender=<?= $gen; ?>");</script>
             <?php
		   }
		   }
		   if($data1==''){
		   $sql2 ="SELECT * From card_ett where opd_no='$id' AND gender = '$gen'";
		   $data2= $this->CustomQuery($sql2);
		   if($data2){
		     ?>
			 <script>window.open("report/ett_report1.php?id=<?= $id;?>&gender=<?= $gen; ?>");</script>
             <?php
		   }
		   }
		   if($data2==''){
		   $sql3 ="SELECT * From card_ecg where opd_no='$id' AND gender = '$gen'";
		   $data3= $this->CustomQuery($sql3);
		   if($data3){
		     ?>
			 <script>window.open("report/ecg_report1.php?id=<?= $id;?>&gender=<?= $gen; ?>");</script>
             <?php
		   }
		   }
		   if($data3==''){
		   $sql4 ="SELECT * From card_holter where opd_no='$id' AND gender = '$gen'";
		   $data4= $this->CustomQuery($sql4);
		   }
		   if($data4){
		     ?>
			 <script>window.open("report/holter_report1.php?id=<?= $id;?>&gender=<?= $gen; ?>");</script>
             <?php
		   }
		   else
		   if($data){
		     ?>
			 <script>window.open("report/pecho_report1.php?id=<?= $id;?>&gender=<?= $gen; ?>");</script>
             <?php
		   }
		   else
			   if($data=='' && $data1=='' && $data2=='' && $data3==''&& $data4==''){
				 return $data = "Sorry No Record Found!"; 
				 return $data1 = "Sorry No Record Found!"; 
				 return $data2 = "Sorry No Record Found!"; 
				 return $data3 = "Sorry No Record Found!"; 
				 return $data4 = "Sorry No Record Found!";   
		   }
}
////////////////////////////////////////////////
public function search_ultrasound_all_by_opdno_for_report()
{
	       extract($_POST);
	       $id=$_POST['opd_no'];
		   $sql="SELECT * From pat_ultra_result as p, opd as o where p.opd_no = o.YEAR AND p.opd_no='$id' AND o.sex = '$gender'";
	       $data= $this->CustomQuery($sql);
		   if($data==''){
		   $sql1 ="SELECT * From pat_ultra_female as p, opd as o where p.opd_no = o.YEAR AND p.opd_no='$id' AND o.sex = '$gender'";
		   $data1= $this->CustomQuery($sql1);
		   if($data1){
		     ?>
			 <script>window.open("report/ultra_report_b.php?id=<?= $id; ?>&gender=<?= $gender; ?>");</script>
             <?php
		   }
		   }
		   if($data){
		     ?>
			 <script>window.open("report/ultra_report_a.php?id=<?= $id; ?>&gender=<?= $gender; ?>");</script>
             <?php
		   }
		   else
			   if($data=='' && $data1==''){
				 return $data = "Sorry No Record Found!";
				 return $data1 = "Sorry No Record Found!";   
		   }
}
////////////////////////////////////////////////
public function search_xray_opdno_for_report()
{
	       extract($_POST);
	       $id=$_POST['opd_no'];
		   $gender=$_POST['gender'];
		   $sql="SELECT * From test_against_x_ray where opd_no='$id' AND gender='$gender'";
	       $data= $this->CustomQuery($sql);
		   if($data){
		     ?>
			 <script>window.open("report/xray_report.php?opd=<?= $id; ?>&gender=<?= $gender; ?>");</script>
             <?php
		   }
		   else
			   if($data==''){
				 return $data = "Sorry No Record Found!";   
		   }
}
////////////////////////////////////////////////
public function search_ctscan_opdno_for_report()
{
	       extract($_POST);
	       $id=$_POST['opd_no'];
		   $gender=$_POST['gender'];
		   $sql="SELECT * From  `test_against_ct_scan` where opd_no='$id' and gender='$gender'";
	       $data= $this->CustomQuery($sql);
		   if($data){
		     ?>
			 <script>window.open("report/ctscan_report.php?opd=<?= $id; ?>&gender=<?= $gender; ?>");</script>
             <?php
		   }
		   else
			   if($data==''){
				 return $data = "Sorry No Record Found!";   
		   }
}
////////////////////////////////////////////////

public function get_medications($id)
{
	
		$sql = "SELECT * From pharmacy AS P LEFT JOIN opd AS O ON(P.opd_id=O.YEAR) where patient_id='".$id."'";
	$data = $this->CustomQuery($sql);
		if(empty($data)){
		$data ="EMPTY";
		}
		else
		{
	$data;
}
return $data;
}
public function get_x_ray($id)
{
	
		$sql = "SELECT * From test_against_x_ray AS P LEFT JOIN opd AS O ON(P.opd_id=O.YEAR) LEFT JOIN x_ray AS X ON (P.x_test_id=X.x_test_id) where patient_id='".$id."'";
	$data = $this->CustomQuery($sql);
		if(empty($data)){
		$data ="EMPTY";
		}
		else
		{
	$data;
}
return $data;
}

////////////////
public function get_cardiology($id)
{
	
		$sql = "SELECT * From test_against_cardialogy AS P LEFT JOIN opd AS O ON(P.opd_id=O.YEAR) LEFT JOIN cardiology AS X ON (P.c_test_id=X.c_test_id) where patient_id='".$id."'";
	$data = $this->CustomQuery($sql);
		if(empty($data)){
		$data ="EMPTY";
		}
		else
		{
	$data;
}
return $data;
}
/////////

public function get_groups($pd,$tn)
{
	$sql = "SELECT * From `groups`  WHERE `PDNO`='$pd' AND `TNO`='$tn'";
	$data = $this->CustomQuery($sql);
		if(empty($data)){
		$data ="EMPTY";
		}
		else
		{
	$data;
}

return $data;
	}

////////////////
public function get_history($id)
{
	
		$sql = "SELECT * From patient_history AS H LEFT JOIN opd AS O ON(H.opd_id=O.YEAR) where patient_id='".$id."'";
	$data = $this->CustomQuery($sql);
		if(empty($data)){
		$data ="EMPTY";
		}
		else
		{
	$data;
}

return $data;
	}
	/////////////////////////////////////////////////////
	public function get_LabTest($id)
{
	$sql ="SELECT * FROM `test_against_opd` AS T LEFT JOIN opd AS O ON ( T.opd_id = O.YEAR ) LEFT JOIN `med_tests` AS M ON(T.test_id=M.m_test_id) where YEAR='".$id."'";


		//$sql = "SELECT * From patient_history AS H LEFT JOIN opd AS O ON(H.opd_id=O.YEAR) where patient_id='".$id."'";
	$data = $this->CustomQuery($sql);
		if(empty($data)){
		$data ="EMPTY";
		}
		else
		{
	$data;
}

return $data;
	}
////////////////////////////////////////////////////////////////////////	
	public function search_patient_by_opdno_medicine(){
	extract($_POST);
        $date=date("Y");
	$abc="SELECT *
FROM opd AS t WHERE t.YEAR = '$id' AND OPDDATE LIKE '%$date%'";
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="No Record Found";
		}
		else
		{
	$data;
}

return $data;
}
///////////////////////////////////////////
public function search_patient_by_wardno_medicine(){
	extract($_POST);
	$system_date=date("Y/m/d");
	$abc="SELECT *
FROM phar_ward AS p WHERE p.ward_id = '$id'";
	//$sql = "SELECT * From test_against_opd where opd_id='".$id."'";
	/////$system_date=date("Y/m/d"); AND o.OPDDATE='$system_date' AND t.date='$system_date'
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="No Record Found";
		}
		else
		{
	$data;
}

return $data;
}
////////////////////////////////////////////
public function search_test_by_opdno(){
	extract($_POST);
        $date=date('Y');
	 $abc="SELECT *
FROM pat_test AS t
LEFT JOIN opd AS o ON (t.OPD_NO = o.YEAR)
LEFT JOIN tests1 AS M ON (t.PDNO=M.PDNO && t.TNO=M.TNO)
WHERE t.OPD_NO = '$id'
AND t.OPD_NO = o.YEAR
AND o.OPDDATE LIKE '%$date%'";
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="No Record Found";
		}
		else
		{
	$data;
}

return $data;
}
/////////////////////////////////////////////////////////////
public function search_opdno_monthly(){
	extract($_POST);
	$date=date("Y-m",strtotime($_POST['date1']));
	$id=$_POST['user_id'];
	$abc="SELECT OPDDATE, count(YEAR) AS OPD, sum(RATE) as RATE, u.username as user
FROM `opd` as o, um_users as u
WHERE o.USER_id=u.user_id
AND o.OPDDATE LIKE '$date%'
AND o.USER_ID LIKE '$id'
GROUP BY o.OPDDATE";
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="No Record Found";
		}
		else
		{
	$data;
}

return $data;
}
public function count_opdno_monthly(){
	extract($_POST);
	$date=date("Y-m",strtotime($_POST['date1']));
	$id=$_POST['user_id'];
	$abc="SELECT count(YEAR) AS OPD, sum(RATE) as RATE
FROM `opd`
WHERE `OPDDATE` LIKE '$date%'
AND `USER_ID` LIKE '$id'";
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="No Record Found";
		}
		else
		{
	$data;
}

return $data;
}
//////////////////////////////////////////////////////////////////
public function search_lab_by_opd(){
	extract($_POST);
        $date=date('Y');
	$opd=$_POST['opdno'];
	$gender=$_POST['gender'];
        
	$abc="SELECT * 
FROM pat_test AS t, opd AS o
WHERE t.opd_no = o.YEAR
AND t.opd_no = '$opd'
AND o.SEX = '$gender'
AND o.OPDDATE LIKE '%$date%'
GROUP BY t.OPD_NO";	
$data = $this->CustomQuery($abc);
if($data==''){
echo "No Record Found";
}else{
return $data;
}
}
//////////////////////////////////////////////////////////////////
public function search_test_by_opdno_for_report($opd_no){
	extract($_POST);
	$system_date=date("Y/m/d");
	$abc="SELECT *
FROM pat_result AS t
LEFT JOIN opd AS o ON (t.OPD_NO = o.YEAR)
LEFT JOIN tests1 AS M ON (t.PDNO=M.PDNO && t.TNO=M.TNO)
WHERE t.OPD_NO = '$opd_no' AND o.OPDDATE='$system_date' AND t.DATE='$system_date'   GROUP BY t.PDNO,t.TNO,t.GNO";
	//$sql = "SELECT * From test_against_opd where opd_id='".$id."'";
	/////$system_date=date("Y/m/d"); AND o.OPDDATE='$system_date' AND t.date='$system_date'
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="No Record Found";
		}
		else
		{
	$data;
}

return $data;
}
///////ultrasound report///////
public function search_ultrasound_by_opdno_for_report($opd_no){
	extract($_POST);
	$system_date=date("Y/m/d");
	$abc="SELECT *
FROM opd where YEAR='$opd_no'";
	//$sql = "SELECT * From test_against_opd where opd_id='".$id."'";
	/////$system_date=date("Y/m/d"); AND o.OPDDATE='$system_date' AND t.date='$system_date'
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="No Record Found";
		}
		else
		{
	$data;
}

return $data;
}


////////////
public function search_xray_by_opdno_for_report($opd_no){
	extract($_POST);
	$system_date=date("Y/m/d");
	$abc="SELECT *
FROM `test_against_x_ray` AS t
LEFT JOIN opd AS o ON (t.opd_id = o.YEAR)
LEFT JOIN x_ray AS x ON (t.x_test_id  = x.x_test_id)
WHERE t.opd_id = '$opd_no'";
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="No Record Found";
		}
		else
		{
	$data;
}

return $data;
}


////////////
public function search_test_by_opdno_for_report_second($opd_no){
	extract($_POST);
	//$system_date=date("Y/m/d");
	 $abc="SELECT *
FROM pat_result AS t
LEFT JOIN opd AS o ON (t.OPD_NO = o.YEAR)
LEFT JOIN tests1 AS M ON (t.PDNO=M.PDNO && t.TNO=M.TNO)
WHERE t.OPD_NO = '$opd_no' AND t.GNO='0' AND t.SGNO='0' GROUP BY t.PDNO,t.TNO,t.GNO";
	//$sql = "SELECT * From test_against_opd where opd_id='".$id."'";
	/////$system_date=date("Y/m/d"); AND o.OPDDATE='$system_date' AND t.date='$system_date'
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="No Record Found";
		}
		else
		{
	$data;
}

return $data;
}
/////////////////////////////////////////////////////
public function get_item_whole(){
	$sql="SELECT *
FROM phar_item";
	$data = $this->CustomQuery($sql);
		if(empty($data)){
		$data ="No Record Found";
		}
		else
		{
	$data;
}

return $data;
}
////////////////////////////////////////////////
public function get_item_whole1(){
	$sql=mysql_query("SELECT *
FROM phar_item
where quantity >0");
	$number=mysql_num_rows($sql);
		if(empty($number)){
		$number ="No Record Found";
		}
		else
		{
	return $number;
}

return $data;
}
///////////////////////////////////////////////////////////////
public function get_pharmacy_item_by_date(){
	$to_date=$_POST['to_date'];
			if($_POST['to_date']!="")
{
	$to_date=$_POST['to_date'];
	$date_is=date("Y/m/d",strtotime($to_date));
	$sql="SELECT i.item_name AS item, sum( m.quantity_given ) AS qty, m.date AS date
FROM `patient_medicine` AS m, phar_item AS i
WHERE m.isbn_no = i.isbn_no
AND m.date = '$date_is'
GROUP BY m.isbn_no ASC";
	$data = $this->CustomQuery($sql);
	$data;
}

return $data;
}
//////////////////////////////////////////////////////////////
public function get_ward_item_by_date(){
	$to_date=$_POST['to_date'];
			if($_POST['to_date']!="")
{
	$to_date=$_POST['to_date'];
	$date_is=date("Y/m/d",strtotime($to_date));
	$sql="SELECT i.item_name AS item, sum( m.quantity_given ) AS qty, m.date AS date
FROM `ward_medicine` AS m, phar_item AS i
WHERE m.isbn_no = i.isbn_no
AND m.date = '$date_is'
GROUP BY m.isbn_no ASC";
	$data = $this->CustomQuery($sql);
	$data;
}

return $data;
}
//////////////////////////////////////////////////////////////
public function get_pharmacy_item_by_month(){
	$to_date=$_POST['to_date'];
	$date=date("Y");
			if($_POST['to_date']!="")
{
	$to_date=$_POST['to_date'];
	$date_is=date("Y-m",strtotime($to_date));
	$sql="SELECT i.item_name AS item, sum( m.quantity_given ) AS qty, m.date AS date
FROM `patient_medicine` AS m, phar_item AS i
WHERE m.isbn_no = i.isbn_no
AND m.date LIKE '$date_is%'
AND m.date LIKE '%$date%'
GROUP BY m.isbn_no ASC";
	$data = $this->CustomQuery($sql);
	$data;
}

return $data;
}
//////////////////////////////////////////////////////////////
public function get_ward_item_by_month(){
	$to_date=$_POST['to_date'];
			if($_POST['to_date']!="")
{
	$to_date=$_POST['to_date'];
	$date_is=date("Y-m",strtotime($to_date));
	$sql="SELECT i.item_name AS item, sum( m.quantity_given ) AS qty, m.date AS date
FROM `ward_medicine` AS m, phar_item AS i
WHERE m.isbn_no = i.isbn_no
AND m.date LIKE '$date_is%'
GROUP BY m.isbn_no ASC";
	$data = $this->CustomQuery($sql);
	$data;
}

return $data;
}
//////////////////////////////////////////////////////////////
public function search_x_ray_by_opdno(){
	extract($_POST);
        $date=date("Y"); 
	$abc="SELECT *
FROM opd where YEAR = '$id' AND OPDDATE LIKE '%$date%'";
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="No Record Found";
		}
		else
		{
	$data;
}

return $data;
}
////////////////////////////////////////////////////////////////////
public function search_ct_scan_by_opdno(){
	extract($_POST);
$date=date("Y");
	$abc="SELECT *
FROM opd where YEAR = '$id' AND OPDDATE LIKE '%$date%'";
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="No Record Found";
		}
		else
		{
	$data;
}

return $data;
}
////////////////////////////////////////////////////////////////////////

public function search_cardialogy_by_opdno(){
	extract($_POST);
        $date=date("Y");
	$abc="SELECT * FROM opd WHERE YEAR = '$id' AND OPDDATE LIKE '%$date%'";
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="No Record Found";
		}
		else
		{
	$data;
}

return $data;
}
//////////////
public function search_ultrasound_by_opdno(){
	extract($_POST);
	$abc="SELECT * FROM opd WHERE YEAR = '$opdno'";
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="No Record Found";
		}
		else
		{
	$data;
}
return $data;
}
////////////////////////////////////////////
public function search_pharmacy_by_opdno(){
	extract($_POST);
	$system_date=date("Y/m/d");
	$abc="SELECT *
FROM patient_medical AS p
LEFT JOIN opd AS o ON ( p.opd_no = o.YEAR )
WHERE p.opd_no = '$id'";

	
	//$sql = "SELECT * From test_against_opd where opd_id='".$id."'";
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="EMPTY";
		}
		else
		{
	$data;
}

return $data;
}
/////////////////////////////////
public function show_xray(){
	$abc="SELECT * FROM  `x_ray`";
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="EMPTY";
		}
		else
		{
	$data;
}
return $data;
}
////////////////////////////////////////
public function show_ct_scan(){
	$sql="SELECT * FROM  `ct_scan` ";
	$data = $this->CustomQuery($sql);
		if(empty($data)){
		$data ="EMPTY";
		}
		else
		{
	$data;
}
return $data;
}
///////////////////////////////////
public function search_pharmacy_by_ward_id(){
	extract($_POST);
	$system_date=date("Y/m/d");
	$abc="SELECT *
FROM ward_medicine AS w
LEFT JOIN phar_ward AS p ON ( w.ward_id = p.ward_id )
WHERE w.ward_id = '$id'";

	
	//$sql = "SELECT * From test_against_opd where opd_id='".$id."'";
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="EMPTY";
		}
		else
		{
	$data;
}

return $data;
}
/////////////advance search/////////

public function advancesearch(){
	extract($_POST);
	
	$abc="SELECT *
FROM patient_record AS p
WHERE P.patient_id='$clue' or P.opd_id = '$clue' or P.name = '$clue' or P.father_name = '$clue'";

	
	//$sql = "SELECT * From test_against_opd where opd_id='".$id."'";
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="No Record Found";
		}
		else
		{
	$data;
}

return $data;
}

//////////////////////////////////////
	public function getAllPat($start,$limit,$q){
		
				$sql = "SELECT * FROM opd_pat_reg $q order by opd_unique_no LIMIT ".$start.",".$limit;
			
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	public function getAlltests(){
		
				$sql = "SELECT * FROM tests1";
			
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	/////////xray tests
	public function getAll_x_ray_test(){
		
				$sql = "SELECT * FROM  x_ray";
			
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	////////////////////////////////////////////
	public function get_pharmacy_update_item(){
		
				$sql = "SELECT m.date AS date, m.time AS time, p.item_name AS item, p.item_desc AS item_desc, m.quan_add AS add_quan, m.quantity AS new_quan, m.old_quan AS old_quan, e.emp_name AS empname
FROM  `manage_stock` AS m,  `phar_item` AS p, um_users AS u, hr_employee AS e
WHERE m.isbn_no = p.isbn_no
AND m.user_id = u.user_id
AND u.employee_id = e.employee_id";
			
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	////////////////////////////////////////////
	public function get_pharmacy_added_item(){
		
				$sql = "SELECT p.date AS date, p.time AS time, p.item_name AS item, p.item_desc AS item_desc, p.ini_qty AS qty, p.expiry AS exp, e.emp_name AS empname
FROM `phar_item` AS p, um_users AS u, hr_employee AS e
WHERE p.user_id = u.user_id
AND u.employee_id = e.employee_id
AND p.ini_qty>0
ORDER BY date";
			
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	/////////////////////////////////
	public function opd_patient_medication($id){
		       $date=date('Y');
				$sql = "SELECT p.id AS id, p.opd_no AS opd, p.date AS date, p.time AS time, i.item_name AS item, p.quantity_given AS qty
FROM `patient_medicine` AS p, `phar_item` AS i
WHERE p.isbn_no = i.isbn_no
AND p.opd_no = '$id'
AND p.date LIKE '%$date%'";
			
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	////////////////cardialogy tests////////////
	public function getAll_cardialogy_tests(){
		
				$sql = "SELECT * FROM cardiology";
			
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	
		public function get_pharmacy_by_date(){
			$to_date=$_POST['to_date'];
			$date=date('Y');
			if($_POST['to_date']!="")
{
	$to_date=$_POST['to_date'];
	$date_is=date("Y/m/d",strtotime($to_date));
  $sql = "SELECT sum(pm.id) as id, pm.opd_no AS opd_no, o.NAME AS name, pr.item_name AS item, pm.quantity_given AS qty_given, pr.quantity as remain_quan, pm.date AS pdate, pm.time AS ptime
FROM patient_medicine AS pm, phar_item AS pr, opd AS o
WHERE pm.opd_no = o.YEAR
AND pm.gender = o.SEX
AND pm.isbn_no = pr.isbn_no
AND pm.date='$date_is'
AND o.OPDDATE LIKE '%$date%'
GROUP BY opd_no";
		}
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	////////////////////////////////////////////////////////////////////////////
	public function get_lab_by_date(){
			$to_date=$_POST['to_date'];
			$date=date('Y');
			if($_POST['to_date']!="")
{
	$to_date=$_POST['to_date'];
	$date_is=date("Y/m/d",strtotime($to_date));
  $sql = "SELECT * 
FROM pat_test AS t, opd AS o
WHERE t.OPD_NO = o.YEAR
AND t.ddate = '$date_is'
AND o.OPDDATE LIKE '%$date%'
GROUP BY t.opd_no asc";
	}
		$data = $this->CustomQuery($sql);	
		return $data;
	}
	////////////////////////////////////////////////////////////////////////////
	public function get_nultra_by_date(){
			$to_date=$_POST['to_date'];
			$date=date("Y");
			if($_POST['to_date']!="")
{
	$to_date=$_POST['to_date'];
	$date_is=date("Y/m/d",strtotime($to_date));
  $sql = "SELECT * 
FROM pat_ultra_result AS t, opd AS o, ultrasound_type as u
WHERE t.opd_no = o.YEAR
AND t.ultra_id=u.ultra_id
AND t.date = '$date_is'
AND o.OPDDATE LIKE '%$date%'
GROUP BY t.opd_no asc";
	}
		$data = $this->CustomQuery($sql);	
		return $data;
	}
	////////////////////////////////////////////////////////////////////////////
	public function get_xray_by_date(){
			$to_date=$_POST['to_date'];
			$date=date("Y");
			if($_POST['to_date']!="")
{
	$to_date=$_POST['to_date'];
	$date_is=date("Y/m/d",strtotime($to_date));
  $sql = "SELECT * 
FROM test_against_x_ray AS t, opd AS o, x_ray as x
WHERE t.opd_no = o.YEAR
AND t.gender = o.SEX 
AND t.x_ray_id = x.x_test_id
AND t.opd_date = '$date_is'
AND o.OPDDATE LIKE '%$date%'
GROUP BY t.opd_no ASC";
	}
		$data = $this->CustomQuery($sql);	
		return $data;
	}
	////////////////////////////////////////////////////////////////////////////
	public function get_ecg_by_date(){
			$to_date=$_POST['to_date'];
			$date=date("Y");
			if($_POST['to_date']!="")
{
	$to_date=$_POST['to_date'];
	$date_is=date("Y/m/d",strtotime($to_date));
  $sql = "SELECT * 
FROM  `card_ecg` AS c, opd AS o
WHERE c.opd_no = o.YEAR
AND c.gender = o.SEX
AND c.date = '$date_is'
AND o.OPDDATE LIKE '%$date%'";
	}
		$data = $this->CustomQuery($sql);	
		return $data;
	}
	////////////////////////////////////////////////////////////////////////////
	public function get_echo_by_date(){
		$date=date("Y");
			$to_date=$_POST['to_date'];
			if($_POST['to_date']!="")
{
	$to_date=$_POST['to_date'];
	$date_is=date("Y/m/d",strtotime($to_date));
  $sql = "SELECT * 
FROM  `card_echo` AS c, opd AS o
WHERE c.opd_no = o.YEAR
AND c.gender = o.SEX
AND c.date = '$date_is'
AND o.OPDDATE LIKE '%$date%'";
	}
		$data = $this->CustomQuery($sql);	
		return $data;
	}
	////////////////////////////////////////////////////////////////////////////
	public function get_pecho_by_date(){
		$date=date("Y");
			$to_date=$_POST['to_date'];
			if($_POST['to_date']!="")
{
	$to_date=$_POST['to_date'];
	$date_is=date("Y/m/d",strtotime($to_date));
  $sql = "SELECT * 
FROM  `card_pecho` AS c, opd AS o
WHERE c.opd_no = o.YEAR
AND c.gender = o.SEX
AND c.date = '$date_is'
AND o.OPDDATE LIKE '%$date%'";
	}
		$data = $this->CustomQuery($sql);	
		return $data;
	}
	////////////////////////////////////////////////////////////////////////////
	public function get_ett_by_date(){
		$date=date("Y");
			$to_date=$_POST['to_date'];
			if($_POST['to_date']!="")
{
	$to_date=$_POST['to_date'];
	$date_is=date("Y/m/d",strtotime($to_date));
  $sql = "SELECT * 
FROM  `card_ett` AS c, opd AS o
WHERE c.opd_no = o.YEAR
AND c.gender = o.SEX
AND c.date = '$date_is'
AND o.OPDDATE LIKE '%$date%'";
	}
		$data = $this->CustomQuery($sql);	
		return $data;
	}
	////////////////////////////////////////////////////////////////////////////
	public function get_holter_by_date(){
			$date=date("Y");
			$to_date=$_POST['to_date'];
			if($_POST['to_date']!="")
{
	$to_date=$_POST['to_date'];
	$date_is=date("Y/m/d",strtotime($to_date));
  $sql = "SELECT * 
FROM  `card_holter` AS c, opd AS o
WHERE c.opd_no = o.YEAR
AND c.gender = o.SEX
AND c.date = '$date_is'
AND o.OPDDATE LIKE '%$date%'";
	}
		$data = $this->CustomQuery($sql);	
		return $data;
	}
	////////////////////////////////////////////////////////////////////////////
	public function get_opd_by_date(){
			$to_date=$_POST['to_date'];
	$terminal_id=$_REQUEST['terminal_id'];
			if($_POST['to_date']!="")
{
	$to_date=$_POST['to_date'];
	$terminal_id=$_REQUEST['terminal_id'];
	//$where="";
	$date_is=date("Y/m/d",strtotime($to_date));
 $sql =mysql_query( "SELECT o.opddate as date, o.opd as opd, o.year as year, o.name as name, o.sex as sex, o.time as time, u.user_id as id, u.username as user
 FROM opd as o, um_users as u 
 WHERE o.user_id=u.user_id 
 and o.OPDDATE='$date_is' 
 AND o.USER_ID='$terminal_id'
 GROUP BY year asc");
	}
	else
	{
$sql = mysql_query("SELECT o.opddate as date, o.opd as opd, o.year as year, o.name as name, o.sex as sex, o.time as time, u.user_id as id, u.username as user
 FROM opd as o, um_users as u 
 WHERE o.user_id=u.user_id  
 AND o.USER_ID='$terminal_id'
 GROUP BY year asc");
		}
	

		$data = mysql_num_rows($sql);
		
		return $data;
	}
	////////////////////////////////////////////////////////////////////////////////
	public function get_opd_by_date1(){
			$to_date=$_POST['to_date'];
	$terminal_id=$_REQUEST['terminal_id'];
			if($_POST['to_date']!="")
{
	$to_date=$_POST['to_date'];
	$terminal_id=$_REQUEST['terminal_id'];
	//$where="";
	$date_is=date("Y/m/d",strtotime($to_date));
 $sql = "SELECT o.opddate as date, o.opd as opd, o.year as year, o.name as name, o.sex as sex, o.time as time, u.username as user, u.user_id as id
 FROM opd as o, um_users as u 
 WHERE o.user_id=u.user_id 
 and o.OPDDATE='$date_is' 
 AND o.USER_ID='$terminal_id'
 GROUP BY year asc";
	}
	else
	{
$sql = "SELECT o.opddate as date, o.opd as opd, o.year as year, o.name as name, o.sex as sex, o.time as time, u.username as user, u.user_id as id
 FROM opd as o, um_users as u 
 WHERE o.user_id=u.user_id  
 AND o.USER_ID='$terminal_id'
 GROUP BY year asc";
		}
	

		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	////////////////////////////////////////////////////////////////////////////////
	public function get_opd_by_month(){
		$sql="select * from opd, um_users";
		
	}
	/////////////////////////////////////////////////get opd availabilty//////////
	public function opd_availability($sql){
		
				
			
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	/////////////////////////////////////
	
	public function getPat($id){
		$data = $this->GetRecord('opd_pat_reg', 'opd_id', $id);
		return  $data;
	}
	public function get_patient_record($id){
		$data = $this->GetRecord('opd', 'YEAR', $id);
		return  $data;
	}
	
	
	
	public function updatePat(){
				extract($_POST);
		$uid=$_REQUEST['uid'];
	
					$sql  = "UPDATE opd_pat_reg SET opd_pat_name = '$name',opd_unique_no = '$opd_unique_no',
				 	opd_pat_gender = '$gender', 
				 	opd_pat_date= '$date' WHERE opd_id = '$uid'";
					
	if(mysql_query($sql)){
				return "User updated successfully!";
			}
		else{
			return "this username is not available!";
		}
	}
	
 
 
 
 public function deletePat($id){
		$sql = "DELETE";
	
		if($this->deleteRecord('opd_pat_reg', 'opd_id = '.$id)){
			return "User deleted";
		}
		
		
	}
 public function getall_opd(){
		$sql = "SELECT *
FROM `opdlist`
ORDER BY `opdlist`.`OPD` ASC";
		$data = $this->CustomQuery($sql);
		return $data;
 
 }
 ///////////////////////////////////////////////
 public function opd_monthly_report($date){
	    $date1=date("Y-m",strtotime($date));
		$sql = "SELECT OPDDATE, count( YEAR ) as opds, sum( RATE ) as amount
FROM `opd`
WHERE 	OPDDATE LIKE '%$date1%'
group by OPDDATE";
		$data = $this->CustomQuery($sql);
		return $data;
 
 }
////////////////////////////////////////////////
public function xray_monthly_report($date){
	    $date1=date("Y-m",strtotime($date));
		$sql = "SELECT opd_date, count( opd_no ) as opds, count( x_ray_id ) as xrays
FROM `test_against_x_ray`
WHERE opd_date LIKE '%$date1%'
group by opd_date";
		$data = $this->CustomQuery($sql);
		return $data;
 
 }
////////////////////////////////////////////////
public function opd_monthly_sum($date){
	   $date1=date("Y-m",strtotime($date));
		$sql = "SELECT sum( RATE ) as total, count( YEAR ) as opds
FROM `opd`
WHERE OPDDATE LIKE '%$date1%'";
		$data = $this->CustomQuery($sql);
		return $data;
 
 }
 public function xray_monthly_sum($date){
	   $date1=date("Y-m",strtotime($date));
		$sql = "SELECT count( opd_no ) as opds, count( x_ray_id ) as xrays
FROM `test_against_x_ray`
WHERE opd_date LIKE '%$date1%'";
		$data = $this->CustomQuery($sql);
		return $data;
 
 }
 ///////////////////////////////////////////////
 public function get_actual_amount_opd(){
	 $date=date("m");
	  $sq1 = "SELECT count( no_of_opds ) AS opds, sum( total_amount ) AS amount
FROM `opd_daily_revenue`
WHERE opd_date LIKE '%$date%'
GROUP BY opd_date LIKE '%$date%'";
		$data = $this->CustomQuery($sql);
		return $data;
 }
 /////////////////////////////////////////////
  public function getopd_report_by_id($id){
		$sql = "SELECT * FROM opd where `ID`='$id'";
		$data = $this->CustomQuery($sql);
		return $data;
 
 }
 public function getall_ward(){
		$sql = "SELECT * FROM phar_ward";
		$data = $this->CustomQuery($sql);
		return $data;
 
 }
//////////////////////////////////////////////////////////////////////////
 public function insert_pecho(){
	 if(isset($_POST['submit1'])=='save1'){
		 extract($_POST);
		 
		 $ip=getenv('REMOTE_ADDR');
		 $date=date('Y-m-d');
		 $time=date('H:i:s');
		 $user_id=$_SESSION['luser']['id'];
		 $com=nl2br($_POST['comment']);
		 $conc=nl2br($_POST['conclusion']);
		 $sql="INSERT INTO card_pecho SET `opd_no`='$opdno', `aortic_dim`='$aortic_dim', `l_atr_dim`='$l_atr_dim', `l_vent_dis_dim`='$l_vent_dis_dim', `l_vent_sys_dim`='$l_vent_sys_dim', `i_v_sep_thick`='$i_v_sep_thick', `l_v_p_wall_thick`='$l_v_p_wall_thick', `r_v_dim`='$r_v_dim', `f_short`='$f_short', `e_frac`='$e_frac', `ivrt`='$ivrt', `dct`='$dct', `vsd_grad`='$vsd_grad', `vsd_size`='$vsd_size', `vsd_mpa_size`='$vsd_mpa_size', `vsd_lpa_size`='$vsd_lpa_size', `vsd_rpa_size`='$vsd_rpa_size', `pap_sys`='$pap_sys', `pap_dias`='$pap_dias', `pda_sys`='$pda_sys', `pda_dias`='$pda_dias', `mit_peak`='$mit_peak', `mit_mean`='$mit_mean', `mit_vel`='$mit_vel', `mit_dop`='$mit_dop', `mit_2d`='$mit_2d', `mit_reg`='$mit_reg', `tri_peak`='$tri_peak', `tri_mean`='$tri_mean', `tri_vel`='$tri_vel', `tri_dop`='$tri_dop', `tri_2d`='$tri_2d', `tri_reg`='$tri_reg', `aor_peak`='$aor_peak', `aor_mean`='$aor_mean', `aor_vel`='$aor_vel', `aor_dop`='$aor_dop', `aor_2d`='$aor_2d', `aor_reg`='$aor_reg', `pul_peak`='$pul_peak', `pul_mean`='$pul_mean', `pul_vel`='$pul_vel', `pul_dop`='$pul_dop', `pul_2d`='$pul_2d', `pul_reg`='$pul_reg', `comment`='$com', `conclusion`='$conc', gender='$gen', `ip`='$ip', `date`='$date', `time`='$time', `user_id`='$user_id'";
		 if(mysql_query($sql)){
			 $id=mysql_insert_id();
			 ?>
             <script>window.open("report/pecho_report.php?id=<?= $id; ?>");</script>
             <?php
		 }
		 }
 }
/////////////////////////////////////////////////////////////////////////////
public function show_pecho($id){
	$sql="SELECT * FROM `card_pecho` AS e, `opd` AS o WHERE e.opd_no=o.YEAR AND e.id='$id' and e.gender=o.SEX";
	$data = $this->CustomQuery($sql);
	return $data;
}
/////////////////////////////////////////////////////////////////////////////
public function show_pecho1($id){
	$sql="SELECT * FROM `card_pecho` AS e, `opd` AS o WHERE e.opd_no=o.YEAR AND e.opd_no='$id' and e.gender=o.SEX";
	$data = $this->CustomQuery($sql);
	return $data;
}
/////////////////////////////////////////////////////////////////////////////
 public function insert_echo(){
	 if(isset($_POST['submit'])=='save'){
		 extract($_POST);
		 $ip=getenv('REMOTE_ADDR');
		 $date=date('Y-m-d');
		 $time=date('H:i:s');
		 $user_id=$_SESSION['luser']['id'];
		 $com1=nl2br($_POST['comment1']);
		 $con1=nl2br($_POST['conclusion1']);
		 $sql="INSERT INTO card_echo SET `opd_no`='$opdno1', `aortic_dim1`='$aortic_dim1', `epss`='$epss', `l_atr_dim1`='$l_atr_dim1', `pht`='$pht', `l_vent_dis_dim1`='$l_vent_dis_dim1', `evel`='$evel', `l_vent_sys_dim1`='$l_vent_sys_dim1', `avel`='$avel', `i_v_sep_thick1`='$i_v_sep_thick1', `aratio`='$aratio', `l_v_p_wall_thick1`='$l_v_p_wall_thick1', `rsys`='$rsys', `r_v_dim1`='$r_v_dim1', `rdias`='$rdias', `f_short1`='$f_short1', `e_frac1`='$e_frac1', `ivrt1`='$ivrt1', `dct1`='$dct1', `mit_peak1`='$mit_peak1', `mit_mean1`='$mit_mean1', `mit_vel1`='$mit_vel1', `mit_dop1`='$mit_dop1', `mit_2d1`='$mit_2d1', `mit_reg1`='$mit_reg1', `tri_peak1`='$tri_peak1', `tri_mean1`='$tri_mean1', `tri_vel1`='$tri_vel1', `tri_dop1`='$tri_dop1', `tri_2d1`='$tri_2d1', `tri_reg1`='$tri_reg1', `aor_peak1`='$aor_peak1', `aor_mean1`='$aor_mean1', `aor_vel1`='$aor_vel1', `aor_dop1`='$aor_dop1', `aor_2d1`='$aor_2d1', `aor_reg1`='$aor_reg1', `pul_peak1`='$pul_peak1', `pul_mean1`='$pul_mean1', `pul_vel1`='$pul_vel1', `pul_dop1`='$pul_dop1', `pul_2d1`='$pul_2d1', `pul_reg1`='$pul_reg1', 
		 `comment1`='$com1', `conclusion1`='$con1', gender='$gen1', `ip`='$ip', `date`='$date', `time`='$time', `user_id`='$user_id'";
		 if(mysql_query($sql)){
			 $id=mysql_insert_id();
			 ?>
             <script>window.open("report/echo_report.php?id=<?= $id; ?>");</script>
             <?php
		 }
		 }
 }
///////////////////////////////////////////////////////////////////////////////////////////////////
 public function show_echo($id){
	$sql="SELECT * FROM `card_echo` AS e, `opd` AS o WHERE e.opd_no=o.YEAR AND e.id='$id' and e.gender=o.SEX";
	$data = $this->CustomQuery($sql);
	return $data;
}
////////////////////////////////////////////////////////////////////////////////////
 public function show_echo1($id){
	$sql="SELECT * FROM `card_echo` AS e, `opd` AS o WHERE e.opd_no=o.YEAR AND e.opd_no='$id' and e.gender=o.SEX";
	$data = $this->CustomQuery($sql);
	return $data;
}
////////////////////////////////////////////////////////////////////////////////////
 public function insert_ett(){
	 if(isset($_POST['submit2'])=='save2'){
		 extract($_POST);
		 $ip=getenv('REMOTE_ADDR');
		 $date=date('Y-m-d');
		 $time=date('H:i:s');
		 $user_id=$_SESSION['luser']['id'];
		 $arr=array($_POST['r_bp'],$_POST['r_bp2']);
		 $arr_r_bp=implode("/",$arr);
		 $arr2=array($_POST['mbp'],$_POST['mbp2']);
		 $arr_mbp=implode("/",$arr2);
		 $arr3=array($_POST['bp_rec'],$_POST['bp_rec2']);
		 $arr_bp_rec=implode("/",$arr3);
		$sql="INSERT INTO card_ett SET `opd_no`='$opdno2', `i_ett`='$i_ett', `c_med`='$c_med', `r_fac`='$r_fac', `e_time`='$e_time', `phr`='$phr', `ach`='$ach', `rhr`='$rhr', `prot`='$prot', `mhr`='$mhr', `r_bp`='$arr_r_bp', `mbp`='$arr_mbp', `bp_rec`='$arr_bp_rec', `l_fac`='$l_fac', `r_ecg`='$r_ecg', `p_e_ecg`='$p_e_ecg', `p_ex_ecg`='$p_ex_ecg', `imp`='$imp', gender='$gen2', `ip`='$ip', `date`='$date', `time`='$time', `user_id`='$user_id'";
		 if(mysql_query($sql)){
			 $id=mysql_insert_id();
			 ?>
             <script>window.open("report/ett_report.php?id=<?= $id; ?>");</script>
             <?php
		 }
		 }
 }
 ////////////////////////////////////////////////////////////////////////////
 public function show_ett($id){
	$sql="SELECT * FROM `card_ett` AS e, `opd` AS o WHERE e.opd_no=o.YEAR AND e.id='$id' and e.gender=o.SEX";
	$data = $this->CustomQuery($sql);
	return $data;
}
////////////////////////////////////////////////////////////////////////////////////
public function show_ett1($id){
	$sql="SELECT * FROM `card_ett` AS e, `opd` AS o WHERE e.opd_no=o.YEAR AND e.opd_no='$id' and e.gender=o.SEX";
	$data = $this->CustomQuery($sql);
	return $data;
}
////////////////////////////////////////////////////////////////////////////////////
public function insert_ecg(){
	 if(isset($_POST['submit3'])=='save3'){
		 extract($_POST);
		 $ip=getenv('REMOTE_ADDR');
		 $date=date('Y-m-d');
		 $time=date('H:i:s');
		 $user_id=$_SESSION['luser']['id'];
		 $sql="INSERT INTO card_ecg SET `opd_no`='$opdno3', `done`='$done', gender='$gen3', `ip`='$ip', `date`='$date', `time`='$time', `user_id`='$user_id'";
		 if(mysql_query($sql)){
			 $id=mysql_insert_id();
			 ?>
              <script>window.open("report/ecg_report.php?id=<?= $id; ?>");</script>
             <?php 
		 }
		 }
 }
////////////////////////////////////////////////////////////////////////////////////
public function show_ecg($id){
	$sql="SELECT * FROM `card_ecg` AS G, `opd` AS o WHERE G.opd_no=o.YEAR AND G.id='$id' and G.gender=o.SEX";
	$data = $this->CustomQuery($sql);
	return $data;
}
//////////////////////////////////////////////////
public function show_holter($id){
	$sql="SELECT * FROM `card_holter` AS H, `opd` AS o WHERE H.opd_no=o.YEAR AND H.id='$id' and H.gender=o.SEX";
	$data = $this->CustomQuery($sql);
	return $data;
}

////////////////////////////////////////////////////////////////////////////////////
public function show_ecg1($id){
	$sql="SELECT * FROM `card_ecg` AS G, `opd` AS o WHERE G.opd_no=o.YEAR AND G.opd_no='$id' and G.gender=o.SEX";
	$data = $this->CustomQuery($sql);
	return $data;
}
//////////////////////////////////////////////////
public function show_holter1($id){
	$sql="SELECT * FROM `card_holter` AS H, `opd` AS o WHERE H.opd_no=o.YEAR AND H.opd_no='$id' and H.gender=o.SEX";
	$data = $this->CustomQuery($sql);
	return $data;
}

////////////////////////////////////////////////////////////////////////////////////
public function insert_holter(){
	 if(isset($_POST['submit4'])=='save4'){
		 extract($_POST);
		 $ip=getenv('REMOTE_ADDR');
		 $date=date('Y-m-d');
		 $time=date('H:i:s');
		 $user_id=$_SESSION['luser']['id'];
		 $sql="INSERT INTO card_holter SET `opd_no`='$opdno4', `done1`='$done1', gender='$gen4', `ip`='$ip', `date`='$date', `time`='$time', `user_id`='$user_id'";
		 if(mysql_query($sql)){
			 $id=mysql_insert_id();
			 ?>
             <script>window.open("report/holter_report.php?id=<?= $id;?>");</script>
             <?php
		 }
		 }
 }
////////////////////////////////////////////////////////////////////////////////////
}
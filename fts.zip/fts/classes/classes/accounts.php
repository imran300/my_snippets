<?php 
class Accounts extends DBAccess{
	function Accounts(){
		$this->connectToDB();
	}
	public function maximum_number(){
		
				$sql = "SELECT * FROM  opd";
			
		$data = $this->totalRecordsInQuery_max($sql);
		
		return $data;
	}
	function total_max($sql)
	{
		if(empty($sql))
			return false;
			
			$q = mysql_query($sql) or die(mysql_error());
			$r=mysql_fetch_array($q);
			//$num = mysql_num_rows($q);
			$max=$r['mx'];
			return $max;
	}
 public function maximum_number_lab($pdno,$no){
		
$sql="SELECT IFNULL(MAX(`LAB`),0)+1 FROM `pat_test` AS mx
WHERE `PDNO`='$pdno' AND `TNO`='$no'";

		$data = $this->total_max($sql);
		
		return $data;
	}
 	
	public function add_head(){
	 $ip = getenv("REMOTE_ADDR");
date_default_timezone_set('Asia/karachi');
	$TIME = date("h:i:s", time());
	extract($_POST);
		$date=date('Y-m-d');
	  $sql  = "INSERT INTO  ac_head SET
	                
	 				
				 	ac_head_name = '$head_name',
					date='$date',
					time='$TIME',
					ip='$ip',
					user_id=".$_SESSION['luser']['id']."";
			if(mysql_query($sql))
			{
				return "Head added successfully";
			}
			else
			{
				return "Head is not available";
				}
	}
	///////////////////////////////////////////
	public function deleteHeads($id){
		$sql = "DELETE";
		if($this->deleteRecord('ac_head', 'ac_head_no = '.$id)){
			return "User deleted";
		}
		
		
	}
 
	////////////////////////////
public function countAllHeads()
{
	$sql = "SELECT * FROM ac_head";
	$data = $this->totalRecordsInQuery($sql);
	return $data;
}
	
	public function getAllHeads($start,$limit,$q){
		
				$sql = "SELECT * FROM ac_head $q order by ac_head_no LIMIT ".$start.",".$limit;
			
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	
	//////////////////////////////////////////
	public function getHeads($id){
		$data = $this->GetRecord('ac_head', 'ac_head_no', $id);
		return  $data;
	}
	///////////////////////////////////////
	public function updateHeads(){
				extract($_POST);
		//$uid=$_REQUEST['uid'];
	
					$sql  = "UPDATE ac_head SET ac_head_name = '$head_name'
					
				 	 WHERE ac_head_no = '$head_id'";
					
	if(mysql_query($sql)){
				return "Test updated successfully!";
			}
		else{
			return "this Test is not available!";
		}
	}
	
	/////////////insert_patient_Detail///////////////
	public function insert_patient_Detail(){
	 $ip = getenv("REMOTE_ADDR");
   date_default_timezone_set('Asia/karachi');
	$TIME = date("h:i:s", time());


		extract($_POST);
		$date=date('Y-m-d');
		$test_count=$_REQUEST['test'];
	 $count=count($test_count);
	foreach($test_count as $row_test)
	{
		$sql_tests=mysql_query("INSERT INTO `test_against_opd` SET `opd_id`='$opd_no',`test_id`='$row_test',`pat_id`='0'");
		}
		$sql="INSERT INTO patient_record SET opd_unique_no='$opd_no',m_test_id='$row_test',remarks='$remarks',time='$TIME',date='$date',ip='$ip'";
		$data = mysql_query($sql);
		if($data)
		{
			header("Location:index.php?option=report&item=print_opd_patient_record&opd_id=$opd_no");
			return "Done Successfully !";
			}
			else
			{
				
							return "Operation Terminated !";
}
		//die($test);
	 
		
	}
	public function countAll_pat()
{
	$sql = "SELECT * FROM opd_pat_reg";
	$data = $this->totalRecordsInQuery($sql);
	return $data;
}
public function get_opd_by_no(){
	extract($_POST);
	$system_date=date("Y/m/d");
	$sql = "SELECT * FROM opd WHERE `OPDDATE`='$system_date' AND YEAR='".$id."'";
	$data = $this->CustomQuery($sql);
		if(empty($data)){
		$data ="EMPTY";
		}
		else
		{
	$data;
}

return $data;
}
////////////////////////////////////////////////////
public function get_pdno($id)
{
	
		 $sql="SELECT * From tests1 where TNO='$id'";
	$data =mysql_query($sql);
		if(empty($data)){
		$data ="EMPTY";
		}
		else
		{
	$data;
}
return $data;
}
////////////////////////////////////////////////
public function get_medications($id)
{
	
		$sql = "SELECT * From pharmacy AS P LEFT JOIN opd AS O ON(P.opd_id=O.YEAR) where patient_id='".$id."'";
	$data = $this->CustomQuery($sql);
		if(empty($data)){
		$data ="EMPTY";
		}
		else
		{
	$data;
}
return $data;
}
public function get_x_ray($id)
{
	
		$sql = "SELECT * From test_against_x_ray AS P LEFT JOIN opd AS O ON(P.opd_id=O.YEAR) LEFT JOIN x_ray AS X ON (P.x_test_id=X.x_test_id) where patient_id='".$id."'";
	$data = $this->CustomQuery($sql);
		if(empty($data)){
		$data ="EMPTY";
		}
		else
		{
	$data;
}
return $data;
}

////////////////
public function get_cardiology($id)
{
	
		$sql = "SELECT * From test_against_cardialogy AS P LEFT JOIN opd AS O ON(P.opd_id=O.YEAR) LEFT JOIN cardiology AS X ON (P.c_test_id=X.c_test_id) where patient_id='".$id."'";
	$data = $this->CustomQuery($sql);
		if(empty($data)){
		$data ="EMPTY";
		}
		else
		{
	$data;
}
return $data;
}
/////////

public function get_groups($pd,$tn)
{
	$sql = "SELECT * From `groups`  WHERE `PDNO`='$pd' AND `TNO`='$tn'";
	$data = $this->CustomQuery($sql);
		if(empty($data)){
		$data ="EMPTY";
		}
		else
		{
	$data;
}

return $data;
	}

////////////////
public function get_history($id)
{
	
		$sql = "SELECT * From patient_history AS H LEFT JOIN opd AS O ON(H.opd_id=O.YEAR) where patient_id='".$id."'";
	$data = $this->CustomQuery($sql);
		if(empty($data)){
		$data ="EMPTY";
		}
		else
		{
	$data;
}

return $data;
	}
	/////////////////////////////////////////////////////
	public function get_LabTest($id)
{
	$sql ="SELECT * FROM `test_against_opd` AS T LEFT JOIN opd AS O ON ( T.opd_id = O.YEAR ) LEFT JOIN `med_tests` AS M ON(T.test_id=M.m_test_id) where patient_id='".$id."'";


		//$sql = "SELECT * From patient_history AS H LEFT JOIN opd AS O ON(H.opd_id=O.YEAR) where patient_id='".$id."'";
	$data = $this->CustomQuery($sql);
		if(empty($data)){
		$data ="EMPTY";
		}
		else
		{
	$data;
}

return $data;
	}
////////////////////////////////////////////
public function search_test_by_opdno(){
	extract($_POST);
	$system_date=date("Y/m/d");
	$abc="SELECT *
FROM pat_test AS t
LEFT JOIN opd AS o ON (t.OPD_NO = o.YEAR)
LEFT JOIN tests1 AS M ON (t.PDNO=M.PDNO && t.TNO=M.TNO)
WHERE t.OPD_NO = '$id' AND o.OPDDATE='$system_date' AND t.DDATE='$system_date'";
	//$sql = "SELECT * From test_against_opd where opd_id='".$id."'";
	/////$system_date=date("Y/m/d"); AND o.OPDDATE='$system_date' AND t.date='$system_date'
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="No Record Found";
		}
		else
		{
	$data;
}

return $data;
}
public function search_test_by_opdno_for_report($opd_no){
	extract($_POST);
	$system_date=date("Y/m/d");
	$abc="SELECT *
FROM pat_result AS t
LEFT JOIN opd AS o ON (t.OPD_NO = o.YEAR)
LEFT JOIN tests1 AS M ON (t.PDNO=M.PDNO && t.TNO=M.TNO)
WHERE t.OPD_NO = '$opd_no' AND o.OPDDATE='$system_date' AND t.DATE='$system_date' AND t.GNO='0' AND t.SGNO='0' GROUP BY t.PDNO,t.TNO,t.GNO";
	//$sql = "SELECT * From test_against_opd where opd_id='".$id."'";
	/////$system_date=date("Y/m/d"); AND o.OPDDATE='$system_date' AND t.date='$system_date'
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="No Record Found";
		}
		else
		{
	$data;
}

return $data;
}
////////////
public function search_test_by_opdno_for_report_second($opd_no){
	extract($_POST);
	//$system_date=date("Y/m/d");
	$abc="SELECT *
FROM pat_result AS t
LEFT JOIN opd AS o ON (t.OPD_NO = o.YEAR)
LEFT JOIN tests1 AS M ON (t.PDNO=M.PDNO && t.TNO=M.TNO)
WHERE t.OPD_NO = '$opd_no' AND t.GNO='0' AND t.SGNO='0' GROUP BY t.PDNO,t.TNO,t.GNO";
	//$sql = "SELECT * From test_against_opd where opd_id='".$id."'";
	/////$system_date=date("Y/m/d"); AND o.OPDDATE='$system_date' AND t.date='$system_date'
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="No Record Found";
		}
		else
		{
	$data;
}

return $data;
}

public function search_x_ray_by_opdno(){
	extract($_POST);
$system_date=date("Y/m/d");
		///// AND o.OPDDATE='$system_date' AND t.date='$system_date'
	$abc="SELECT *
FROM test_against_x_ray AS t
LEFT JOIN opd AS o ON ( t.opd_id = o.YEAR)
LEFT JOIN x_ray AS M ON (t.x_test_id=M.x_test_id)
WHERE t.opd_id = '$id' AND o.OPDDATE='$system_date' AND t.date='$system_date'";

	
	//$sql = "SELECT * From test_against_opd where opd_id='".$id."'";
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="No Record Found";
		}
		else
		{
	$data;
}

return $data;
}

public function search_cardialogy_by_opdno(){
	extract($_POST);
	$system_date=date("Y/m/d");
	/////$system_date=date("Y/m/d"); AND o.OPDDATE='$system_date' AND t.date='$system_date'
	$abc="SELECT *
FROM test_against_cardialogy AS t
LEFT JOIN opd AS o ON ( t.opd_id = o.YEAR)
LEFT JOIN cardiology AS M ON (t.c_test_id=M.c_test_id)
WHERE t.opd_id = '$id' AND o.OPDDATE='$system_date' AND t.date='$system_date'";

	
	//$sql = "SELECT * From test_against_opd where opd_id='".$id."'";
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="No Record Found";
		}
		else
		{
	$data;
}

return $data;
}

////////////////////////////////////////////
public function search_pharmacy_by_opdno(){
	extract($_POST);
	$system_date=date("Y/m/d");
	$abc="SELECT *
FROM pharmacy AS t
LEFT JOIN opd AS o ON ( t.opd_id = o.YEAR )
WHERE t.opd_id = '$id' AND o.OPDDATE='$system_date' AND t.date='$system_date'";

	
	//$sql = "SELECT * From test_against_opd where opd_id='".$id."'";
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="EMPTY";
		}
		else
		{
	$data;
}

return $data;
}
/////////////advance search/////////

public function advancesearch(){
	extract($_POST);
	
	$abc="SELECT *
FROM patient_record AS p
WHERE P.patient_id='$clue' or P.opd_id = '$clue' or P.name = '$clue' or P.father_name = '$clue'";

	
	//$sql = "SELECT * From test_against_opd where opd_id='".$id."'";
	$data = $this->CustomQuery($abc);
		if(empty($data)){
		$data ="No Record Found";
		}
		else
		{
	$data;
}

return $data;
}

//////////////////////////////////////
	public function getAllPat($start,$limit,$q){
		
				$sql = "SELECT * FROM opd_pat_reg $q order by opd_unique_no LIMIT ".$start.",".$limit;
			
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	public function getAlltests(){
		
				$sql = "SELECT * FROM tests1";
			
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	/////////xray tests
	public function getAll_x_ray_test(){
		
				$sql = "SELECT * FROM  x_ray";
			
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	////////////////cardialogy tests////////////
	public function getAll_cardialogy_tests(){
		
				$sql = "SELECT * FROM cardiology";
			
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
		public function get_opd_by_date(){
			$to_date=$_POST['to_date'];
	$terminal_id=$_REQUEST['terminal_id'];
			if($_POST['to_date']!="")
{
	$to_date=$_POST['to_date'];
	$terminal_id=$_REQUEST['terminal_id'];
	//$where="";
	$date_is=date("Y/m/d",strtotime($to_date));
 $sql = "SELECT * FROM opd WHERE OPDDATE='$date_is' AND USER_ID='$terminal_id'";
	}
	else
	{
$sql = "SELECT * FROM opd where USER_ID='$terminal_id'";
		}
	

		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	/////////////////////////////////////////////////get opd availabilty//////////
	public function opd_availability($sql){
		
				
			
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	/////////////////////////////////////
	
	public function getPat($id){
		$data = $this->GetRecord('opd_pat_reg', 'opd_id', $id);
		return  $data;
	}
	public function get_patient_record($id){
		$data = $this->GetRecord('opd', 'YEAR', $id);
		return  $data;
	}
	
	
	
	public function updatePat(){
				extract($_POST);
		$uid=$_REQUEST['uid'];
	
					$sql  = "UPDATE opd_pat_reg SET opd_pat_name = '$name',opd_unique_no = '$opd_unique_no',
				 	opd_pat_gender = '$gender', 
				 	opd_pat_date= '$date' WHERE opd_id = '$uid'";
					
	if(mysql_query($sql)){
				return "User updated successfully!";
			}
		else{
			return "this username is not available!";
		}
	}
	
 
 
 
 public function deletePat($id){
		$sql = "DELETE";
	
		if($this->deleteRecord('opd_pat_reg', 'opd_id = '.$id)){
			return "User deleted";
		}
		
		
	}
 public function getall_opd(){
		$sql = "SELECT * FROM opdlist";
		$data = $this->CustomQuery($sql);
		return $data;
 
 }
  public function getopd_report_by_id($id){
		$sql = "SELECT * FROM opd where `ID`='$id'";
		$data = $this->CustomQuery($sql);
		return $data;
 
 }
 
	
     

   
     


	
	
}
<?php
class Menu extends DBAccess{
	function Menu(){
		$this->connectToDB();
	}
	public function listMenus(){
		$sql = "SELECT * FROM um_menu order by parent_id";
		$data = $this->CustomQuery($sql);
		$menus = array();
		foreach($data as $m){
			$parent = $m['parent_id'];
			if($m['parent_id'] == 0){
				$menus[] = array(
					'id' => $m['menu_id'],
					'title' => $m['menu_text'],
					'href'	=> $m['url'],
					'parent'=>$m['parent_id'],
					'order'	=> $m['sort_order'],
					'child'	=> $this->getChildMenus($data,$m['menu_id'])
					);
			}
		}
		return $menus;
	}
	public function getChildMenus($menus, $id){
		$data = array();
		foreach ($menus as $m){
			if($m['parent_id'] == $id){
				
				$data[] = array(
							'id' => $m['menu_id'],
							'title' => $m['menu_text'],
							'href'	=> $m['url'],
							'parent'=>$m['parent_id'],
							'order'	=> $m['sort_order']
							);
			}
		}
		return $data;
	}
	
	public function getMenu($id){
		$data = $this->GetRecord('um_menu', 'menu_id', $id);
		return $data;
	}
	public function getAllMenus(){
		
	}
	
	public function addMenu(){
		extract($_POST);
		if(isset($show_in_menu)){
			$show_in_menu = 1;
		}else{
			$show_in_menu = 0;
		}
		$sql = "INSERT INTO um_menu SET
				menu_text = '$menu_text',
				url = '$url',
				parent_id = '$parent_id',
				show_in_menu = '$show_in_menu',
				sort_order = '$sort_order'	
				";
		if(mysql_query($sql)){
			return "New menu has been added";
			unset($_POST);
		}else{
			return "cannot add menu, please try again";
		}
	}
	public function updateMenu(){
		extract($_POST);
	if(isset($show_in_menu)){
			$show_in_menu = 1;
		}else{
			$show_in_menu = 0;
		}
		$sql = "UPDATE um_menu SET
				menu_text = '$menu_text',
				url = '$url',
				parent_id = '$parent_id',
				show_in_menu = '$show_in_menu',
				sort_order = '$sort_order'
				WHERE menu_id = $menu_id	
				";
		if(mysql_query($sql)){
			return "Menu has been updated";
			unset($_POST);
		}else{
			return "cannot update menu, please try again";
		}
	}
	public function deleteMenu(){
		
	}
	public function getMenuDD($name, $selected, $text, $options){
		$employees = $this->getAllParentMenus("");
		$html = "<select name='$name' id='$name' $options >";
		
		$html .= "<option value='0'>$text</option>";
		
		foreach ($employees as $emp){
			$selected_item = '';
			if($selected == $emp['menu_id']){
				$selected_item = "selected='selected'";
			}
			$html .= "<option $selected_item value='".$emp['menu_id']."'>".$emp['menu_text']."</option>";
		}
		$html .= "</select>";
		return $html;
	}
	public function getAllParentMenus(){
		$sql = "SELECT * FROM um_menu WHERE parent_id = 0";
		$data = $this->CustomQuery($sql);
		return $data;
	}
	public function listMenusPermissions($group){
		$sql = "SELECT * FROM um_menu order by parent_id";
		$data1 = $this->CustomQuery($sql);
		$data = array();
		foreach($data1 as $d1){
			$data[] = array(
				'menu_id' => $d1['menu_id'],
				'menu_text' =>$d1['menu_text'],
				'url' => $d1['url'],
				'parent_id' => $d1['parent_id'],
				'sort_order' => $d1['sort_order'],
				'permissions' => $this->findPermissions($d1['menu_id'],$group,'pview'),
				
				);
		}
		
		
		$menus = array();
		foreach($data as $m){
			$parent = $m['parent_id'];
			if($m['parent_id'] == 0){
				$menus[] = array(
					'id' => $m['menu_id'],
					'title' => $m['menu_text'],
					'href'	=> $m['url'],
					'parent'=>$m['parent_id'],
					'order'	=> $m['sort_order'],
					'permissions' => $m['permissions'],
					'child'	=> $this->getChildMenusPermissions($data,$m['menu_id'])
					);
			}
		}
		
	
		
		return $menus;
	}
	public function getChildMenusPermissions($menus, $id){
		$data = array();
		foreach ($menus as $m){
			if($m['parent_id'] == $id){
				
				$data[] = array(
							'id' => $m['menu_id'],
							'title' => $m['menu_text'],
							'href'	=> $m['url'],
							'parent'=>$m['parent_id'],
							'order'	=> $m['sort_order'],
							'permissions' => $m['permissions'],
							);
			}
		}
		return $data;
	}
	public function findPermissions($menu_id,$group_id,$option){
		$sql = "SELECT * FROM um_permissions WHERE menu_id = $menu_id AND group_id = $group_id";
		$rs = $this->getRecordBySql($sql);
		$data = array(
			'view' => $rs['pview'],
			'add' => $rs['padd'],
			'edit' => $rs['pedit'],
			'delete' =>$rs['pdelete'],
			);
		return $data;
	}
	
}
?>
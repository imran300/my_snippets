<?php
class General extends DBaccess
{
function General()
{
	$this->connectToDB();
	
}
public function maximum_number_test_1(){
		
				$sql = "SELECT * FROM  tests1";
			
		$data = $this->totalRecordsInQuery_max($sql);
		
		return $data;
	}
function addGender()
{
 extract($_POST);
$query = mysql_query("SELECT * FROM gen_gender where gender_title='".$gentitle."'");
$row=mysql_fetch_array($query);

	if(empty($gentitle) || $gentitle=='Gender Title')
 	 {return $this->error="Please Enter title"; }
    else{
			if(empty($row['gender_title']))
					{
						$insert="gender_title";
						$vals="'".mysql_real_escape_string($gentitle)."'";
						$id=$this->InsertRecord("gen_gender",$insert,$vals);
						unset($_POST);
           		    	$this->success="Gender has been added successfully";
						return $id;	
					}
			 else 
			return $this->err="Gender already exists.";
						 
 }

}
function getAllGender($start,$limit,$q)
{
	$sql = "SELECT * FROM gen_gender $q order by gender_title LIMIT ".$start.", ".$limit;
	
	$data = $this->CustomQuery($sql);
	if(empty($data)){
		$data = array();
	}
	return $data;	
}
function countAllGender()
{
	$sql = "SELECT * FROM gen_gender";
	$data = $this->totalRecordsInQuery($sql);
	return $data;	
}
function searchGender($q)
{
	$sql = "SELECT * FROM gen_gender".$q;
	$data = $this->CustomQuery($sql);
		if(empty($data)){
		$data = array();
	}
	return $data;	
}
 function getSepcificGender($genid)
      {
          $sql = "SELECT * FROM gen_gender where gender_id='" . $genid . "'";
          $data = $this->CustomQuery($sql);
          return $data;
      }

 function updateGender($genid)
 {
 extract($_POST);
 $sql = "UPDATE  gen_gender set gender_title='" . $gentitle . "' where gender_id='" . $genid . "' ";
		unset($_POST);
		
		 $this->success="Gender has been updated successfully";
	 return $this->CustomModify($sql);
			
			
 }	 
 
  function deleteGender($gid)
      {
          $this->deleteRecord("gen_gender", "gender_id=" . $gid);
          return true;
      }  
function addDesignation()
{
 extract($_POST);
$query = mysql_query("SELECT * FROM gen_designations where designation_title='".$designation_title."'");
$row=mysql_fetch_array($query);
if(empty($designation_title))
{
return $this->error="Please Enter title";
  
}
else{
		if(empty($row['designation_title']))
			{
			$insert="designation_title";
			$vals="'".mysql_real_escape_string($designation_title)."'";
			$id=$this->InsertRecord("gen_designations",$insert,$vals);
			unset($_POST);
            $this->success="Designation has been added successfully";
			return $id;	
			}
		else
		 return  $this->success="Designation already exists";
	}
 }
function getAllDesignation($start,$limit,$q)
{
	$sql = "SELECT * FROM gen_designations $q order by designation_title LIMIT ".$start.", ".$limit;
	$data = $this->CustomQuery($sql);
	if(empty($data)){
		$data = array();
	}
	return $data;	
}
function countAllDesignation()
{
	$sql = "SELECT * FROM gen_designations";
	$data = $this->totalRecordsInQuery($sql);
	return $data;	
}
  function deleteDesignation($did)
      {
          $this->deleteRecord("gen_designations", "designation_id=" . $did);
          return true;
      } 
 function getSepcificDesignation($desid)
      {
          $sql = "SELECT * FROM gen_designations where designation_id='" . $desid . "'";
          $data = $this->CustomQuery($sql);
          return $data;
      }

 function updateDesignation($desid)
 {
 extract($_POST);
 $sql = "UPDATE  gen_designations set designation_title='" . $designation_title . "' where designation_id='" . $desid . "' ";
		unset($_POST);
		
		 $this->success="Designations has been updated successfully";
	 return $this->CustomModify($sql);
			
			
 }	  

function getAllGroups($q){
		$sql = "SELECT * FROM um_groups $q ORDER BY group_title";
		$data = $this->CustomQuery($sql);
		return $data;
	}
	function getGroup($id){
		$data = $this->GetRecord('um_groups', 'group_id', $id);
		return $data;
	}
	function addGroup(){
		extract($_POST);
		if(empty($group_title)){
			return $this->error="Please Enter title";
		}else{
			$insert="group_title";
			$vals="'".mysql_real_escape_string($group_title)."'";
			$id=$this->InsertRecord("um_groups",$insert,$vals);
			unset($_POST);
			$this->success="Group title been added successfully";
			return $id;
		}
	}
	function updateGroup(){
		extract($_POST);
		$sql = "UPDATE um_groups SET group_title = '$group_title' WHERE group_id = $group_id ";
		$this->CustomModify($sql);
	
	}
	function deleteGroup($id){
		$this->deleteRecord("um_groups", "group_id=" . $id);
		return true;
	}  
	public function getGroupDD($name, $selected, $text, $options){
		$groups = $this->getAllGroups("");
		$html = "<select name='$name' id='$name' $options >";
		
		$html .= "<option value='0'>$text</option>";
		
		foreach ($groups as $g){
			$selected_item = '';
			if($selected == $g['group_id']){
				$selected_item = "selected='selected'";
			}
			$html .= "<option $selected_item value='".$g['group_id']."'>".$g['group_title']."</option>";
		}
		
		
		
		$html .= "</select>";
		return $html;
	}
	public function getChildMenus($menus, $id){
		$data = array();
		foreach ($menus as $m){
			if($m['parent_id'] == $id){
				
				$data[] = array(
							'id' => $m['menu_id'],
							'title' => $m['menu_text'],
							'href'	=> $m['url'],
							'parent'=>$m['parent_id'],
							'order'	=> $m['sort_order']
							);
			}
		}
		return $data;
	}
	public function mainNavigation(){
		
		$group = $_SESSION['luser']['group'];
		$sql = "SELECT * FROM um_menu as u 
			LEFT JOIN um_permissions as p ON (p.menu_id = u.menu_id)
			where u.show_in_menu = 1 
			AND
			p.group_id = $group
			AND 
			p.pview = 1
		order by u.sort_order";
		if($_SESSION['luser']['admin'] == 1){
			$sql = "SELECT * FROM um_menu as u 
				where u.show_in_menu = 1 
				order by u.sort_order";
		}
		$data = $this->CustomQuery($sql);
		
		$menus = array();
		foreach($data as $m){
			$parent = $m['parent_id'];
			if($m['parent_id'] == 0){
				$menus[] = array(
					'id' => $m['menu_id'],
					'title' => $m['menu_text'],
					'href'	=> $m['url'],
					'parent'=>$m['parent_id'],
					'order'	=> $m['sort_order'],
					'child'	=> $this->getChildMenus($data,$m['menu_id'])
					);
			}
		}
		return $menus;
	}
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $name
	 * @param unknown_type $id
	 * @param unknown_type $select
	 * @param unknown_type $selected
	 * @param unknown_type $text
	 */
	function getGenderDD($name, $id, $select, $selected,$text){
		$sql = "SELECT * FROM gen_gender order by gender_title ";
	    $values = $this->CustomQuery($sql);
		$html = "<select name='$name' id='$name' $text >";
		$html .= "<option value='0'>$select</option>";
		foreach ($values as $value){
			$selected_item = '';
			if($selected == $value['gender_id']){
				$selected_item = "selected='selected'";
			}
			$html .= "<option $selected_item value='".$value['gender_id']."'>".$value['gender_title']."</option>";
		}
		$html .= "</select>";
		return $html;
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param $name
	 * @param $id
	 * @param $select
	 * @param $selected
	 * @param $text
	 */
	function getDesignationDD($name, $id, $select, $selected,$text){
		$sql = "SELECT * FROM gen_designations order by designation_title ";
	    $values = $this->CustomQuery($sql);
		$html = "<select name='$name' id='$name' $text >";
		$html .= "<option value='0'>$select</option>";
		foreach ($values as $value){
			$selected_item = '';
			if($selected == $value['designation_id']){
				$selected_item = "selected='selected'";
			}
			$html .= "<option $selected_item value='".$value['designation_id']."'>".$value['designation_title']."</option>";
		}
		$html .= "</select>";
		return $html;
	}
	
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $name
	 * @param unknown_type $id
	 * @param unknown_type $select
	 * @param unknown_type $selected
	 * @param unknown_type $text
	 */
	
	function getCountryDD($name, $id, $select, $selected,$text){
		$sql = "SELECT * FROM countries order by countries_name ";
	    $values = $this->CustomQuery($sql);
		$html = "<select name='$name' id='$name' $text >";
		$html .= "<option value='0'>$select</option>";
		foreach ($values as $value){
			$selected_item = '';
			if($selected == $value['countries_id']){
				$selected_item = "selected='selected'";
			}
			$html .= "<option $selected_item value='".$value['countries_id']."'>".$value['countries_name']."</option>";
		}
		$html .= "</select>";
		return $html;
	}
	  
	  
	  
	  


	

}
?>
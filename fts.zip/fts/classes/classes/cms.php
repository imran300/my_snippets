<?php 
class Cms extends DBAccess{
	function Cms(){
		$this->connectToDB();
	}
	public function maximum_number(){
		
				$sql = "SELECT * FROM  opd_pat_reg";
			
		$data = $this->totalRecordsInQuery_max($sql);
		
		return $data;
	}
 public function maximum_number_test_1($test){
		
		$sql = "SELECT IFNULL(MAX(`TNO`),0)+1  AS mx FROM `tests1`
WHERE `PDNO`='$test'";
			
		$data = $this->total_max($sql);
		
		return $data;
	}
	//////////////////////////////////////////
	public function maximum_number_group($g_test,$groups){
		
		 $sql = "SELECT IFNULL(MAX(`GNO`),0)+1  AS mx FROM `groups`
WHERE `PDNO`='$g_test' AND TNO='$groups'";
			
		$data = $this->total_max($sql);
		
		return $data;
	}
	public function maximum_number_sgroup($s_test,$child,$sub_child){
		
		  $sql = "SELECT IFNULL(MAX(`SGNO`),0)+1  AS mx FROM `sgroups`
WHERE `PDNO`='$s_test' AND TNO='$child' AND GNO='$sub_child'";
			
		$data = $this->total_max($sql);
		
		return $data;
	}
	
	//////////////////////////////////////////
 	
	public function addPat(){
	 $ip = getenv("REMOTE_ADDR");
  $timezone = "Asia/Karachi";


		extract($_POST);
		
		$name_c=strtoupper($name);
		
		$date=date('Y-m-d');
	 $sql  = "INSERT INTO  opd_pat_reg SET
	                 opd_unique_no ='$opd_unique_no',
	 				 opd_pat_name = '$name_c',
				 	opd_pat_gender = '$gender', 
				 	opd_pat_date= '$date'";
				
			if(mysql_query($sql)){
				return "User added successfully!";
			}
		else{
			return "this username is not available!";
		}
		
	}
	///////////////////////////////////////////////////
	public function add_opd(){
	 $ip = getenv("REMOTE_ADDR");
  $timezone = "Asia/Karachi";


		extract($_POST);
		
		$name_c=strtoupper($name);
		if($day1!="-1")
		{
			$day_one=$day1;
			}
			else
			{
				$day_one="";
				}
		//////////////////////////////////////////FOR DAY2////////////////////////////
	if($day2!="-1")
		{
			$day_two=$day2;
			}
			else
			{
				$day_two="";
				}
				/////////////////FOR DAY 3///////////////////
				if($day3!="-1")
		{
			$day_three=$day3;
			}
			else
			{
				$day_three="";
				}
				/////////////////FOR DAY 4///////////////////
				if($day3!="-1")
		{
			$day_three=$day3;
			}
			else
			{
				$day_three="";
				}
				/////////////////FOR DAY 4///////////////////
				if($day4!="-1")
		{
			$day_four=$day4;
			}
			else
			{
				$day_four="";
				}
				/////////////////FOR DAY 5///////////////////
				if($day5!="-1")
		{
			$day_five=$day5;
			}
			else
			{
				$day_five="";
				}
				/////////////////FOR DAY 6///////////////////
				if($day6!="-1")
		{
			$day_six=$day6;
			}
			else
			{
				$day_six="";
				}
				
				
	
		$date=date('Y-m-d');
	  $sql  = "INSERT INTO  opdlist SET
	                 OPD ='$opd_name',
	 				RATE = '$opd_rate',
				 	ROOM = '$opd_room',
					DAY1='$day_one',
					DAY2='$day_two',
					DAY3='$day_three',
					DAY4='$day_four',
					DAY5='$day_five',
					DAY6='$day_six'";
			
			if(mysql_query($sql)){
				return "User added successfully!";
			}
		else{
			return "this username is not available!";
		}
		
	}
	////////////////////////////////////////////////////////////////////////
	public function addTest($no){
	 $ip = getenv("REMOTE_ADDR");
	 date_default_timezone_set('Asia/karachi');
	$TIME = date("h:i:s", time());


		extract($_POST);
		$date=date('Y-m-d');
	 $sql  = "INSERT INTO  tests1 SET
                    TNO='$no',	 
	                PDNO='$test',
	 				TNAME = '$t_name',
				 	NORMAL_FR = '$nor_fr',
					NORMAL_TO='$nor_to',
					UNIT='$unit',
					RATE ='$rate',
					COST='$cost',
					SPNO='$sp_no',
					SCHRGS='$s_charges',
					HEXP='$hexp',
					IPP_RATE='$ipp_rate'";
				 	
				
			if(mysql_query($sql)){
				return "Test added successfully!";
			}
		else{
			return "this Test is not available!";
		}
		
	}
//////////////////////////////////////////////////////
	
public function addTest_groups($no_max){
	 $ip = getenv("REMOTE_ADDR");
	 date_default_timezone_set('Asia/karachi');
	$TIME = date("h:i:s", time());


		extract($_POST);
		$date=date('Y-m-d');
	 $sql  = "INSERT INTO  groups SET	 
	                PDNO='$g_test',
					TNO='$groups',
					GNO='$no_max',
	 				GNAME = '$g_name',
				 	NORMAL_FR = '$g_nor_f',
					NORMAL_TO='$g_nor_to',
					UNIT='$g_unit',
					RATE ='$g_rate',
					COST='$g_cost',
					SPNO='$g_sp_no'";
			if(mysql_query($sql)){
				return "Test added successfully!";
			}
		else{
			return "this Test is not available!";
		}
		
	}
public function addTest_sub_groups($no_max_sub){
	 $ip = getenv("REMOTE_ADDR");
	 date_default_timezone_set('Asia/karachi');
	$TIME = date("h:i:s", time());


		extract($_POST);
		$date=date('Y-m-d');
	 $sql  = "INSERT INTO  sgroups SET	 
	                PDNO='$s_test',
					TNO='$child',
					GNO='$sub_child',
					SGNO='$no_max_sub',
	 				SGNAME = '$s_name',
				 	NORMAL_FR = '$s_nor_f',
					NORMAL_TO='$s_nor_to',
					UNIT='$s_unit',
					RATE ='$s_rate',
					COST='$s_cost',
					SPNO='$s_sp_no'";
			if(mysql_query($sql)){
				return "Test added successfully!";
			}
		else{
			return "this Test is not available!";
		}
		
	}


	/////////////////////////////////////////////////
	public function addC_test(){
	 $ip = getenv("REMOTE_ADDR");
	 date_default_timezone_set('Asia/karachi');
	$TIME = date("h:i:s", time());


		extract($_POST);
		$date=date('Y-m-d');
	 $sql  = "INSERT INTO  cardiology SET
	                
	 				c_test_name = '$ctest_name',
				 	c_test_rate = '$ctest_rate',
					time='$TIME',
					date='$date',
					ip='$ip'";
				 	
				
			if(mysql_query($sql)){
				return "Test added successfully!";
			}
		else{
			return "this Test is not available!";
		}
		
	}
	//////////////////////////////////////////////
	public function addX_Ray(){
	 $ip = getenv("REMOTE_ADDR");
	 date_default_timezone_set('Asia/karachi');
	$TIME = date("h:i:s", time());


		extract($_POST);
		$date=date('Y-m-d');
	 $sql  = "INSERT INTO  x_ray SET
	                
	 				x_test_name = '$x_name',
				 	x_test_rate = '$x_rate',
					time='$TIME',
					date='$date',
					ip='$ip'";
				 	
				
			if(mysql_query($sql)){
				return "Test added successfully!";
			}
		else{
			return "this Test is not available!";
		}
		
	}
	//////////////////////////////////////////////
	public function add_med(){
	 $ip = getenv("REMOTE_ADDR");
	 date_default_timezone_set('Asia/karachi');
	$TIME = date("h:i:s", time()); 
	extract($_POST);
		$date=date('Y-m-d');
$sql  = "INSERT INTO  medicines SET med_name='$m_name'";
			if(mysql_query($sql)){
				return "Test added successfully!";
			}
		else{
			return "this Test is not available!";
		}
		
	}
	////////////////////////////////////////////////////////////////
	public function addCT_scan(){
	 $ip = getenv("REMOTE_ADDR");
	 date_default_timezone_set('Asia/karachi');
	$TIME = date("h:i:s", time());


		extract($_POST);
		$date=date('Y-m-d');
	 $sql  = "INSERT INTO  ct_scan SET
	                
	 				ct_test_name = '$ct_name',
				 	ct_test_rate = '$ct_rate',
					time='$TIME',
					date='$date',
					ip='$ip'";
				 	
				
			if(mysql_query($sql)){
				return "Test added successfully!";
			}
		else{
			return "this Test is not available!";
		}
		
	}

	//////////////////////////////////////////////////////////////////////////////////////////
 public function GetallUsers(){
		
				$sql = "SELECT * FROM um_users";
			
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	///////////////////////////
	 public function getAllPdept(){
		
				$sql = "SELECT * FROM pdept";
			
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	/////////////////////////////////////
	 
	/////////////
	public function countAll_pat()
{
	$sql = "SELECT * FROM opd";
	$data = $this->totalRecordsInQuery($sql);
	return $data;
}
	public function getAllPat($start,$limit,$q){
		
				$sql = "SELECT * FROM opd $q order by YEAR LIMIT ".$start.",".$limit;
			
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	//////////////OPD LIST///////////////////////
	public function countAll_opd()
{
	$sql = "SELECT * FROM opdlist";
	$data = $this->totalRecordsInQuery($sql);
	return $data;
}
	public function getAllopd($start,$limit,$q){
		
				$sql = "SELECT * FROM opdlist $q order by opd LIMIT ".$start.",".$limit;
			
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	//////////////////////////////////////////////////////////////////////////////////////////
	public function countAll_test()
{
	$sql = "SELECT * FROM tests1";
	$data = $this->totalRecordsInQuery($sql);
	return $data;
}
	public function getAllTest($start,$limit,$q){
		
				$sql = "SELECT * FROM tests1 AS T LEFT JOIN pdept AS P ON(T.PDNO=P.PDNO) $q order by TNO LIMIT ".$start.",".$limit;
			
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	////////////////////////////////////////////////////////
	 public function countAll_med()
{
	$sql = "SELECT * FROM medicines";
	$data = $this->totalRecordsInQuery($sql);
	return $data;
}
	public function getAllMed($start,$limit,$q){
		
				$sql = "SELECT * FROM medicines $q order by med_id LIMIT ".$start.",".$limit;
			
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	

	//////////////////////////////////////////////////////
	public function getAllCard($start,$limit,$q){
		
				$sql = "SELECT * FROM cardiology $q order by c_test_id LIMIT ".$start.",".$limit;
			
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	
	/////////////////////////////////////////////////////////////////////////
	public function countAll_xtest()
{
	$sql = "SELECT * FROM x_ray";
	$data = $this->totalRecordsInQuery($sql);
	return $data;
}
	public function getAllxray($start,$limit,$q){
		
				$sql = "SELECT * FROM x_ray $q order by x_test_id LIMIT ".$start.",".$limit;
			
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	/////////////////////////////////////////////////////////////////////////
	public function getAllct($start,$limit,$q){
		
				$sql = "SELECT * FROM ct_scan $q order by ct_test_id LIMIT ".$start.",".$limit;
			
		$data = $this->CustomQuery($sql);
		
		return $data;
	}
	///////////////////////////////////////////////////////////////////////////
	
	public function getPat($id){
		$data = $this->GetRecord('opd_pat_reg', 'opd_id', $id);
		return  $data;
	}
	//////////////////////////////////////////////////
	public function getOpdList($id){
		$data = $this->GetRecord('opdlist', 'CODE', $id);
		return  $data;
	}
	////////////////////////////////////////////////////////////////////////////////
	public function getTest($id){
		$data = $this->GetRecord('med_tests', 'm_test_id', $id);
		return  $data;
	}
	public function getCardTest($id){
		$data = $this->GetRecord('cardiology', 'c_test_id', $id);
		return  $data;
	}
	public function getCtTest($id){
		$data = $this->GetRecord('ct_scan', 'ct_test_id', $id);
		return  $data;
	}
	
	public function getXrayTest($id){
		$data = $this->GetRecord('x_ray', 'x_test_id', $id);
		return  $data;
	}
	///////////////////////////////////////////
	
	public function updateOpdList(){
				extract($_POST);
		$uid=$_REQUEST['uid'];
	
					$sql  = "UPDATE opdlist SET OPD = '$opd_name',RATE = '$opd_rate',
				 	ROOM= '$opd_room', 
				 	
					
					
					 WHERE CODE = '$uid'";
					
	if(mysql_query($sql)){
				return "User updated successfully!";
			}
		else{
			return "this username is not available!";
		}
	}
	////////////////// Medicines Update ///////////////////////////////////
	public function getMed($id){
		$data = $this->GetRecord('medicines', 'med_id', $id);
		return  $data;
	}



public function updateMed(){
				extract($_POST);
		//$uid=$_REQUEST['uid'];
	
				$sql  = "UPDATE medicines SET med_name = '$m_name', WHERE med_id = '$m_id'";
				
	if(mysql_query($sql)){
				return "Test updated successfully!";
			}
		else{
			return "this Test is not available!";
		}
	}
	
	///////////////////////////////////Test Update///////////////////////////////////
	public function updateTest(){
				extract($_POST);
		//$uid=$_REQUEST['uid'];
	
					$sql  = "UPDATE med_tests SET m_test_name = '$test_name',
					
				 	m_test_rate= '$test_rate' WHERE m_test_id = '$test_id'";
					
	if(mysql_query($sql)){
				return "Test updated successfully!";
			}
		else{
			return "this Test is not available!";
		}
	}
	/////////////////////////////////////////////
	public function updateCardTest(){
				extract($_POST);
		//$uid=$_REQUEST['uid'];
	
					$sql  = "UPDATE cardiology SET c_test_name = '$ctest_name',
					
				 	c_test_rate= '$ctest_rate' WHERE c_test_id = '$ctest_id'";
					
	if(mysql_query($sql)){
				return "Test updated successfully!";
			}
		else{
			return "this Test is not available!";
		}
	}
	///////////////////////////////////////////////////////
	public function updateCtTest(){
				extract($_POST);
		//$uid=$_REQUEST['uid'];
	
					$sql  = "UPDATE ct_scan SET ct_test_name = '$cttest_name',
					
				 	ct_test_rate= '$cttest_rate' WHERE ct_test_id = '$cttest_id'";
					
	if(mysql_query($sql)){
				return "Test updated successfully!";
			}
		else{
			return "this Test is not available!";
		}
	}
	
	/////////////////////////////////////////////////
	public function getalldays(){
		$sql = "SELECT * FROM opd_days";
		$data = $this->CustomQuery($sql);
		return $data;
 
 }
		////////////////////////////////////////////////////
		public function updateXrayTest(){
				extract($_POST);
		//$uid=$_REQUEST['uid'];
	
					$sql  = "UPDATE x_ray SET x_test_name = '$x_name',
					
				 	x_test_rate= '$x_rate' WHERE x_test_id = '$xtest_id'";
					
	if(mysql_query($sql)){
				return "Test updated successfully!";
			}
		else{
			return "this Test is not available!";
		}
	}
/////////////////////////////////////////////////////////////
 
 
  public function deleteOPD($id){
		$sql = "DELETE";
	
		if($this->deleteRecord('opd', 'ID = '.$id)){
			return "User deleted";
		}
 }
 
 
 
 
 public function deletePat($id){
		$sql = "DELETE";
	
		if($this->deleteRecord('opd_pat_reg', 'opd_id = '.$id)){
			return "User deleted";
		}
 }
 ////////////////////////////////////////////
 public function deleteOpdList($id){
		$sql = "DELETE";
	
		if($this->deleteRecord('opdlist', 'CODE = '.$id)){
			return "User deleted";
		}
 }
		///////////////////////////////////////////////////////////////////////////
		public function deleteTest($id){
		$sql = "DELETE";
		if($this->deleteRecord('tests1', 'TNO = '.$id)){
			return "User deleted";
		}
		
		
	}
	////////////////////////////////////////////////
	public function deleteMed($id){
		$sql = "DELETE";
		if($this->deleteRecord('medicines', 'med_id = '.$id)){
			return "User deleted";
		}
		
		
	}
 
 ////////////////////////////////////////////////////////////////////////
 public function deleteCardTest($id){
		$sql = "DELETE";
		if($this->deleteRecord('cardiology', 'c_test_id = '.$id)){
			return "User deleted";
		}
		
		
	}
 
 
	
     //////////////////////////////////////////////////////////////////////////////
	  public function deleteXrayTest($id){
		$sql = "DELETE";
		if($this->deleteRecord('x_ray', 'x_test_id = '.$id)){
			return "User deleted";
		}
		
		
	}
 

   ////////////////////////////////////////////
   public function deleteCTscan($id){
		$sql = "DELETE";
		if($this->deleteRecord('ct_scan', 'ct_test_id = '.$id)){
			return "User deleted";
		}
		
		
	}
	//////////////////////////////////////////////
     


	
	
}

<?php
class Employee extends DBAccess{
	function Employee(){
		$this->connectToDB();
	}
	
	public function getAllEmployees($q){
		$sql = "SELECT * FROM employee 
				$q
				";
		$data = $this->CustomQuery($sql);
		return $data;
	}
	
	public function getEmpList($start,$limit,$q){
		$sql = "		SELECT * FROM employee as e
				
				LEFT JOIN gen_gender as g ON (e.gender_id = g.gender_id) 
				$q 
				LIMIT $start, $limit
				";
		$data = $this->CustomQuery($sql);
		return $data;
	}
	public function getEmpList2($start,$limit,$q,$dat){
			$sql = "SELECT * FROM employee e
					LEFT JOIN gen_designations AS d ON ( e.designation_id = d.designation_id )
					LEFT JOIN gen_gender AS g ON ( e.gender_id = g.gender_id )
					$q and e.employee_id NOT IN (
					SELECT p.employee_id
					FROM project_team p
					WHERE p.deployed_to > '$dat'
					)
				";
		$data = $this->CustomQuery($sql);
		return $data;
	}
	
	function countAllEmployees(){
		$sql = "SELECT * FROM employee";
		$data = $this->totalRecordsInQuery($sql);
		return $data;	
	}
	
	function countEmployees($q){
		$sql = "SELECT * FROM employee e $q";
		$data = $this->totalRecordsInQuery($sql);
		return $data;	
	}
	
	public function getEmployeeDD($name, $selected, $text, $options){
		$employees = $this->getAllEmployees("");
		$html = "<select name='$name' id='$name' $options >";
		
		$html .= "<option value='0'>$text</option>";
		
			foreach ($employees as $emp){
				$selected_item = '';
				if($selected == $emp['employee_id']){
					$selected_item = "selected='selected'";
				}
				$html .= "<option $selected_item value='".$emp['employee_id']."'>".$emp['emp_name']."</option>";
			}
		
		
		
		$html .= "</select>";
		return $html;
	}
	public function getEmployeeCode(){
		$sql = "select * from gen_codes where code_id = 4";
		$rs = mysql_query($sql) or die(mysql_error()); 
		$rec = mysql_fetch_array($rs);
		$code = "SB-".$rec['code'];	
		return $code;
	}
	public function updateEmpCode(){
		$sql = "select * from gen_codes where code_id = 4";
		$rs = mysql_query($sql) or die(mysql_error()); 
		$rec = mysql_fetch_array($rs);
		$code = $rec['code'];
		$code++;
		$sql = "UPDATE gen_codes SET code = $code WHERE code_id = 4";
		mysql_query($sql);
	}
	
	
	function addEmployee(){
		
		extract($_POST);
		
		
		$sql = "INSERT INTO employee SET
				emp_name = '$emp_name',
				emp_nationality = '$emp_nationality',
				emp_number = '$emp_number',
				emp_report_to = '$emp_report_to',  
				emp_joing_date  = '".date("Y-m-d",strtotime($emp_joing_date))."',
				emp_retire_date = '".date("Y-m-d",strtotime($emp_retire_date))."',
				designation_id = '$designation_id',
				emp_function = '$emp_function',
				gender_id = '$gender_id',
				blood_group_id = '$blood_group_id',
				father_mother_name = '$father_mother_name',
				spouse_name = '$spouse_name',
				home_address = '$home_address',
				contact_number = '$contact_number',
				email_address = '$email_address',
				basic_pay = '$basic_pay',
				working_hours = '$working_hours',
				rate_per_hour = '$rate_per_hour'				
				";
		
		if(mysql_query($sql)){
			$eid = mysql_insert_id();
			$this->updateEmpCode();
			
			if($_FILES["emp_picture"]['name']!=NULL || !empty($_FILES["emp_picture"]['name'])){			
			$dir = $this->absolute_path."media/";
			$dir1 = $this->absolute_path."media/";

			
			$emp_image=nowUploadPicture("emp_picture",$dir ,$this->upload_size_allowed,400,400);	
			$images[]=$emp_image;
			$path_emp_image = $dir.$emp_image;
			
			$thumbnil_image =$dir."_".$emp_image;				
			createthumb($path_emp_image,$thumbnil_image,200,200);
			
			$path_emp_image1 = $dir1.$emp_image;
			$thumbnil_image1 =$dir1."_".$emp_image;	
			
		 	$sql_pic = "UPDATE employee SET emp_picture = '$emp_image' WHERE employee_id = $eid";
			mysql_query($sql_pic);									
			}
			
			
			
			
			
		}else{
			echo $sql;
			echo "\n";
			echo mysql_error();	
			//die();
		}
		
		

	}
	
	public function getEmployee($id){
		$sql = "SELECT * from employee as e
				LEFT JOIN gen_gender as g ON (e.gender_id = g.gender_id)
				LEFT JOIN gen_designations as d ON (e.designation_id = d.designation_id)
				WHERE e.employee_id = $id
				";
		
		$rs = mysql_query($sql) or die(mysql_error());
		$data = mysql_fetch_array($rs);
		
		return $data;
		
	}




	public function getStatusDD($name, $selected, $text, $options){
		$sql = "SELECT * FROM hr_attendence_status";
		$rs = mysql_query($sql);
		$data = array();
		while($r = mysql_fetch_array($rs)){
			$data[] = array(
				'sid' => $r['attendence_status_id'],
				'title'	=> $r['at_title']
					);
		}
		$html = "<select name='$name' id='$name' $options >";
		
		$html .= "<option value='0'>$text</option>";
		
		foreach ($data as $emp){
			$selected_item = '';
			if($selected == $emp['sid']){
				$selected_item = "selected='selected'";
			}
			$html .= "<option $selected_item value='".$emp['sid']."'>".$emp['title']."</option>";
		}
		
		
		
		$html .= "</select>";
		return $html;
	}
	
	

	function updateEmployee(){
		
		extract($_POST);
		$sql = "Update employee SET
				emp_name = '$emp_name',
				emp_nationality = '$emp_nationality',
				emp_number = '$emp_number',
				emp_report_to = '$emp_report_to',  
				emp_joing_date  = '".date("Y-m-d",strtotime($emp_joing_date))."',
				emp_retire_date = '".date("Y-m-d",strtotime($emp_retire_date))."',
				designation_id = '$designation_id',
				emp_function = '$emp_function',
				gender_id = '$gender_id',
				blood_group_id = '$blood_group_id',
				father_mother_name = '$father_mother_name',
				spouse_name = '$spouse_name',
				home_address = '$home_address',
				contact_number = '$contact_number',
				email_address = '$email_address',
				basic_pay = '$basic_pay',
				working_hours = '$working_hours',
				rate_per_hour = '$rate_per_hour'
				WHERE employee_id = $employee_id
				";
		
		if(mysql_query($sql)){
			$eid = $employee_id;
			
			if($_FILES["emp_picture"]['name']!=NULL || !empty($_FILES["emp_picture"]['name'])){			
			$dir = $this->absolute_path."media/";
			$dir1 = $this->absolute_path."media/";

			
			$emp_image=nowUploadPicture("emp_picture",$dir ,$this->upload_size_allowed,400,400);	
			$images[]=$emp_image;
			$path_emp_image = $dir.$emp_image;
			
			$thumbnil_image =$dir."_".$emp_image;				
			createthumb($path_emp_image,$thumbnil_image,200,200);
			
			$path_emp_image1 = $dir1.$emp_image;
			$thumbnil_image1 =$dir1."_".$emp_image;	
			
		 	$sql_pic = "UPDATE employee SET emp_picture = '$emp_image' WHERE employee_id = $eid";
			mysql_query($sql_pic);									
			}
			
			
			
		}else{
			echo $sql;
			echo "\n";
			echo mysql_error();	
			die();
		}
		
		

	}
	
	function deleteEmployee($eid){
		$sql = "DELETE FROM employee WHERE employee_id = $eid";
		mysql_query($sql) or die(mysql_error());
			mysql_query($p);
		$u = "DELETE from um_users WHERE employee_id = $eid";
		mysql_query($u);
	}
	

	
	function getDesignationTitleById($id){
	
	$sql = "SELECT * From gen_designations where designation_id = '".$id."'";
	$data = $this->CustomQuery($sql);
		if(empty($data)){
			$data = array();
		}
		return $data;
	
	
	}
	
	function getEmployeeNameById($id){
	
	$sql = "SELECT emp_name From employee where employee_id = '".$id."'";
	$data = $this->CustomQuery($sql);
		if(empty($data)){
			$data = array();
		}
		return $data;
	}

	
}
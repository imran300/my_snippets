<?php 
include("../config.php");
$data=$Operation->get_medications($_REQUEST['patient_id']);
//print_r($data);
?>
<fieldset class="signups"><legend>Patient's Medication History</legend><table width="80%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr class="heading">
    <td width="20%"><strong>Patient Name</strong></td>
    <td width="12%"><strong>OPD NO</strong></td>
    <td width="18%"><strong>Medicine</strong></td>
    <td width="12%"><strong>Frequency</strong></td>
    <td width="14%"><strong>Timings</strong></td>
    <td width="24%"><strong>Dated</strong></td>
  </tr>
 
 <?php for($i=0; $i<count($data);$i++)
 { ?>
  <tr>
    <td><?php echo $data[$i]['NAME'];?></td>
    <td>&nbsp;<?php echo $data[$i]['opd_id'];?></td>
    <td>&nbsp;<?php echo $data[$i]['med_name'];?></td>
    <td>&nbsp;<?php echo $data[$i]['frequency'];?></td>
    <td>&nbsp;<?php echo $data[$i]['timing'];?></td>
    <td>&nbsp;<?php $date= $data[$i]['OPDDATE'];
	echo date("d/M/Y",strtotime($date));
	
	?></td>
    
  </tr>
  <?php } ?>
</table></fieldset>
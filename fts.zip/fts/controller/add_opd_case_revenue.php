<?php include("../config.php");
$Operation->Operation();
extract($_POST);
$user_id=$_SESSION['luser']['id'];
$ip = getenv("REMOTE_ADDR");
date_default_timezone_set('Asia/karachi');
$time = date("h:i:s", time());
$date_today=date('Y-m-d');
$dates_from_form=date("Y-m-d",strtotime($date));
$check="select * from opd_daily_revenue where opd_date='$dates_from_form'";
$row=mysql_query($check);
$number=mysql_num_rows($row);
if($number>0){
	$update=mysql_query("update opd_daily_revenue set no_of_opds='$opd_case',total_amount='$amount',`opd_date`='$dates_from_form', time='$time', date='$date_today', ip='$ip', user_id='$user_id' where opd_date='$dates_from_form'");
	if($update)
{
echo "Successfully Updated";
}	
}
else{
$sql="insert into `opd_daily_revenue` set `no_of_opds`='$opd_case',`total_amount`='$amount',`opd_date`='$dates_from_form', time='$time', date='$date_today', ip='$ip', user_id='$user_id'";
if(mysql_query($sql))
{
echo "Successfully Saved";
}	
}
		?>
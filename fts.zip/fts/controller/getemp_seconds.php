<style type="text/css">
.alert-danger {
  color: #a94442;
  background-color: #f2dede;
  border-color: #ebccd1;
}
.alert {
  padding: 15px;
  margin-bottom: 20px;
  border: 1px solid transparent;
  border-radius: 4px;
}
</style>
<?php 
require_once('../connect.php');
$name=$_REQUEST['name_V'];
 $qr="SELECT * FROM `issue` WHERE `barcode`='$name'";
$rqr=mysql_query($qr)or die(mysql_error());
$number=mysql_num_rows($rqr);
if($number<1)
{
	echo "<p style='width:400px;margin:0 auto;' class='alert alert-danger'><strong>No Record Found ! With THe Bar Code No : ".  $name."</strong></p>";
	}
	else
	{
$row = mysql_fetch_array($rqr);
?>
<table align="center"  width="496" style="border:9px solid #333; border-radius:13px;">
  <tr style="background-color:#999">
  	<td width="194" align="left"><strong>No. :</strong></td><td width="694" align="left"><?php echo $row['idissue']; ?></td>
   </tr>
   <tr>
    <td align="left"  scope="col"><strong>File No second : </strong></td>
    <td align="left"><?php echo $row['fileno']; ?></td>
   </tr>
  <tr style="background-color:#999">
    <td align="left"  scope="col"><strong>Volume :</strong></td>
    <td align="left"><?php echo $row['idvolume']; ?></td>
    </tr>
    <tr>
    <td align="left"  scope="col"><strong>Subject :</strong></td>
    <td align="left"><?php echo $row['subject']; ?></td>
    </tr>
  <tr style="background-color:#999">
    <td align="left"  scope="col"><strong>Source :</strong></td>
    <td align="left"><?php echo $row['idsource']; ?></td>
    </tr>
    <tr>
    <td align="left"  scope="col"><strong>Flag :</strong></td>
    <td align="left"><?php echo $row['idflag']; ?></td>
    </tr>
  <tr style="background-color:#999">
    <td align="left"  scope="col"><strong>From Department :</strong></td>
    <td align="left"><?php
	
	$ses_var=mysql_query("select * from `department` where `iddepartment`='$row[fromdept]'");
	$row_Sess=mysql_fetch_assoc($ses_var); 
	echo $row_Sess['department']; ?></td>
    </tr>
    <tr>
    <td align="left"  scope="col"><strong>From Section :</strong></td>
    <td align="left"><?php ///echo $row['F_Officer'];
	$ses_var=mysql_query("select * from `section` where `idsection`='$row[fromsection]'");
	$row_Sess=mysql_fetch_assoc($ses_var); 
	echo $row_Sess['section'];
	 ?></td>
    </tr>
  <tr style="background-color:#999">
    <td align="left"  scope="col"><strong>Date :</strong></td>
    <td align="left"><?php $DATE_FORMAT= $row['datetime'];
	echo date("d-m-Y h:i A",strtotime($DATE_FORMAT)); ?></td>
    </tr>
    <tr>
    <td align="left"  scope="col"><strong>Dairy No :</strong></td>
    <td align="left"><?php echo $row['dairyno']; ?></td>
    </tr>
  <tr style="background-color:#999">
    <td align="left"  scope="col"><strong>Status :</strong></td>
    <td align="left"><?php echo $row['idfilestatus']; ?></td>
    </tr>
    
  <tr >
    <td align="left"  scope="col"><strong>Actions :</strong></td>
    <td align="left"><a class="btn" href="index.php?option=file&item=track&idissue=<?php echo $row['idissue']; ?>">View Track</a>
	<?php $grab=mysql_query("SELECT * 
FROM  `receive` 
WHERE  `idissue` =  '$row[idissue]'
AND  `status` =  '1'");
/////////////if status is 1 so only those r allowed to forward this as possesing file user ////////////////////
$row_grab=mysql_fetch_array($grab);?>
	<a class="btn btn_success" href="index.php?option=file&item=forward&idreceive=<?php echo $row_grab['idreceive']; ?>">Forward Now</a>
	</td>
    </tr>
  </tr>
</table>
<?php }?>
<br>
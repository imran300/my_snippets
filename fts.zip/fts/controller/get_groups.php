<?php include("../config.php");
$Operation->Operation();
$y=$_REQUEST['pdno'];
$t_no=$_REQUEST['t_no'];
echo $sql="SELECT `GNO` , `GNAME`
FROM `groups` AS T
WHERE `PDNO` ='$y' AND `TNO`='$t_no'";
$sql_number=mysql_query($sql) or die(mysql_error());
$num=mysql_num_rows($sql_number);
if($num<1)
{
echo "<option>No Record Found</potion>";
}
else
{
	echo "<option value=''>Select Test Name </option>";
while($rowss=mysql_fetch_array($sql_number))
{
?>
<option value="<?php echo $rowss['GNO'];?>"><?php echo $rowss['GNAME'];?></option>
<?php  } }
?>
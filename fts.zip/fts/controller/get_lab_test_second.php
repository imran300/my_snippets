<?php 
include("../config.php");
//$tests=$Operation->get_LabTest($_REQUEST['YEAR']);
 $id=$_REQUEST['patient_id'];
$data = $Operation->search_test_by_opdno_for_report_second($id);
//print_r($data);
?>
<fieldset class="signups"><legend>Patient's Laboratory Test History</legend><div id="signssupS" style="min-height:200px; overflow:scroll">         <table width="100%" border="0" cellpadding="0" cellspacing="0" class="form list" style="height:200px !important; overflow:scroll !important;">
           <tr>
             <td width="3%"><strong style="">Test Name</strong></td>
             <td colspan="7">Result</td>
             <td width="0%">&nbsp;</td>
             <td width="0%">&nbsp;</td>
           </tr>
           <?php 
		   $index=1;
	  for($i=0; $i<count($data); $i++)
  {
  ?>
           <tr class="tough">
             <td valign="top">&nbsp;</td>
             <td width="13%">&nbsp;</td>
             <td width="9%" align="center"></strong></td>
             <td width="8%" align="left"></td>
             <td width="33%" align="center"><strong>Normal From</strong><strong> - Normal To</strong></td>
             <td width="8%"></td>
             <td width="11%"></td>
             <td width="15%">&nbsp;</td>
             <td>&nbsp;</td>
             <td>&nbsp;</td>
           </tr>
           <tr class="tough" style="background-color:#DBEAF9;" onMouseOver="this.style.backgroundColor='#E8E8E8'" onMouseOut="this.style.backgroundColor='#DBEAF9'">

             <td valign="top"><strong><?php echo $data[$i]['TNAME'];?></strong></td>
             <td colspan="7"> <input type="text" style="width:auto; font-weight:bold; font-size:18px; color:#F00;"  value="<?php echo $data[$i]['VALUE'];?>"  readonly /><em style="margin-left:156px;"> <input name="nor_fr" type="text" id="nor_fr" placeholder="Normal From" value="<?php echo $data[$i]['NORMAL_FR'];?> - <?php echo $data[$i]['NORMAL_TO'];?>" readonly /></em>
     <hr />
 <br />
<?php 
 $pd=$data[$i]['PDNO'];
 $tn=$data[$i]['TNO'];
 $gn=$data[$i]['GNO'];
 $system_date=date("Y/m/d");
///$gr=$Operation->get_groups($pd,$tn);
//print_r($gr);
$sql = "SELECT * From `pat_result` AS P
LEFT JOIN tests1 AS T ON(P.PDNO=T.PDNO && P.TNO=T.TNO)
LEFT JOIN groups AS G ON(P.PDNO=G.PDNO && P.TNO=G.TNO)
WHERE P.OPD_NO='$opd_no' AND P.PDNO='$pd' AND P.TNO='$tn' AND P.GNO='$gn' AND DATE='$system_date'";
$query=mysql_query($sql);
while($gr=mysql_fetch_array($query))
{
$GNO_MY= $gr['GNO'];
$TNO_MY= $gr['TNO'];
$sql_gno_for=mysql_query("SELECT  * from `pat_result` AS K WHERE GNO='$GNO_MY' AND TNO='$TNO_MY' AND OPD_NO='$opd_no'") or die(mysql_error());
$check_number=mysql_num_rows($sql_gno_for);
if($check_number<1)
{
	}
	else
	{
	$row_for_gno=mysql_fetch_array($sql_gno_for);
	?>
<li style="background-color:#EAF2FA;"><?php echo  $gr['GNAME'];?> || <input type="text" style="font-weight:bold; font-size:18px; color:#F00;" value="<?php echo $row_for_gno['VALUE'];?>" style="width:auto;" readonly /><input type="text" name="normal" style="margin-left:43px;" placeholder="Normal From" readonly value="<?php echo $gr['NORMAL_FR'];?> - <?php echo $gr['NORMAL_TO'];?>"> </li>
<?php 
echo "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ";
$sql_third_q="select * from `sgroups` where `PDNO`='$pd' AND `TNO`='$tn' and GNO='$gr[GNO]'";
$sql_third=mysql_query($sql_third_q) or die(mysql_error());
while($row_third=mysql_fetch_array($sql_third))
{
	 $query_sg="SELECT  * from `pat_result`  WHERE  `PDNO`='$pd' AND GNO='$GNO_MY' AND TNO='$TNO_MY' AND SGNO='$row_third[SGNO]' AND  OPD_NO='$opd_no'";
	$sql_gno_for_SG=mysql_query($query_sg) or die(mysql_error());
 $check_number_SG=mysql_num_rows($sql_gno_for_SG);

	$row_for_gno_SG=mysql_fetch_array($sql_gno_for_SG);
	?>
	<li><?php echo $row_third['SGNAME'];?> <input type='text' name='result' style="font-weight:bold; font-size:18px; color:#F00;" value="<?PHP echo $row_for_gno_SG['VALUE'];?>" > <input type='text' name='normal' placeholder='Normal From' readonly='readonly' value='<?php echo $row_third['NORMAL_FR'];?> - <?php $row_third['NORMAL_TO'];?>'>  </li>
	<?php echo "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ";
 
	}


echo "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ";
$index++;
}}
?>
<input type="hidden" name="result_id[]" id="result_id[<?php echo $data[$i]['TNO'];?>]" value="<?php echo $data[$i]['TNO'];?>" /> <input type="hidden" name="case_id[]" id="case_id[<?php echo $data[$i]['LAB'];?>]" value="<?php echo $data[$i]['LAB'];?>" /></td>
             <td>&nbsp;</td>
             <td>&nbsp;</td>
           </tr>
           <?php } ?>
         </table>
         </div>
</fieldset>
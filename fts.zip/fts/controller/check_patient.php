<?php include("../config.php");
$Operation->Operation();
$y=$_REQUEST['id'];
$sql="SELECT `patient_id` FROM `patient_record` WHERE `patient_id`='$y'";
$sql_number=mysql_query($sql) or die(mysql_error());
$num=mysql_num_rows($sql_number);
if($num<1)
{
echo "0";
}
else
{
echo "yes";
}
?>
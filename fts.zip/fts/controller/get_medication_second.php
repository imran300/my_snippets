<?php 
include("../config.php");
$data = $pharmacy->getMedicationRecord($_REQUEST['patient_id']);
//$med=$Operation->get_medications();
//print_r($data);
?>
<fieldset class="signups"><legend>Patient's Medication History</legend><div class="body-container">
		<div>
			<h2>Patient Medicine Details</h2>
            <div>
              <!-- Personal Information -->
              <table style="width:100% !important; margin:0 auto;" width="662" border="0" cellpadding="0" cellspacing="0" class="list title" align="left">
                      <thead>
              <tr>
                <td width="142" align="center" valign="middle"><span class="whitesmalltabtext"><strong>S.No</strong></span></td>
                <td width="231" align="center" valign="middle"><span class="whitesmalltabtext"><strong>Item</strong></span></td>
                <td width="200" align="center" valign="middle"><span class="whitesmalltabtext"><strong>Quantity</strong></span></td>
      </tr>
              </thead>
                <?php
				$a=1;
				if($data==''){
				echo "<center>"."No Record Found"."</center>";
				}
				else
				{
				for($i=0;$i<count($data);$i++)
		{
			?>
                <tr align="left">
                  <td align="center" valign="middle"><?= $a++; ?></td>
                  <td align="center" valign="middle"><?= $data[$i]['item']; ?></td>
                  <td align="center" valign="middle"><?= $data[$i]['qty']; ?></td>
                
                </tr>
                <?php  } } ?>
                <tr>
                <td colspan="5">&nbsp;</td>
                </tr>
              </table>
            </div>
				<div>
               	  <form name="" method="post" id="frm" action="">
                    <input type="hidden" name="employee_id" value="<?php /// echo $eid ?>" />
                    <input type="hidden" name="created_by" value="<?php echo $_SESSION['luser']['id'] ?>" />
                    <input type="hidden" name="salary_detail_id" id="salary_detail_id" value="" />
                    <input type="hidden" name="action" id="action" value="add" />
               	  </form>

		</div>
		
</div>
</div></fieldset>
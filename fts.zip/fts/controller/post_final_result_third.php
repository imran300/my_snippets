<?php include("../config.php");
$Operation->Operation();
extract($_POST);
$ip = getenv("REMOTE_ADDR");
   date_default_timezone_set('Asia/karachi');
	$TIME = date("h:i:s", time());
		$date=date('Y-m-d');
//////////post:value_result,lab:lab_id,opd_no:opd,pd:pd_no,t_no:tno,gr_no:gno,nor_f:nor_fr,nor_t:nor_to
		$post=$_REQUEST['post'];
		$lab=$_REQUEST['lab'];
		$opd_no=$_REQUEST['opd_no'];
		$pd=$_REQUEST['pd'];
		$tno=$_REQUEST['t_no'];
		$gr_no=$_REQUEST['gr_no'];
		$sub_group=$_REQUEST['sub_group'];
		$nor_from=$_REQUEST['nor_f'];
		$nor_to=$_REQUEST['nor_t'];
		/////////$unit=$_REQUEST['unit_n'];
$sql_post="INSERT INTO  `pat_result` set `LAB`='$lab',`OPD_NO`='$opd_no',`RDATE`='$date',`SNO`='',`PDNO`='$pd',`TNO`='$tno',`GNO`='$gr_no',`SGNO`='$sub_group',`VALUE`='$post',`FEEDBY`='',`NORMAL_FR`='$nor_from',`NORMAL_TO`='$nor_to',`TIME`='$TIME',`DATE`='$date',`IP`='$ip'";
$sql_done=mysql_query($sql_post);
		if($sql_done)
		{
			echo "done";
			
			}
		?>
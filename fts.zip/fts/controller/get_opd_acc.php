<?php include("../config.php");
$response=$Operation->get_opd_Acc($_POST['given_date']);
?>
<tr>
<td>
<strong>OPD Cases :</strong>
</td>
<td> 
<input type="text" name="opd_case" value="<?= $response[0]['opds'];?>" readonly="readonly" required="required" />
</td>
</tr>
<tr>
<td>
<strong>Total Amount:</strong>
</td>
<td>
<input type="text" name="amount" value="<?= $response[0]['rate'];?>" readonly="readonly"  required="required" />
</td>
</tr>
<tr>
<td colspan="2" align="center">
<input name="button_opd_case_form" type="button" id="button_opd_case_form" onclick="submit_button_opd_case_form()" value="Save" />
</td>
</tr>
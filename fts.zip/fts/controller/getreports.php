
<?
include "../connect.php";
$from = date("Y-m-d",strtotime($_REQUEST['from']));
$to = date("Y-m-d",strtotime($_REQUEST['to']));
$barcode = $_REQUEST['barcode'];
$subject = $_REQUEST['subject'];
$fileno = $_REQUEST['fileno'];
$dairyno = $_REQUEST['dairyno'];
$idfiletype = $_REQUEST['idfiletype'];
$idflag = $_REQUEST['idflag'];
$idsource = $_REQUEST['idsource'];
$idfilestatus = $_REQUEST['idfilestatus'];
$idvolume = $_REQUEST['idvolume'];
$iddepartment = $_REQUEST['iddepartment'];
$idsection = $_REQUEST['idsection'];
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$sql=mysql_query("SELECT f.*,ft.*,i.*,s.*,fs.*,v.*,d.*,ds.*
FROM `issue` AS i,`filetype` AS ft,`flag` AS f,`source` AS s,`filestatus` AS fs,`volume` AS v, `department` as d, `section` as ds
WHERE i.`idfiletype`=ft.`idfiletype`
AND i.`idflag`=f.`idflag`
AND i.`idsource`=s.`idsource`
AND i.`idfilestatus`=fs.`idfilestatus`
AND i.`idvolume`=v.`idvolume`
AND i.`fromdept`=d.`iddepartment`
AND i.`fromsection`=ds.`idsection`
AND DATE_FORMAT(i.`datetime`,'%Y-%m-%d')  BETWEEN '$from' AND '$to'
AND i.`fromdept` = '$iddepartment'
AND i.`fromsection` = '$idsection'
ORDER BY i.`datetime` ASC") or die(mysql_error());
if(mysql_num_rows($sql)<1){
	echo '<script>alert("No Record Found")</script>';
}else{
?>
<table class="list title">
<thead>
  <tr>
  <th>Date Time</th>
  <th>Barcode</th>
  <th>Subject</th>
  <th>File No</th>
  <th>Dairy No</th>
  <th>File Type</th>
  <th>Flag</th>
  <th>Source</th>
  <th>File Status</th>
  <th>Volume</th>
  <th>Department</th>
  <th>Section</th>
  <th>Action</th>
  </tr>
</thead>
<tbody>
<?php
while($result=mysql_fetch_array($sql) or die(mysql_error())){
?>
  <tr>
  <td><?=date("d-m-Y h:i A", strtotime($result['datetime']));?></td>
  <td><?=$result['barcode'];?></td>
  <td><?=$result['subject'];?></td>
  <td><?=$result['fileno'];?></td>
  <td><?=$result['dairyno'];?></td>
  <td><?=$result['filetype'];?></td>
  <td><?=$result['flag'];?></td>
  <td><?=$result['source'];?></td>
  <td><?=$result['filestatus'];?></td>
  <td><?=$result['volume'];?></td>
  <td><?=$result['department'];?></td>
  <td><?=$result['section'];?></td>
  <td><a href="index.php?option=file&item=track&idissue=<?=$result['idissue'];?>">Track</a></td>
  </tr>
  <?php
}
  ?>
</tbody>
</table>
<?php
}
?>

<?php 
include("../config.php");
$system_day=date("D");
$opd_code=$_REQUEST['opd_code'];
$sql = "SELECT * FROM `opdlist` where `CODE`='$opd_code'";
$data=$Operation->opd_availability($sql);
//print_r($data);
?>
<style>
#upload{ display:none;
	 padding:1px; float:right;
	font-weight:bold; font-size:1.3em;
	font-family:Arial, Helvetica, sans-serif;
	text-align:center;
	background:#f2f2f2;
	color:#3366cc;
	margin-left:253px;
	border:1px solid #ccc;
	width:250px;
	cursor:pointer !important;
	-moz-border-radius:5px; -webkit-border-radius:5px;
}
.darkbg{
	background:#ddd !important;
}
#status{
	font-family:Arial; padding:5px;
}
ul#files{ list-style:none; padding:0; margin:0; }
ul#files li{ padding:0px; margin-bottom:2px; width:200px; float:left; margin-right:10px;}
ul#files li img{ width:443px; height:165px; }
.success{ background:#99f099; border:1px solid #339933; }
.error{ background:#f0c6c3; border:1px solid #cc6622; }
</style>

</script>
<table width="907" border="0" cellpadding="0" cellspacing="0" class="clear-list">
  <tr>
    <td width="152"><strong>Nature Of OPD :</strong></td>
    <td width="5">&nbsp;</td>
    <td colspan="2">
    <input name="nature_opd" type="text" id="nature_opd" value="<?php echo $data[0]['OPD'];?>" readonly></td>
    <td width="80" align="center"><strong>Rate:</strong></td>
    <td width="285"><input name="rate" type="text" id="rate" style="width:100px;" value="5" readonly></td>
  </tr>
  <tr>
    <td height="49" colspan="2">&nbsp;</td>
    <td width="218">&nbsp;</td>
    <td>&nbsp;</td>
    <td align="center"><strong>Age:</strong></td>
    <td align="left"><input name="age" type="text" id="rate2" style="width:100px;" value=""  /></td>
  </tr>
  <tr>
    <td height="22" colspan="2"><!--<strong>Room #</strong>-->
      <strong>
      <!--<input name="room" type="text" id="room" value="<?php //echo $data[0]['ROOM'];?>" readonly>-->
    Address:    </strong></td>
    <td height="22"><strong>
      <textarea name="address" id="address" cols="45" rows="5"></textarea>
    </strong></td>
    <td width="167"><input type="hidden" name="code" id="code" value="<?php echo $data[0]['CODE'];?>"></td>
    <td align="center"><strong>Gender</strong>:</td>
    <td align="left">Male
      <input type="radio" name="gender" id="radio" value="male">
Female
<input type="radio" name="gender" id="radio2" value="female" ></td>
  </tr>
  <tr>
    <td height="22" colspan="2" valign="top">&nbsp;</td>
    <td height="22" colspan="2" valign="top">&nbsp;</td>
    <td colspan="2" align="center" valign="top"><input type="submit"  name="insert" value="Generate OPD" class="button_example"   />
    <input type="reset" value="clear" class="remove"  /></td>
  </tr>
  <tr>
    <td height="26" colspan="2" valign="top">&nbsp;</td>
    <td height="26" valign="top">&nbsp;</td>
    <td height="53" rowspan="2">&nbsp;</td>
    <td colspan="2" rowspan="2" align="left" valign="top">&nbsp;</td>
  </tr>
  <tr>
    <td height="27" colspan="2" valign="top">&nbsp;</td>
    <td height="27" valign="top">&nbsp;</td>
  </tr>
</table>

<?php include "../config.php";
$Operation->Operation();
$ip = getenv("REMOTE_ADDR");
date_default_timezone_set('Asia/karachi');
$TIME = date("h:i:s", time());
extract($_POST);
$date=date('Y-m-d');
$no=$_REQUEST['t_no'];
$opd=$_REQUEST['opd'];
$pd_no=$_REQUEST['pd_no'];
list($pdno, $no) = explode(",", $no);
 $sql="SELECT * From tests1 where PDNO='$pdno' AND TNO='$no'";
	$data =mysql_query($sql) or die(mysql_error());
	$row=mysql_fetch_array($data);
$pdno=$row['PDNO'];
$Tno=$row['TNO'];
$request=$row['TNAME'];
$max_lab=$Operation->maximum_number_lab($pdno,$Tno);
//echo $max_lab['mx'];
$sql_query="INSERT INTO `pat_test` SET `OPD_NO`='$opd',`RDATE`='',`PDNO`='$pdno',`TNO`='$Tno',`REQUEST`='$request',`DDATE`='$date',`DTIME`='$TIME',`RES_FEED`=''";
$done=mysql_query($sql_query) or die(mysql_error());
if($done)
{
	echo $request; 
	}else
	{
		echo "no";
		}
?>
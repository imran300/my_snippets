<?php include("../config.php");
$Operation->Operation();
extract($_POST);
$ip = getenv("REMOTE_ADDR");
   date_default_timezone_set('Asia/karachi');
	$TIME = date("h:i:s", time());
		$date=date('Y-m-d');
		for($i=0;$i<count($result);$i++)
		{
			echo $result[$i];
			
			echo "<br>";
			echo "resultid is".$result_id[$i];
			echo "<br>";
			echo "case is".$case_id[$i];
			mysql_query("update `test_against_cardialogy` set `test_result`='$result[$i]' where `id`='$case_id[$i]' and `c_test_id`='$result_id[$i]'");
			
			}
		
		?>
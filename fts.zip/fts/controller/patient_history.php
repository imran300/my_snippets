
<?php  $patient_id=$_REQUEST['id'];?>
<table width="100%" border="0" align="center">
  <tr>
    <td height="109" valign="top"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
      <td width="9%" align="center"><a href="javascript:;"  class="link"></td>
        <td width="15%" align="center">&nbsp;&nbsp;</td>
        <td width="9%" align="center"><input type="button" name="button2" id="button2" value="Patient History" onclick="get_history(<?php echo $patient_id;?>)" class="button_exampless" /></td>
        <td width="11%" align="center"><input type="button" name="button3" id="button3" value="Lab Tests Detail" onclick="get_lab_test(<?php echo $patient_id;?>)" class="button_exampless" /></td>
        
        <td width="10%" align="right"><input type="button" name="button" id="button" value="Medication Detail" onclick="get_medication(<?php echo $patient_id;?>)" class="button_exampless" /></td>
        <td width="2%" align="center">&nbsp;</td>
        <td align="left"><input type="button" name="button4" id="button4" value="X-Ray Detail" onclick="get_x_ray_second(<?php echo $patient_id;?>)" class="button_exampless" /></td>
        <td><input type="button" name="button5" id="button5" value="Cardialogy Detail" onclick="get_card_second(<?php echo $patient_id;?>)" class="button_exampless" /></td>
        <td width="10%"><a href="javascript:;" onclick="panel_for_patient_history_hide()" style="color:#F00; font-family:Verdana, Geneva, sans-serif; font-size:12px;"">Close</a></td>
      </tr>
      <tr>
        <td colspan="9"><div id="container_patient" style="display:none;"></div>&nbsp;</td>
        </tr>
    </table></td>
  </tr>
</table>

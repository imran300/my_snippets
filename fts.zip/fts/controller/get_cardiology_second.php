<?php 
include("../config.php");
$med=$Operation->get_cardiology($_REQUEST['patient_id']);
//print_r($med);
?>
<fieldset class="signups"><legend>Patient's Cardialogy History</legend><table width="80%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr class="heading">
    <td width="20%"><strong>Patient Name</strong></td>
    <td width="12%"><strong>OPD NO</strong></td>
    <td width="18%"><strong>Test Name</strong></td>
    <td width="12%"><strong>Result</strong></td>
    <td width="24%"><strong>Dated</strong></td>
  </tr>
 
 <?php for($i=0; $i<count($med);$i++)
 { ?>
  <tr>
    <td><?php echo $med[$i]['NAME'];?></td>
    <td>&nbsp;<?php echo $med[$i]['opd_id'];?></td>
    <td>&nbsp;<?php echo $med[$i]['c_test_name'];?></td>
    <td>&nbsp;<?php echo $med[$i]['test_result'];?></td>
    <td>&nbsp;<?php $date= $med[$i]['OPDDATE'];
	echo date("d/M/Y",strtotime($date));
	
	?></td>
    
  </tr>
  <?php } ?>
</table></fieldset>
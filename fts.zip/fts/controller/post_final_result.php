<?php include("../config.php");
$Operation->Operation();
extract($_POST);
$ip = getenv("REMOTE_ADDR");
   date_default_timezone_set('Asia/karachi');
	$TIME = date("h:i:s", time());
		$date=date('Y-m-d');
		////post:value_result,lab:lab_id,opd:opd_no,pd:pdno,t_no:tno,nor_f:nor_f,nor_t:nor_to,unit_n:unit_no
		$post=$_REQUEST['post'];
		$lab=$_REQUEST['lab'];
		$opd=$_REQUEST['opd'];
		$pd=$_REQUEST['pd'];
		$tno=$_REQUEST['t_no'];
		$nor_from=$_REQUEST['nor_f'];
		$nor_to=$_REQUEST['nor_t'];
		$unit=$_REQUEST['unit_n'];
$sql_post="INSERT INTO  `pat_result` set `LAB`='$lab',`OPD_NO`='$opd',`RDATE`='$date',`SNO`='',`PDNO`='$pd',`TNO`='$tno',`GNO`='',`SGNO`='',`VALUE`='$post',`FEEDBY`='',`NORMAL_FR`='$nor_from',`NORMAL_TO`='$nor_to',`UNIT`='$unit',`TIME`='$TIME',`DATE`='$date',`IP`='$ip'";
$sql_done=mysql_query($sql_post) or die(mysql_error());
		if($sql_done)
		{
			echo "done";
			
			}
		?>
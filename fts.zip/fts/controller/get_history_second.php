<?php 
include("../config.php");
$history=$Operation->get_history($_REQUEST['patient_id']);
//print_r($history);
?>
<fieldset class="signups"><legend>Patient's History</legend><table width="80%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr class="heading">
    <td><strong>Total Visits </strong><?php echo count($history);?></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr class="heading">
    <td width="21%"><strong>Patient Name</strong></td>
    <td width="11%"><strong>OPD NO</strong></td>
    <td width="15%"><strong>Ailment</strong></td>
    <td width="10%"><strong>BP</strong></td>
    <td width="12%"><strong>Pulse</strong></td>
    <td width="22%"><strong>Temperature</strong></td>
    <td width="9%"><strong>Dated</strong></td>
  </tr>
 
 <?php for($i=0; $i<count($history);$i++)
 { ?>
  <tr>
    <td><?php echo $history[$i]['NAME'];?></td>
    <td>&nbsp;<?php echo $history[$i]['opd_id'];?></td>
    <td>&nbsp;<?php echo $history[$i]['ail_ment'];?></td>
    <td>&nbsp;<?php echo $history[$i]['bp'];?></td>
    <td>&nbsp;<?php echo $history[$i]['pulse'];?></td>
    <td>&nbsp;<?php echo $history[$i]['temperature'];?></td>
    <td>&nbsp;<?php $date= $history[$i]['OPDDATE'];
	echo date("d/M/Y",strtotime($date));
	
	?></td>
    
  </tr>
  <?php } ?>
</table></fieldset>
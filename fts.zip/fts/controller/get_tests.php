<?php include("../config.php");
$Operation->Operation();
$y=$_REQUEST['no'];
$sql="SELECT `TNO` , `TNAME`
FROM `tests1` AS T
WHERE `PDNO` ='$y'";
$sql_number=mysql_query($sql) or die(mysql_error());
$num=mysql_num_rows($sql_number);
if($num<1)
{
echo "<option>No Record Found</potion>";
}
else
{
	echo "<option value=''>Select Test Name </option>";
while($rows=mysql_fetch_array($sql_number))
{
?>
<option value="<?php echo $rows['TNO'];?>"><?php echo $rows['TNAME'];?></option>
<?php  } }
?>
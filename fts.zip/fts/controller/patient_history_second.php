<table width="100%" border="0" align="center">
  <tr>
    <td height="109" valign="top"><table width="88%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
      <td width="5%" align="center"><a href="javascript:;"  class="link"></td>
        <td width="15%" align="center"><input type="button" name="button2" id="button2" value="Patient History" onclick="get_history_second(<?php echo $patient_id;?>)" class="button_exampless" /></td>
        <td width="16%" align="center"><input type="button" name="button3" id="button3" value="Lab Tests Detail" onclick="get_lab_test_second(<?php echo $opd_id;?>)" class="button_exampless" /></td>
        
        <td width="17%" align="right"><input type="button" name="button" id="button" value="Medication Detail" onclick="get_medication_second(<?php echo $opd_id;?>)" class="button_exampless" /></td>
        
        <td width="13%" align="left"><input type="button" name="button4" id="button4" value="X-Ray Detail" onclick="get_x_ray_second(<?php echo $patient_id;?>)" class="button_exampless" /></td>
        <td width="17%"><input type="button" name="button5" id="button5" value="Cardialogy Detail" onclick="get_card_second(<?php echo $patient_id;?>)" class="button_exampless" /></td>
        <td width="17%"><input type="button" name="button6" id="button6" value="Ultrasound Detail" onclick="get_ultra_second(<?php echo $opd_id;?>)" class="button_exampless" /></td>
      </tr>
      <tr>
        <td colspan="8"><div id="container_patient" style="display:none;"></div></td>
        </tr>
    </table></td>
  </tr>
</table>
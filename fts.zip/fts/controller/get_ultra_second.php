<?php 
include("../config.php");
$id=$_REQUEST['patient_id'];
$data = $Operation->search_ultrasound_by_opdno_for_report($id);
//$data = $pharmacy->getMedicationRecord($id);
//$med=$Operation->get_medications();
//print_r($data);
?>
<fieldset class="signups"><legend>Patient's Ultrasound History</legend><div class="body-container">
		<div>
			<h2>Patient Ultrasound Details</h2>
            <div>
              <!-- Personal Information -->
              <table style="width:100% !important; margin:0 auto;" width="662" border="0" cellpadding="0" cellspacing="0" class="list title" align="left">
                      <thead>
              <tr>
                <td width="142" align="center" valign="middle"><span class="whitesmalltabtext"><strong>S.No</strong></span></td>
                <td width="231" align="center" valign="middle"><span class="whitesmalltabtext"><strong>Ultrasound Test Name</strong></span></td>
                <td width="200" align="center" valign="middle"><span class="whitesmalltabtext"><strong>Result</strong></span></td>
      </tr>
              </thead>
                <?php
				$a=1;
				if($data==''){
				echo "<center>"."No Record Found"."</center>";
				}
				else
				{
				for($i=0;$i<count($data);$i++)
		{
			?>
                <tr align="left">
                  <td align="center" valign="middle"><?= $a++; ?></td>
                  <td align="center" valign="middle"><?= $data[$i]['ultrasound_name']; ?></td>
                  <td align="center" valign="middle"><?= $data[$i]['result_ultrasound']; ?></td>
                
                </tr>
                <?php  } } ?>
                <tr>
                <td colspan="5">&nbsp;</td>
                </tr>
              </table>
            </div>
				<div>
               	  <form name="" method="post" id="frm" action="">
                    <input type="hidden" name="employee_id" value="<?php /// echo $eid ?>" />
                    <input type="hidden" name="created_by" value="<?php echo $_SESSION['luser']['id'] ?>" />
                    <input type="hidden" name="salary_detail_id" id="salary_detail_id" value="" />
                    <input type="hidden" name="action" id="action" value="add" />
               	  </form>

		</div>
		
</div>
</div></fieldset>
<?php 
include("../config.php");
$Operation->Operation();
 $year=date("Y");
	$sql_number=mysql_query("SELECT IFNULL( MAX(patient_id) , 0)+1 as yearly FROM `patient_record` as p
WHERE date LIKE '%$year%'") or die(mysql_error());
$row=mysql_fetch_assoc($sql_number);
$number= $row['yearly'];
?>
Patient's Id : <input type="text" name="new_patient_id" id="new_patient_id" value="<?php echo $number;?>" style="width:100px !important; border:2px solid #099; " readonly />  Status: <select name="status" id="status" style="width:100px; "><option selected="selected" value="Titled">Titled</option>
<option value="untitled">UnTitled</option></select>
<?php
include "../connect.php";
$fromdept = $_REQUEST['fromdept'];
    $sqlsection = mysql_query("SELECT * FROM `section`
	 WHERE `iddepartment` = '$fromdept' 
	 AND `status`=1
	 ORDER BY `section` ASC");
if (mysql_num_rows($sqlsection) < 1) {
    echo '<option value="">No Section</option>';
} else {
    echo '<option value="">Select Section</option>';
    while ($resultsection = mysql_fetch_array($sqlsection)) {
        echo '<option value="' . $resultsection['idsection'] . '">' . $resultsection['section'] . '</option>';
    }
}
?>
<?php 
include("../config.php");
$data=$Operation->get_LabTest($_REQUEST['patient_id']);
//print_r($data);
?>
<fieldset class="signups"><legend>Patient's Laboratory History</legend><table width="80%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr class="heading">
    <td><strong>Total Tests : </strong> <?php echo count($data);?></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr class="heading">
    <td width="23%"><strong>Patient Name</strong></td>
    <td width="13%"><strong>OPD NO</strong></td>
    <td width="17%"><strong>Test Name</strong></td>
    <td width="18%"><strong>Result</strong></td>
    <td width="29%"><strong>Dated</strong></td>
  </tr>
 
 <?php for($i=0; $i<count($data);$i++)
 { ?>
  <tr>
    <td><?php echo $data[$i]['NAME'];?></td>
    <td>&nbsp;<?php echo $data[$i]['opd_id'];?></td>
    
    <td>&nbsp;<?php echo $data[$i]['m_test_name'];?></td>
    <td>&nbsp;<?php echo $data[$i]['test_result'];?></td>
    <td>&nbsp;<?php $date= $data[$i]['OPDDATE'];
	echo date("d/M/Y",strtotime($date));
	
	?></td>
    
  </tr>
  <?php } ?>
</table></fieldset>
<?php include("../config.php");
$Operation->Operation();
extract($_POST);
$ip = getenv("REMOTE_ADDR");
   date_default_timezone_set('Asia/karachi');
	$TIME = date("h:i:s", time());
		$date=date('Y-m-d');
if(isset($_REQUEST['existing_patient']))
{
	//$med_array=count($Medicine);
	//$medicines=$_REQUEST['medicines'];	////////id=24&status=new&new_patient_id=2&ailment=&bp=&pulse=&wtht2=&temperature=&medicines%5B%5D=1&frequency%5B%5D=2&timing%5B%5D=3&remarks2=&opd_no2=24
	$sql_for_history="INSERT INTO `patient_history` SET
	 				patient_id = '$existing_patient',
				 	opd_id = '$id', 
				 	ail_ment= '$ailment',
					bp='$bp',
					pulse='$pulse',
					wtht='$wtht',
					temperature='$temperature',
					comments='$remarks',
					time='$TIME',
					Date='$date',
					ip='$ip',
					user_id=".$_SESSION['luser']['id']."";
					$history=mysql_query($sql_for_history);
					////////////////////
	
					///////////////sql for TEST////////////////
					
		/////////////////////////////////////////////////
		if(!empty($test_c) || count($test_c)>=1)
					{
		foreach($test_c as $row_test_c)
					{
					mysql_query("INSERT INTO `test_against_cardialogy` SET c_test_id='$row_test_c', opd_id='$id',patient_id='$existing_patient',time='$TIME',
					Date='$date',
					ip='$ip',
					user_id=".$_SESSION['luser']['id']."");
						}
		}
		//////////////////////
		if(!empty($test_x) || count($test_x)>=1)
					{
		foreach($test_x as $row_test_x)
					{
					mysql_query("INSERT INTO `test_against_x_ray` SET x_test_id='$row_test_x', opd_id='$id',patient_id='$existing_patient',time='$TIME',
					Date='$date',
					ip='$ip',
					user_id=".$_SESSION['luser']['id']."");
						}
		}
		/////////for ultrasound ///////
		if(!empty($ultrasound) || count($ultrasound)>=1)
					{
		foreach($ultrasound as $ultrasounds)
					{
					mysql_query("INSERT INTO `assigned_ultrasound` SET ultrasound_name='$ultrasounds', opd_no='$id',patient_id='$existing_patient',time='$TIME',
					Date='$date',
					ip='$ip',
					user_id=".$_SESSION['luser']['id']."");
						}
		}
		
		///////////////////////////////

		if($history)
		{
			echo "existing done";
			}
		
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	if(isset($_REQUEST['new_patient_id']))
{
	if(empty($hidden_file) || $hidden_file=="")
	{
		$attachment="";
		$status="untitled";
		}
		else
		{
			$attachment=$hidden_file;
			$status="titled";
			}
	$sql_for_patient="INSERT INTO `patient_record` SET
	 				patient_id = '$new_patient_id',
				 	opd_id = '$id',
					name='$name',
				 	father_name= '$f_name',
					gender='$gender',
					attached_copy='$attachment',
					status='$status',
					time='$TIME',
					date='$date',
					ip='$ip',
					user_id=".$_SESSION['luser']['id']."";
	$sql_new_p=mysql_query($sql_for_patient);
	
		if(!empty($test_c) || count($test_c)>=1)
					{
		foreach($test_c as $row_test_c)
					{
						mysql_query("INSERT INTO `test_against_cardialogy` SET c_test_id='$row_test_c', opd_id='$id',patient_id='$new_patient_id',time='$TIME',
					Date='$date',
					ip='$ip',
					user_id=".$_SESSION['luser']['id']."");
						}
		}
		//////////////////////
		if(!empty($test_x) || count($test_x)>=1)
					{
		foreach($test_x as $row_test_x)
					{
						mysql_query("INSERT INTO `test_against_x_ray` SET x_test_id='$row_test_x', opd_id='$id',patient_id='$new_patient_id',time='$TIME',
					Date='$date',
					ip='$ip',
					user_id=".$_SESSION['luser']['id']."");
						}
		}
		///////////////for ultra s////////
		if(!empty($ultrasound) || count($ultrasound)>=1)
					{
		foreach($ultrasound as $ultrasounds)
					{
					mysql_query("INSERT INTO `assigned_ultrasound` SET ultrasound_name='$ultrasounds', opd_no='$id',patient_id='$new_patient_id',time='$TIME',
					Date='$date',
					ip='$ip',
					user_id=".$_SESSION['luser']['id']."");
						}
		}
	/*for($i=0;$i<count($medicines);$i++)
	{
	 $sql_for_pharmacy="INSERT INTO `pharmacy` SET
	 				med_id = '$new_patient_id',
				 	opd_id = '$id',
					patient_id='$new_patient_id',
					med_name='$medicines[$i]',
					frequency='$frequency[$i]',
					timing='$timing[$i]',
					time='$TIME',
					date='$date',
					ip='$ip',
					user_id=".$_SESSION['luser']['id']."";
									$phar_new=mysql_query($sql_for_pharmacy) or die(mysql_error());
	}
	*/
	$sql_for_history="INSERT INTO `patient_history` SET
	 				patient_id = '$new_patient_id',
				 	opd_id = '$id', 
				 	ail_ment= '$ailment',
					bp='$bp',
					pulse='$pulse',
					wtht='$wtht',
					temperature='$temperature',
					time='$TIME',
					Date='$date',
					ip='$ip',
					user_id=".$_SESSION['luser']['id']."";
		$historys=mysql_query($sql_for_history);
	if($sql_new_p && $historys)
	{
	echo "New Done";
	}
	}
?>
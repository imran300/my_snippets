<?php
error_reporting(0);
ob_start();
session_start();
include_once "conn.php";


$config = new Config();
include $config->absolute_path . "classes/DBaccess.php";
include $config->absolute_path . "classes/general.php";
include $config->absolute_path . "classes/users.php";
include $config->absolute_path . "classes/employee.php";
include $config->absolute_path . "classes/operation.php";
include $config->absolute_path . "classes/menu.php";
include $config->absolute_path . "classes/pager.php";
include $config->absolute_path . "classes/cms.php";
include $config->absolute_path . "classes/accounts.php";
include $config->absolute_path . "classes/pharmacy.php";
include $config->absolute_path . "classes/report.php";
$general = new General();
$groups = new User();
$user = new User();
$employee = new Employee();
$Operation = new Operation();
$menu = new Menu();
$pager = new Pager();
$Cms = new Cms();
$accounts = new Accounts();
$pharmacy = new Pharmacy();
$report = new Report();
?>
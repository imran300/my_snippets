<?php
if(isset($_POST['saveuser'])){
   extract ($_POST);
      if($password!=$cpassword){
		  $error = "Passwords are not matched";
	  }else{
		$cpassword = md5($cpassword);
		$check = $con->prepare("SELECT * FROM `users` 
		WHERE `username` = :username
		AND `status`=1");
		//$check->bindParam(':idemployee', $idemployee, PDO::PARAM_INT);
		$check->bindParam(':username', $username, PDO::PARAM_STR);
		$check->execute();
		if($check->rowCount() > 0){
		 $error = "User Already Exists";
		}
		else{
			$insertuser=$con->prepare("INSERT INTO `users` SET `idemployee` = :idemployee, `username` = :username, `password`= :cpassword, `isactive`= :isactive, isadmin= :isadmin");
			$insertuser->bindParam(':idemployee', $idemployee, PDO::PARAM_INT);
		    $insertuser->bindParam(':username', $username, PDO::PARAM_STR);
			$insertuser->bindParam(':cpassword', $cpassword, PDO::PARAM_STR);
			$insertuser->bindParam(':isactive', $isactive, PDO::PARAM_INT);
			$insertuser->bindParam(':isadmin', $isadmin, PDO::PARAM_INT);
		    $insertuser->execute();
		    if($insertuser){
			 $success = "User Added Successfully";
			}
		}
	  }
}
?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Users</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Add New User
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form role="form" method="post">
							<?php
                            if(isset($error)){
                              echo '<div class="alert alert-dismissable alert-danger">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong>'.$error.'</strong> </div>';
                                }
                                if(isset($success)){
                              echo '<div class="alert alert-dismissable alert-success">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong>'.$success.'</strong> </div>';
                                }
                                ?>
                                         <div class="form-group">
                                            <label>Employee</label>
                                            <select name="idemployee" class="form-control" autofocus tabindex="1" required>
                                            <option value="">Select Employee</option>
                                            <?php
											if($superadmin==1){
											$sqlemployee=$con->query("SELECT * FROM `employee` ORDER BY `empname` ASC");
											}else{
												$sqlemployee=$con->query("SELECT * FROM `employee`
												WHERE iddepartment = '$iddepartment'
												ORDER BY `empname` ASC");
											}
											while($resultemployee=$sqlemployee->fetch(PDO::FETCH_ASSOC)){
												echo '<option value="'.$resultemployee['idemployee'].'">'.$resultemployee['empname'].'</option>';
											}
											?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Username</label>
                                            <input type="text" class="form-control" name="username" placeholder="username" tabindex="2" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Password</label>
                                            <input type="password" class="form-control" name="password" placeholder="Password" tabindex="3" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Confirm Password</label>
                                            <input type="password" class="form-control" name="cpassword" placeholder="Password" tabindex="4" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Status</label>
                                            <label class="radio-inline">
                                                <input type="radio" name="isactive"  tabindex="5" id="optionsRadiosInline1" value="1" checked="">Active
                                            </label>
                                            <label class="radio-inline">
                                                <input type="radio" name="isactive" id="optionsRadiosInline2" value="0">Inactive
                                            </label>
                                        </div>
                                        <div class="form-group">
                                            <label>Admin</label>
                                            <label class="radio-inline">
                                                <input type="radio" name="isadmin" id="optionsRadiosInline1" value="1">Yes
                                            </label>
                                            <label class="radio-inline">
                                                <input type="radio" name="isadmin" tabindex="6" id="optionsRadiosInline2" value="0" checked="">No
                                            </label>
                                        </div>
                                       
                                        <button type="submit" class="btn btn-success" tabindex="7" name="saveuser"><span class="fa fa-plus"></span> Save User</button>
                                        <a href="index.php?option=hr&item=users" class="btn btn-danger"><span class="fa fa-minus"></span> Cancel</a>
                                    </form>
                                </div>
                               
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <!-- /.row -->
           
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

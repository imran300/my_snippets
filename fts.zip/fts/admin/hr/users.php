
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Users</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Users Record
                            <div class="pull-right">
                                <div class="btn-group">
                                    <a href="index.php?option=hr&item=addusers" class="btn btn-primary btn-xs">
                                        <span class="fa fa-plus"></span> Add New User
                                    </a>
                                    
                                </div>
                            </div>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th width="10%">Name</th>
											<th width="10%">Username</th>
											<th width="20%">Section</th>
                                            <th width="20%">Department</th>
                                            <th width="15%">Status</th>
                                            <th width="25%">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
									if($superadmin==1){
									$sql = $con->query("SELECT * 
									FROM  `users` AS u,  `employee` AS e,  `department` AS d,  `section` AS s,  `designation` AS g
									WHERE u.idemployee = e.idemployee
									AND e.iddepartment = d.iddepartment
									AND e.idsection = s.idsection
									AND e.iddesignation = g.iddesignation
									AND u.status =1");
									}else{
									$sql = $con->query("SELECT * 
									FROM  `users` AS u,  `employee` AS e,  `department` AS d,  `section` AS s,  `designation` AS g
									WHERE u.idemployee = e.idemployee
									AND e.iddepartment = d.iddepartment
									AND e.idsection = s.idsection
									AND e.iddesignation = g.iddesignation
									AND e.iddepartment = '$iddepartment'
									AND u.status =1");
									}
									while($result=$sql->fetch(PDO::FETCH_ASSOC)){
									?>
                                        <tr class="odd gradeX">
                                            <td><?=$result['empname'];?></td>
											<td><?=$result['username'];?></td>
											<td><?=$result['section'];?></td>
                                            <td><?=$result['department'];?></td>
                                            <td class="center"><?php
                                            $status=$result['isactive'];
											if($status==1){
												echo '<span class="label label-success">Active</span>';
											}else{
												echo '<span class="label label-default">Inactive</span>';
											}
											?>
											<?
                                            $adminuser=$result['isadmin'];
											if($adminuser==1){
												echo '<span class="label label-info">Admin</span>';
											}
											?></td>
                                            <td class="center">
                                            <a class="btn btn-success btn-xs" href="index.php?option=hr&item=changepassusers&id=<?=$result['idusers'];?>"><span class="fa fa-edit"></span> Change Password</a>
                                            <a class="btn btn-warning btn-xs" href="index.php?option=hr&item=editusers&id=<?=$result['idusers'];?>"><span class="fa fa-edit"></span> Edit User</a>
                                            </td>
                                        </tr>
                                       <?php
									   }
									   ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <!-- /.row -->
           
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

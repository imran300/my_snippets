
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Employee</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Employee Record
                            <div class="pull-right">
                                <div class="btn-group">
                                    <a href="index.php?option=hr&item=addemployee" class="btn btn-primary btn-xs">
                                        <span class="fa fa-plus"></span> Add New Employee
                                    </a>
                                    
                                </div>
                            </div>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                        
                                            <th width="15%">Department</th>
                                            <th width="25%">Section</th>
                                            <th width="15%">Designation</th>
                                            <th width="20%">Name</th>
                                            <th width="15%">Email</th>
                                            <th width="10%">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
									if($superadmin==1){
									$sql=$con->query("SELECT * 
									FROM employee as e, department as d, section as s, designation as g
									WHERE e.iddepartment = d.iddepartment
									AND e.idsection = s.idsection
									AND e.iddesignation = g.iddesignation
									AND e.status = 1");
									}else{
									$sql=$con->query("SELECT * 
									FROM employee as e, department as d, section as s, designation as g
									WHERE e.iddepartment = d.iddepartment
									AND e.idsection = s.idsection
									AND e.iddepartment = '$iddepartment'
									AND e.iddesignation = g.iddesignation
									AND e.status = 1");
									}
									while($result=$sql->fetch(PDO::FETCH_ASSOC)){
									?>
                                        <tr class="odd gradeX">
                                            <td><?=$result['department'];?></td>
                                            <td><?=$result['section'];?></td>
                                            <td><?=$result['designation'];?></td>
                                            <td><?=$result['empname'];?></td>
                                            <td><?=$result['empemail'];?></td>
                                            <td class="center">
                                            <a class="btn btn-warning btn-xs" href="index.php?option=hr&item=editemployee&id=<?=$result['idemployee'];?>"><span class="fa fa-edit"></span> Edit</a>
                                            </td>
                                        </tr>
                                       <?php
									   }
									   ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <!-- /.row -->
           
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

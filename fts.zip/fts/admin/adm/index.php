<?php
include "header.php";
include "menu.php"; 
$option = 'home'; 
if(isset($_GET['option'])){
	$option = $_GET['option'];
}
if(isset($_GET['item'])){
	$item = $option."/".$_GET['item'].".php";

	include ($item);
}else{
	include($option.".php");
}
include "footer.php";
 ?>
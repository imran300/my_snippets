<?php

include "../conn.php";
$iddepartment = $_REQUEST['iddepartment'];
$sqlsection = $con->query("SELECT * FROM `section`
	 WHERE `iddepartment` = '$iddepartment' 
	 AND `status`=1
	 ORDER BY `section` ASC");
if ($sqlsection->rowCount() < 1) {
    echo '<option value="">No Section</option>';
} else {
    echo '<option value="">Select Section</option>';
    while ($resultsection = $sqlsection->fetch(PDO::FETCH_ASSOC)) {
        echo '<option value="' . $resultsection['idsection'] . '">' . $resultsection['section'] . '</option>';
    }
}
?>
<?php
session_start();
unset($_SESSION['fts']);
header("location:login.php");
?>
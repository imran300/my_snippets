function getsection(){
	var iddepartment = $('#iddepartment').val();
	$.post('code/getsection.php', {iddepartment:iddepartment}, function(result){
		$('#idsection').html(result);
        $('#idsection').val();
	});
}
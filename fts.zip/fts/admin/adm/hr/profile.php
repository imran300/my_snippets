
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Profile</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Employee Profile
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <?php
							$idusers=$_GET['id'];
							$sql=$con->query("SELECT * 
				FROM users as u, employee as e, department as d, section as s, designation as g
				WHERE u.idemployee = e.idemployee 
				AND e.iddepartment = d.iddepartment
				AND e.idsection = s.idsection
				AND e.iddesignation = g.iddesignation
				AND u.idusers = '$idusers'");
							$result=$sql->fetch(PDO::FETCH_ASSOC);
							?>
                            <div class="table-responsive">
                            
                                <table class="table table-striped table-bordered table-hover">
                                    
                                   <tr>
                                   <th>Name</th>
                                   <td><?=$result['empname'];?></td>
                                   <th>Email</th>
                                   <td><?=$result['empemail'];?></td>
                                   </tr>
                                   <tr>
                                   <th>Department</th>
                                   <td><?=$result['department'];?></td>
                                   <th>Section</th>
                                   <td><?=$result['section'];?></td>
                                   </tr>
                                   <tr>
                                   <th>Designation</th>
                                   <td colspan="3"><?=$result['designation'];?></td>
                                   
                                   </tr>
                                   
                                        
                                        
                                </table>
                                
                                
                            </div>
                            <!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <!-- /.row -->
           
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

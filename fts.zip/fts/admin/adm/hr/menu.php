
<div id="page-wrapper">
  <div class="row">
    <div class="col-lg-12">
      <h1 class="page-header">Menu</h1>
    </div>
    <!-- /.col-lg-12 --> 
  </div>
  <!-- /.row -->
  <div class="row">
    <div class="col-lg-12">
      <div class="panel panel-default">
        <div class="panel-heading"> Menu Record
          <div class="pull-right">
            <div class="btn-group"> <a href="index.php?option=hr&item=addmenu" class="btn btn-primary btn-xs"> <span class="fa fa-plus"></span> Add New Menu </a> </div>
          </div>
        </div>
        <!-- /.panel-heading -->
        <div class="panel-body">
          <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover">
              <thead>
                <tr>
                  <th width="20%">Title</th>
                  <th width="40%">Url</th>
                  <th width="10%">Sort Order</th>
                  <th width="10%">Status</th>
                  <th width="20%">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
									$sql=$con->query("SELECT * FROM `menu` WHERE `parent`='0' ORDER BY `sort` ASC");
									while($result = $sql->fetch(PDO::FETCH_ASSOC)){
									?>
                <tr class="odd gradeX">
                  <td><?=$result['title'];?></td>
                  <td><?=$result['url'];?></td>
                  <td><?=$result['sort'];?></td>
                  <td><?php
                                            $status=$result['status'];
											if($status==1){
												echo '<span class="label label-success">Active</span>';
											}else{
												echo '<span class="label label-default">Inactive</span>';
											}
											?></td>
                  <td class="center"><a class="btn btn-warning btn-xs" href="index.php?option=hr&item=editmenu&id=<?=$mid=$result['idmenu'];?>"><span class="fa fa-edit"></span> Edit Menu</a></td>
                </tr>
                <?php
									$sqlinner=$con->query("SELECT * FROM `menu` WHERE `parent`='$mid' ORDER BY `sort` ASC");
									while($resultinner = $sqlinner->fetch(PDO::FETCH_ASSOC)){
									?>
                <tr class="odd gradeX">
                  <td>&gt;&gt;
                    <?=$resultinner['title'];?></td>
                  <td><?=$resultinner['url'];?></td>
                  <td>&gt;
                    <?=$resultinner['sort'];?></td>
                  <td><?php
                                            $status=$resultinner['status'];
											if($status==1){
												echo '<span class="label label-success">Active</span>';
											}else{
												echo '<span class="label label-default">Inactive</span>';
											}
											?></td>
                  <td class="center"><a class="btn btn-warning btn-xs" href="index.php?option=hr&item=editmenu&id=<?=$resultinner['idmenu'];?>"><span class="fa fa-edit"></span> Edit Menu</a></td>
                </tr>
                <?php
									   }
									   ?>
                <?php
									   }
									   ?>
              </tbody>
            </table>
          </div>
          <!-- /.table-responsive --> 
          
        </div>
        <!-- /.panel-body --> 
      </div>
      <!-- /.panel --> 
    </div>
    <!-- /.col-lg-12 --> 
  </div>
  <!-- /.row --> 
  
  <!-- /.row --> 
  
</div>
<!-- /#page-wrapper -->

</div>
<!-- /#wrapper --> 

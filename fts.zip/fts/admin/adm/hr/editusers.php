<?php
		$idusers=$_GET['id'];
		$sql=$con->query("SELECT * FROM `users` as u, employee as e
		WHERE u.idemployee = e.idemployee
		AND u.`idusers`= '$idusers'");
		$result = $sql->fetch(PDO::FETCH_ASSOC);
		
if(isset($_POST['edituser'])){
   extract($_POST);
			$updateuser=$con->query("UPDATE `users` SET `idemployee` = '$idemployee', `username` = '$username', `isactive`='$isactive', isadmin= '$isadmin' WHERE `idusers`= '$idusers'");
		    if($updateuser){
			 $success = "User Updated Successfully";
			}
}
?>

<div id="page-wrapper">
  <div class="row">
    <div class="col-lg-12">
      <h1 class="page-header">Users</h1>
    </div>
    <!-- /.col-lg-12 --> 
  </div>
  <!-- /.row -->
  <div class="row">
    <div class="col-lg-12">
      <div class="panel panel-default">
        <div class="panel-heading"> Edit User </div>
        <div class="panel-body">
          <div class="row">
            <div class="col-lg-6">
              <form role="form" method="post">
                <?php
                            if(isset($error)){
                              echo '<div class="alert alert-dismissable alert-danger">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong>'.$error.'</strong> </div>';
                                }
                                if(isset($success)){
                              echo '<div class="alert alert-dismissable alert-success">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong>'.$success.'</strong> </div>';
                                }
                                ?>
                <div class="form-group">
                  <label>Employee</label>
                  <select name="idemployee" class="form-control">
                    <option value="<?=$emp_id=$result['idemployee'];?>">
                    <?=$result['empname'];?>
                    </option>
                    <?php
					$sqlemployee=$con->query("SELECT * FROM `employee` WHERE `idemployee`!='$emp_id' ORDER BY `empname` ASC");
					while($resultemployee=$sqlemployee->fetch(PDO::FETCH_ASSOC)){
						echo '<option value="'.$resultemployee['idemployee'].'">'.$resultemployee['empname'].'</option>';
						}
						?>
                  </select>
                </div>
                
                <div class="form-group">
                  <label>Username</label>
                  <input type="text" class="form-control" name="username" placeholder="Username" value="<?=$result['username'];?>" tabindex="2" required>
                </div>
                
                <div class="form-group">
                  <label>Status</label>
                  <?
					 $status=$result['isactive'];
					 if($status==1){
						 echo '<label class="radio-inline">
						<input type="radio" name="isactive"  tabindex="3" id="isactive1" value="1" checked="">Active
					</label>
					<label class="radio-inline">
						<input type="radio" name="isactive" id="isactive2" value="0">Inactive
					</label>';
					 }else{
						 echo '<label class="radio-inline">
						<input type="radio" name="isactive"  tabindex="3" id="isactive1" value="1">Active
					</label>
					<label class="radio-inline">
						<input type="radio" name="isactive" id="isactive2" value="0" checked="">Inactive
					</label>';
					 }
											?>
                </div>
                <div class="form-group">
                  <label>Admin</label>
                  <?
				 $admin=$result['isadmin'];
				 if($admin==1){
					 echo '<label class="radio-inline">
					<input type="radio" name="isadmin" id="isadmin1" value="1" checked="">Yes
				</label>
				<label class="radio-inline">
					<input type="radio" name="isadmin" tabindex="4" id="isadmin2" value="0">No
				</label>';
				 }else{
					 echo '<label class="radio-inline">
					<input type="radio" name="isadmin"  tabindex="3" id="isadmin1" value="1">Yes
				</label>
				<label class="radio-inline">
					<input type="radio" name="isadmin" tabindex="4" id="isadmin2" value="0" checked="">No
				</label>';
				 }
				?>
                </div>
                <button type="submit" class="btn btn-warning" tabindex="5" name="edituser"><span class="fa fa-edit"></span> Edit User</button>
                <a href="index.php?option=hr&item=users" class="btn btn-danger"><span class="fa fa-minus"></span> Cancel</a>
              </form>
            </div>
          </div>
          <!-- /.row (nested) --> 
        </div>
        <!-- /.panel-body --> 
      </div>
      <!-- /.panel --> 
    </div>
    <!-- /.col-lg-12 --> 
  </div>
  <!-- /.row --> 
  
  <!-- /.row --> 
  
</div>
<!-- /#page-wrapper -->

</div>
<!-- /#wrapper --> 

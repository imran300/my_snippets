<?php
	$idusers=$_GET['id'];
	$sql=$con->prepare("SELECT * FROM `users` as u, employee as e
	WHERE u.idemployee = e.idemployee
	AND u.`idusers`= :idusers");
	$sql->bindParam(':idusers', $idusers, PDO::PARAM_INT);
	$sql->execute();
	$result = $sql->fetch(PDO::FETCH_ASSOC);
   
   if(isset($_POST['changepassuser'])){
   extract ($_POST);
   if($password!=$cpassword){
		  $error = "Passwords are not matched";
	  }else{
		$cpassword = md5($cpassword);
			$updateuser=$con->prepare("UPDATE `users` SET `password`= :cpassword WHERE `idusers`= :idusers");
			$updateuser->bindParam(':cpassword', $cpassword, PDO::PARAM_STR);
	        $updateuser->bindParam(':idusers', $idusers, PDO::PARAM_INT);
			$updateuser->execute();
		    if($updateuser){
			 $success = "User Password Updated Successfully";
			}
	  }
}
?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Users</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Change Password
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form role="form" method="post">
							<?php
                            if(isset($error)){
                              echo '<div class="alert alert-dismissable alert-danger">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong>'.$error.'</strong> </div>';
                                }
                                if(isset($success)){
                              echo '<div class="alert alert-dismissable alert-success">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong>'.$success.'</strong> </div>';
                                }
                                ?>
                                        <div class="form-group">
                                            <label>Name</label>
                                            <input class="form-control" name="empname" id="empname" placeholder="Full Name" autocomplete="off" value="<?=$result['empname'];?>" readonly>
                                        </div>
                                        <div class="form-group">
                                            <label>Password</label>
                                            <input type="password" class="form-control" name="password" placeholder="Password" tabindex="1" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Confirm Password</label>
                                            <input type="password" class="form-control" name="cpassword" placeholder="Password" tabindex="2" required>
                                        </div>
                                        
                                        <button type="submit" class="btn btn-warning" tabindex="3" name="changepassuser"><span class="fa fa-edit"></span> Update</button>
                                        <a href="index.php?option=hr&item=users" class="btn btn-danger"><span class="fa fa-minus"></span> Cancel</a>
                                    </form>
                                </div>
                               
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <!-- /.row -->
           
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

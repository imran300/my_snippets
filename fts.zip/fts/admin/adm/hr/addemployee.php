<?php
if(isset($_POST['saveemployee'])){
   extract ($_POST);   
		$check = $con->query("SELECT * FROM `employee` 
		WHERE `empname` = '$empname' 
		AND `empemail` = '$empemail'");
		if($check->rowCount() > 0){
		 $error = "Employee Already Exists";
		}
		else
			$insertemployee=$con->query("INSERT INTO `employee` SET `iddepartment` = '$iddepartment', `idsection` = '$idsection', `iddesignation` = '$iddesignation', `empname` = '$empname', `empemail` = '$empemail'");
			if($insertemployee){
			 $success = "Employee Added Successfully";
			}
}
?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Employees</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Add New Employee
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form role="form" method="post" enctype="multipart/form-data">
							<?php
                            if(isset($error)){
                              echo '<div class="alert alert-dismissable alert-danger">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong>'.$error.'</strong> </div>';
                                }
                                if(isset($success)){
                              echo '<div class="alert alert-dismissable alert-success">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong>'.$success.'</strong> </div>';
                                }
                                ?>
                                
                                <div class="form-group">
                                            <label>Department</label>
                                            <select name="iddepartment" id="iddepartment" class="form-control" onChange="getsection();" tabindex="1" autofocus required>
                                            <option value="">Select Department</option>
											<?php
											if($superadmin==1){
											$sqldepartment=$con->query("SELECT * FROM `department`
											 WHERE `status`=1
											 ORDER BY `department` ASC");
											}else{
												$sqldepartment=$con->query("SELECT * FROM `department`
											 WHERE `iddepartment` = '$iddepartment' 
											 AND `status`=1
											 ORDER BY `department` ASC");
											}
											while($resultdepartment=$sqldepartment->fetch(PDO::FETCH_ASSOC)){
												echo '<option value="'.$resultdepartment['iddepartment'].'">'.$resultdepartment['department'].'</option>';
											}
											?>
                                            </select>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Section</label>
                                            <select name="idsection" id="idsection" tabindex="2" class="form-control" required>
                                            <option value="">Select Section</option>
                                            </select>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Designation</label>
                                            <select name="iddesignation" id="iddesignation" tabindex="3" class="form-control" required>
                                            <option value="">Select designation</option>
											<?php
											$sqldesignation=$con->query("SELECT * FROM `designation`
											 WHERE `status`=1
											 ORDER BY `designation` ASC");
											while($resultdesignation=$sqldesignation->fetch(PDO::FETCH_ASSOC)){
												echo '<option value="'.$resultdesignation['iddesignation'].'">'.$resultdesignation['designation'].'</option>';
											}
											?>
                                            </select>
                                        </div> 
                                        <div class="form-group">
                                            <label>Full Name</label>
                                            <input type="text" class="form-control" name="empname" placeholder="Name" tabindex="4" autocomplete="off" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Email</label>
                                            <input type="email" class="form-control" name="empemail" placeholder="Email" tabindex="5" required>
                                        </div>
                                        
                                        <button type="submit" class="btn btn-success" tabindex="6" name="saveemployee"><span class="fa fa-plus"></span> Save</button>
                                        <a href="index.php?option=hr&item=employee" class="btn btn-danger"><span class="fa fa-minus"></span> Cancel</a>
                                    </form>
                                </div>
                               
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <!-- /.row -->
           
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php
if(isset($_POST['savemenu'])){
   extract ($_POST);
		$check = $con->query("SELECT * FROM `menu` WHERE `title` = '$title'");
		if($check->rowCount() > 0){
		 $error = "Menu Already Exists";
		}
		else{
			$insertgroups=$con->query("INSERT INTO `menu` SET `title` = '$title', `url` = '$url', `parent` = '$parent', `status` = '$status', `sort` = '$sort`'");
		    if($insertgroups){
			 $success = "Menu Added Successfully";
			}
		}
}
?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Menu</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Add New Menu
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form role="form" method="post">
							<?php
                            if(isset($error)){
                              echo '<div class="alert alert-dismissable alert-danger">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong>'.$error.'</strong> </div>';
                                }
                                if(isset($success)){
                              echo '<div class="alert alert-dismissable alert-success">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong>'.$success.'</strong> </div>';
                                }
                                ?>
                                         
                                        <div class="form-group">
                                            <label>Title</label>
                                            <input type="text" class="form-control" name="title" placeholder="Title" tabindex="1" autofocus autocomplete="off" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Url</label>
                                            <input type="text" class="form-control" name="url" value="index.php?option=hr&item=menu" tabindex="2" autocomplete="off" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Parent</label>
                                            <select name="parent" class="form-control" tabindex="3" required>
                                            <option value="0">Select Parent</option>
                                            <?php
											$sqlparent=$con->query("SELECT * FROM `menu` 
											WHERE `parent`= '0'
											ORDER BY `sort` ASC");
											while($resultparent=$sqlparent->fetch(PDO::FETCH_ASSOC)){
												echo '<option value="'.$resultparent['idmenu'].'">'.$resultparent['title'].'</option>';
											}
											?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Sort Order</label>
                                            <input type="text" class="form-control" name="sort" value="0" tabindex="4" autocomplete="off" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Show in Menu</label>
                                            <label class="radio-inline">
                                                <input type="radio" name="status"  tabindex="5" id="optionsRadiosInline1" value="1" checked="">Active
                                            </label>
                                            <label class="radio-inline">
                                                <input type="radio" name="status" id="optionsRadiosInline2" value="0">Inactive
                                            </label>
                                        </div>
                                        
                                       
                                        <button type="submit" class="btn btn-success" tabindex="6" name="savemenu"><span class="fa fa-plus"></span> Save Menu</button>
                                        <a href="index.php?option=hr&item=menu" class="btn btn-danger"><span class="fa fa-minus"></span> Cancel</a>
                                    </form>
                                </div>
                               
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <!-- /.row -->
           
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php
$idemployee=$_GET['id'];
$sql=$con->query("SELECT * 
				FROM employee as e, department as d, section as s, designation as g
				WHERE e.iddepartment = d.iddepartment
				AND e.idsection = s.idsection
				AND e.iddesignation = g.iddesignation
				AND idemployee = '$idemployee'");
$result=$sql->fetch(PDO::FETCH_ASSOC);

if(isset($_POST['editemployee'])){
   extract($_POST);
			$updateemployee=$con->query("UPDATE `employee` SET `iddesignation` = '$iddesignation', `iddepartment` = '$iddepartment', `idsection` = '$idsection', `empname` = '$empname', `empemail` = '$empemail' WHERE `idemployee`='$idemployee'");
		    if($updateemployee){
			 $success = "Employee Updated Successfully";
			}
}
?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Employees</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Edit Employee
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form role="form" method="post" enctype="multipart/form-data">
							<?php
                            if(isset($error)){
                              echo '<div class="alert alert-dismissable alert-danger">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong>'.$error.'</strong> </div>';
                                }
                                if(isset($success)){
                              echo '<div class="alert alert-dismissable alert-success">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong>'.$success.'</strong> </div>';
                                }
                                ?>
                                        <div class="form-group">
                                            <label>Department</label>
                                            <select name="iddepartment" id="iddepartment" class="form-control" onChange="getsection();" tabindex="1" required>
                                            <option value="<?=$iddept=$result['iddepartment'];?>"><?=$result['department'];?></option>
											<?php
											$sqldepartment=$con->query("SELECT * FROM `department`
											 WHERE `iddepartment`!='$iddept'
											 AND `status`=1
											 ORDER BY `department` ASC");
											while($resultdepartment=$sqldepartment->fetch(PDO::FETCH_ASSOC)){
												echo '<option value="'.$resultdepartment['iddepartment'].'">'.$resultdepartment['department'].'</option>';
											}
											?>
                                            </select>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Section</label>
                                            <select name="idsection" id="idsection" tabindex="2" class="form-control" required>
                                            <option value="<?=$result['idsection'];?>"><?=$result['section'];?></option>
                                            </select>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Designation</label>
                                            <select name="iddesignation" id="iddesignation" tabindex="3" class="form-control" required>
                                            <option value="<?=$iddesignation=$result['iddesignation'];?>"><?=$result['designation'];?></option>
											<?php
											$sqldesignation=$con->query("SELECT * FROM `designation`
											 WHERE `iddesignation` != '$iddesignation' 
											 AND `status`=1
											 ORDER BY `designation` ASC");
											while($resultdesignation=$sqldesignation->fetch(PDO::FETCH_ASSOC)){
												echo '<option value="'.$resultdesignation['iddesignation'].'">'.$resultdesignation['designation'].'</option>';
											}
											?>
                                            </select>
                                        </div> 
                                        <div class="form-group">
                                            <label>Full Name</label>
                                            <input type="text" class="form-control" name="empname" placeholder="Name" tabindex="4" autocomplete="off" value="<?=$result['empname'];?>" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Email</label>
                                            <input type="email" class="form-control" name="empemail" placeholder="Email" tabindex="5" value="<?=$result['empemail'];?>" required>
                                        </div>
                                        
                                        <button type="submit" class="btn btn-warning" tabindex="7" name="editemployee"><span class="fa fa-edit"></span> Edit</button>
                                        <a href="index.php?option=hr&item=employee" class="btn btn-danger"><span class="fa fa-minus"></span> Cancel</a>
                                    </form>
                                </div>
                               
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <!-- /.row -->
           
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php
$iddesignation=$_GET['id'];
$sql=$con->query("SELECT * FROM `designation` WHERE iddesignation='$iddesignation'");
$result=$sql->fetch(PDO::FETCH_ASSOC);
if(isset($_POST['editdesignation'])){
   extract($_POST);
			$updatedesignation=$con->query("UPDATE `designation` SET `designation` = '$designation' WHERE `iddesignation`='$iddesignation'");
		    if($updatedesignation){
			 $success = "Designation Updated Successfully";
			}
}
?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Designation</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Edit Designation
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form role="form" method="post">
							<?php
                            if(isset($error)){
                              echo '<div class="alert alert-dismissable alert-danger">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong>'.$error.'</strong> </div>';
                                }
                                if(isset($success)){
                              echo '<div class="alert alert-dismissable alert-success">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong>'.$success.'</strong> </div>';
                                }
                                ?>
                                        
                                        <div class="form-group">
                                            <label>Designation</label>
                                            <input type="text" class="form-control" name="designation" autocomplete="off" placeholder="Designation" value="<?=$result['designation'];?>" tabindex="1" required>
                                        </div>
                                        
                                       
                                        <button type="submit" class="btn btn-warning" tabindex="2" name="editdesignation"><span class="fa fa-edit"></span> Edit</button>
                                        <a href="index.php?option=general&item=designation" class="btn btn-danger"><span class="fa fa-minus"></span> Cancel</a>
                                    </form>
                                </div>
                               
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <!-- /.row -->
           
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php
if(isset($_POST['savefiletype'])){
   extract ($_POST);
		$check = $con->query("SELECT * FROM `filetype` WHERE `filetype` = '$filetype'");
		if($check->rowCount() > 0){
		 $error = "File Type Already Exists";
		}
		else{
			$insertfiletype=$con->query("INSERT INTO `filetype` SET `filetype` = '$filetype'");
		    if($insertfiletype){
			 $success = "File Type Added Successfully";
			}
		}
}
?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">File Type</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Add New File Type
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form role="form" method="post">
							<?php
                            if(isset($error)){
                              echo '<div class="alert alert-dismissable alert-danger">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong>'.$error.'</strong> </div>';
                                }
                                if(isset($success)){
                              echo '<div class="alert alert-dismissable alert-success">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong>'.$success.'</strong> </div>';
                                }
                                ?>
                                         
                                        <div class="form-group">
                                            <label>File Type</label>
                                            <input type="text" class="form-control" name="filetype" placeholder="File Type" tabindex="1" autofocus autocomplete="off" required>
                                        </div>
                                        
                                       
                                        <button type="submit" class="btn btn-success" tabindex="2" name="savefiletype"><span class="fa fa-plus"></span> Save</button>
                                        <a href="index.php?option=general&item=filetype" class="btn btn-danger"><span class="fa fa-minus"></span> Cancel</a>
                                    </form>
                                </div>
                               
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <!-- /.row -->
           
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

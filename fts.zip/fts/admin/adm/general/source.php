
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Source</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Source Record
                            <div class="pull-right">
                                <div class="btn-group">
                                    <a href="index.php?option=general&item=addsource" class="btn btn-primary btn-xs">
                                        <span class="fa fa-plus"></span> Add New Source
                                    </a>
                                    
                                </div>
                            </div>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th width="80%">Source</th>
                                            <th width="20%">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
									$sql=$con->query("SELECT * FROM `source` ORDER BY `source` ASC");
									while($result=$sql->fetch(PDO::FETCH_ASSOC)){
									?>
                                        <tr class="odd gradeX">
                                            <td><?=$result['source'];?></td>
                                            
                                            <td class="center">
                                            <a class="btn btn-warning btn-xs" href="index.php?option=general&item=editsource&id=<?=$result['idsource'];?>"><span class="fa fa-edit"></span> Edit</a>
                                            </td>
                                        </tr>
                                       <?php
									   }
									   ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <!-- /.row -->
           
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

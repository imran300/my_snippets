
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Flag</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Flag Record
                            <div class="pull-right">
                                <div class="btn-group">
                                    <a href="index.php?option=general&item=addflag" class="btn btn-primary btn-xs">
                                        <span class="fa fa-plus"></span> Add New Flag
                                    </a>
                                    
                                </div>
                            </div>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th width="80%">Flag</th>
                                            <th width="20%">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
									$sql=$con->query("SELECT * FROM `flag` ORDER BY `flag` ASC");
									while($result=$sql->fetch(PDO::FETCH_ASSOC)){
									?>
                                        <tr class="odd gradeX">
                                            <td><?=$result['flag'];?></td>
                                            
                                            <td class="center">
                                            <a class="btn btn-warning btn-xs" href="index.php?option=general&item=editflag&id=<?=$result['idflag'];?>"><span class="fa fa-edit"></span> Edit</a>
                                            </td>
                                        </tr>
                                       <?php
									   }
									   ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <!-- /.row -->
           
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

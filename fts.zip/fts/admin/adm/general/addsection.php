<?php
if(isset($_POST['savesection'])){
   extract ($_POST);
		$check = $con->query("SELECT * FROM `section` WHERE `iddepartment`='$iddepartment' AND `section` = '$section'");
		if($check->rowCount() > 0){
		 $error = "Section Already Exists";
		}
		else{
			$insertsection=$con->query("INSERT INTO `section` SET `iddepartment` = '$iddepartment', `section` = '$section'");
		    if($insertsection){
			 $success = "Section Added Successfully";
			}
		}
}
?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Section</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Add New Section
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form role="form" method="post">
							<?php
                            if(isset($error)){
                              echo '<div class="alert alert-dismissable alert-danger">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong>'.$error.'</strong> </div>';
                                }
                                if(isset($success)){
                              echo '<div class="alert alert-dismissable alert-success">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong>'.$success.'</strong> </div>';
                                }
                                ?>
                                         
                                         <div class="form-group">
                                            <label>Department</label>
                                            <select name="iddepartment" id="iddepartment" class="form-control" tabindex="1" autofocus required>
                                            <option value="">Select Department</option>
											<?php
											$sqldepartment=$con->query("SELECT * FROM `department`
											 WHERE `status`=1
											 ORDER BY `department` ASC");
											while($resultdepartment=$sqldepartment->fetch(PDO::FETCH_ASSOC)){
												echo '<option value="'.$resultdepartment['iddepartment'].'">'.$resultdepartment['department'].'</option>';
											}
											?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Section</label>
                                            <input type="text" class="form-control" name="section" placeholder="Section" tabindex="2" autofocus autocomplete="off" required>
                                        </div>
                                        
                                       
                                        <button type="submit" class="btn btn-success" tabindex="2" name="savesection"><span class="fa fa-plus"></span> Save</button>
                                        <a href="index.php?option=general&item=section" class="btn btn-danger"><span class="fa fa-minus"></span> Cancel</a>
                                    </form>
                                </div>
                               
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <!-- /.row -->
           
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

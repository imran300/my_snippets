
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Department</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Department Record
                            <div class="pull-right">
                                <div class="btn-group">
                                    <a href="index.php?option=general&item=adddepartment" class="btn btn-primary btn-xs">
                                        <span class="fa fa-plus"></span> Add New Department
                                    </a>
                                    
                                </div>
                            </div>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th width="30%">Department</th>
                                            <th width="50%">Logo</th>
                                            <th width="20%">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
									$sql=$con->query("SELECT * FROM `department` ORDER BY `department` ASC");
									while($result=$sql->fetch(PDO::FETCH_ASSOC)){
									?>
                                        <tr class="odd gradeX">
                                            <td><?=$result['department'];?></td>
                                            <td><img src="../<?=$result['picture'];?>" alt="<?=$result['department'];?> Logo" width="300" height="40"></td>
                                            
                                            <td class="center">
                                            <a class="btn btn-warning btn-xs" href="index.php?option=general&item=editdepartment&id=<?=$result['iddepartment'];?>"><span class="fa fa-edit"></span> Edit</a>
                                            </td>
                                        </tr>
                                       <?php
									   }
									   ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <!-- /.row -->
           
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

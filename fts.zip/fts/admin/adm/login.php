<?php
session_start();
if($_SESSION['fts']){
	header("location:index.php");
}
include "conn.php";
	if(isset($_POST['loginuser'])){
	extract($_POST);
	$password=md5($password);
	$sql = $con->prepare("SELECT * 
			FROM  `users` AS u,  `employee` AS e,  `department` AS d,  `section` AS s,  `designation` AS g
			WHERE u.idemployee = e.idemployee
			AND e.iddepartment = d.iddepartment
			AND e.idsection = s.idsection
			AND e.iddesignation = g.iddesignation
			AND u.isactive =1
			AND u.isadmin =1
			AND u.status =1
			AND u.`username`= :username
			AND u.`password`= :password");
		$sql->bindParam(':username', $username, PDO::PARAM_STR);
		$sql->bindParam(':password', $password, PDO::PARAM_STR);
	$sql->execute();
	if($sql->rowCount()>0){
	$result=$sql->fetch(PDO::FETCH_OBJ);
	$_SESSION['fts']['idusers'] = $result->idusers;
	$_SESSION['fts']['iddepartment'] = $result->iddepartment;
	$_SESSION['fts']['idsection'] = $result->idsection;
	$_SESSION['fts']['department'] = $result->department;
	$_SESSION['fts']['section'] = $result->section;
    $_SESSION['fts']['designation'] = $result->designation;
	$_SESSION['fts']['empname'] = $result->empname;
	$_SESSION['fts']['empemail'] = $result->empemail;
	$_SESSION['fts']['logo'] = $result->picture;
	$_SESSION['fts']['prefix'] = $result->prefix;
		if($result->isadmin == 1 ){
			$_SESSION['fts']['admin'] = 1;
		}else{
			$_SESSION['fts']['admin'] = 0;
		}
		if($result->issuperadmin == 1 ){
			$_SESSION['fts']['superadmin'] = 1;
		}else{
			$_SESSION['fts']['superadmin'] = 0;
		}
		header("location:index.php"); 
	}
	else{
	$error = "Invalid Credentials, Please Try Again!";
	}
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Login &middot; File Tracking System</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="css/plugins/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link rel="icon" type="image/jpg" href="img/favicon.jpg">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    
                    <div class="panel-body">
                    <img src="img/logo.png" class="img img-responsive" width="330" style="margin-bottom:10px;">
                        <form role="form" method="post" enctype="multipart/form-data">
                            <fieldset>
                            <legend>Login</legend>
                            <?php
							if(isset($error)){
							echo '<div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>'.$error.'</div>';
							}
							?>
                            
                            
                                <div class="form-group">
                                    <input class="form-control" placeholder="Username" name="username" type="text" autocomplete="off" value="" autofocus required>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" type="password" autocomplete="off" value="" required>
                                </div>
                                <div class="checkbox">
                                    <label>
                                        <input name="remember" type="checkbox" value="Remember Me">Remember Me
                                    </label>
                                </div>
                                <!-- Change this to a button or input when using this as a form -->
                                <button type="submit" name="loginuser" class="btn btn-lg btn-success btn-block">Login</a>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery Version 1.11.0 -->
    <script src="js/jquery-1.11.0.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/code.js"></script>
    
    <!-- Metis Menu Plugin JavaScript -->
    <script src="js/plugins/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/sb-admin-2.js"></script>

</body>

</html>

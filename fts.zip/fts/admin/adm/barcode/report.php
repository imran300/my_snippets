<body onLoad="print()">
<?php
include("barcode/barcode.inc.php");
include "../conn.php";
$iddepartment=$_GET['iddepartment'];
$sql=$con->query("select * from `barcode` where iddepartment='$iddepartment' AND `status`=1");
while($result=$sql->fetch(PDO::FETCH_ASSOC)){
	
    	 $file=$result['barcode'];
		 $type="png";
	$encode='CODE39';
	$bar= new BARCODE();
	 $barnumber=$result['barcode'];
	$bar->setSymblogy($encode);
	$height='50';
	$bar->setHeight($height);
	$scale='2.5';
	$bar->setScale($scale);
	$color='#333366';
	$bgcolor='#FFFFEC';
	$bar->setHexColor($color,$bgcolor);
	$return = $bar->genBarCode($barnumber,$type,$file);
	?>
                <div style="width:250px; border:1px solid #eee;" align="center">
                <li style="list-style-type:none;">
				<img  src="<?php echo $file; ?>" >
                </li></div>
                <?php		
		$updatebarcode=$con->query("UPDATE `barcode` SET status='0' WHERE iddepartment='$iddepartment'");
		}
?>              
		


<div class="navbar-default sidebar" role="navigation">
  <div class="sidebar-nav navbar-collapse">
    <ul class="nav" id="side-menu">
      <li class="sidebar-search">
        <div class="input-group custom-search-form">
          <input type="text" class="form-control" placeholder="Search...">
          <span class="input-group-btn">
          <button class="btn btn-default" type="button"> <i class="fa fa-search"></i> </button>
          </span> </div>
        <!-- /input-group --> 
      </li>
      <?php
						if($superadmin==1){
							$sql=$con->prepare("SELECT * FROM `menu` WHERE `parent`='0' ORDER BY `sort` ASC");
							$sql->execute();
						}else{
							$sql=$con->prepare("SELECT * FROM `menu` WHERE `parent`='0' AND status=1 ORDER BY `sort` ASC");
							$sql->execute();
						}
						while($result=$sql->fetch(PDO::FETCH_ASSOC)){
						echo '<li><a href="'.$result['url'].'"><i class="fa fa-dashboard fa-fw"></i> '.$result['title'];
						$mid=$result['idmenu'];
						if($superadmin==1){
							$sqlinner=$con->prepare("SELECT * FROM `menu` WHERE `parent`='$mid' ORDER BY `sort` ASC");
							$sqlinner->execute();
						}else{
							$sqlinner=$con->prepare("SELECT * FROM `menu` WHERE `parent`='$mid' AND status=1 ORDER BY `sort` ASC");
							$sqlinner->execute();
						}
						if($sqlinner->rowCount()>0){
							echo '<span class="fa arrow"></span></a>
							<ul class="nav nav-second-level collapse">';
						while($resultinner=$sqlinner->fetch(PDO::FETCH_ASSOC)){
							echo '<li>
						<a href="'.$resultinner['url'].'">'.$resultinner['title'].'</a>
					</li>';
						}
						echo '</ul>';
						}
									
						echo '</a><li>';
						}
						?>
    </ul>
  </div>
  <!-- /.sidebar-collapse --> 
</div>

<!-- /.navbar-static-side -->
</nav>

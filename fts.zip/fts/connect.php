<?php
$db_name="fts";
$db_user= "root";
$db_pass= '';
$db_host="localhost";
mysql_connect($db_host, $db_user, $db_pass) or die(mysql_error());
mysql_select_db($db_name) or die(mysql_error());
?>
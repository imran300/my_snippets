<body onLoad="print()">
<?php
include("barcode/barcode.inc.php");
$conn=mysql_connect("localhost","root","root");
mysql_select_db("fts2");
$time=$_REQUEST['time'];
$sql=mysql_query("select * from `barcodes` where time='$time'");
while($result=mysql_fetch_array($sql)){
	
    	 $file=$result['barcode'];
		 $type="png";
	$encode='CODE39';
	$bar= new BARCODE();
	 $barnumber=$result['barcode'];
	$bar->setSymblogy($encode);
	$height='30';
	$bar->setHeight($height);
	$scale='2';
	$bar->setScale($scale);
	$color='#333366';
	$bgcolor='#FFFFEC';
	$bar->setHexColor($color,$bgcolor);
	$return = $bar->genBarCode($barnumber,$type,$file);
	?>
                <div style="width:150px; border:1px solid #eee;" align="center">
                <li style="list-style-type:none;">
				<img src="<?php echo $file; ?>">
                </li>
                </div>
		<?php		
		$update=mysql_query("UPDATE `barcodes` SET `print_status`=1 WHERE `time`='$time'");
		}
?>
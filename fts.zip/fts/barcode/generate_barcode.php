<?php
$sql=mysql_query("SELECT IFNULL( MAX( idbarcodes ) , 0)+1 as id FROM `barcodes`");
$result=mysql_fetch_assoc($sql);
$id=$result['id'];
if(isset($_POST['submit'])){
	extract($_POST);
	$start=$id;
	$end=($id+$_POST['numbers'])-1;
	$time=date("H:i:s");
	for($i=$start; $i<=$end; $i++){
	   $sql=mysql_query("INSERT INTO `barcodes` SET barcode='P&D-$start', time='$time', status=1");
	   $start++;
	}
	if($sql){
		echo "<script>window.open('report.php?time=$time')</script>";
	}
}
?>
<script>
    function isNumeric(qty){
var numexp = /^[0-9]+$/;
//alert(qty);
//qty=document.getElementById('qty')
if(qty.match(numexp)){
return true;
}else{
alert("Enter Numbers Only");
document.getElementById('numbers').value='';
qty.focus();
return false;
}
}
</script>
<fieldset class="signup">
  <legend>Barcode</legend>
<form method="post" enctype="multipart/form-data">

  <table width="50%" align="center">
    <tr>
     
              <td align="left">Generated Barcodes:</td>
              <td><input name="start" type="text" value="<?php echo $id - 1; ?>" readonly></td>
            </tr>
            <tr>
              <td align="left">No. of Barcodes to Generate:</td>
              <td><input name="numbers" type="text" autofocus="autofocus" required="required" id="numbers" onkeyup="isNumeric(this.value)" placeholder="Enter Numbers Only" /></td>
            </tr>
            <tr>
            <tr>
              <td colspan="2" align="center">&nbsp;</td>
            </tr>  
              <td colspan="2" align="center"><input type="submit" name="submit" value="Generate" style="width:100px;height:30px; background-color:#0296ca;border-radius:10px; color:#FFF;" /></td>
            </tr>
            
          </table>
        </form>
        
</fieldset>
<?php
try {      
            $db_host = 'localhost';  //  hostname
            $db_name = 'ftsdb';  //  databasename
            $db_user = 'root';  //  username
            $user_pw = 'root';  //  password

            $con = new PDO('mysql:host='.$db_host.'; dbname='.$db_name, $db_user, $user_pw);  
            $con->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
        }
        catch (PDOException $err) {  
            echo $err->getMessage();
			echo "sssss";
            die();  //  terminate connection
        }
?>